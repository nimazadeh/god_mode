/* Global keyboard shortcuts, Escape dismissal, table navigation, and modal/drawer bindings */
window.GodShortcuts = {
  init(appRef) {
    document.querySelectorAll(".mode-btn[data-mode]").forEach((btn) => {
      btn.addEventListener("click", () => {
        btn.classList.add("mode-activated");
        setTimeout(() => btn.classList.remove("mode-activated"), 120);
        window.GodCommands.setMode(btn.dataset.mode);
      });
    });
    const byId = (id) => document.getElementById(id);
    byId("allowlist-open-btn")?.addEventListener("click", () => window.GodModals.toggleAllowlistDrawer());
    byId("ports-open-btn")?.addEventListener("click", () => window.GodV25?.togglePortsDrawer());
    byId("quarantine-open-btn")?.addEventListener("click", () => window.GodV25?.toggleQuarantineDrawer());
    byId("close-process-drawer")?.addEventListener("click", () => byId("process-drawer").classList.add("hidden"));
    byId("close-allowlist-drawer")?.addEventListener("click", () => window.GodModals.toggleAllowlistDrawer(false));
    byId("close-ports-drawer")?.addEventListener("click", () => window.GodV25?.togglePortsDrawer(false));
    byId("close-quarantine-drawer")?.addEventListener("click", () => window.GodV25?.toggleQuarantineDrawer(false));
    byId("close-diff-modal")?.addEventListener("click", () => byId("diff-modal").classList.add("hidden"));
    byId("confirm-cancel-btn")?.addEventListener("click", () => byId("confirm-modal").classList.add("hidden"));
    byId("confirm-accept-btn")?.addEventListener("click", () => {
      byId("confirm-modal").classList.add("hidden");
      if (window.GodModals.confirmCallback) window.GodModals.confirmCallback();
    });
    byId("add-selected-allowlist-btn")?.addEventListener("click", () => this.actOnSelected(appRef, "allow"));
    byId("quarantine-selected-btn")?.addEventListener("click", () => this.actOnSelected(appRef, "quarantine_file"));
    window.addEventListener("keydown", (ev) => this.handleKey(ev));
  },

  actOnSelected(appRef, action) {
    const sel = window.GodAlerts.selectedAlert || appRef.state.alerts[0];
    if (!sel) return window.GodCommands.showToast("Select an alert row first");
    window.GodCommands.requestAction(action, sel);
    setTimeout(() => { window.GodModals.refreshAllowlistTable(); window.GodV25?.refreshQuarantine(); }, 350);
  },

  closeAllOverlays() {
    ["process-drawer", "allowlist-drawer", "ports-drawer", "quarantine-drawer", "rfc-drawer", "diff-modal", "confirm-modal"].forEach((id) => {
      document.getElementById(id)?.classList.add("hidden");
    });
  },

  handleKey(ev) {
    if (ev.key === "Escape") return this.closeAllOverlays();
    const active = document.activeElement;
    if (["INPUT", "TEXTAREA"].includes(active?.tagName)) return;
    if (active?.tagName === "TR" && (ev.key === "ArrowDown" || ev.key === "ArrowUp")) {
      ev.preventDefault();
      const next = ev.key === "ArrowDown" ? active.nextElementSibling : active.previousElementSibling;
      if (next && next.tabIndex === 0) next.focus();
      return;
    }
    if (ev.key === "ArrowLeft" || ev.key === "ArrowRight") return window.GodProto?.cycle(ev.key === "ArrowRight" ? 1 : -1);
    const key = ev.key.toUpperCase();
    const panelMap = { P: "panel-processes", N: "panel-connections", F: "panel-files" };
    if (panelMap[key]) document.getElementById(panelMap[key])?.querySelector("tr[tabindex]")?.focus();
    else if (key === "A") window.GodModals.toggleAllowlistDrawer();
    else if (key === "H") window.GodRfc?.toggleDrawer();
    else if (key === "L") window.GodV25?.togglePortsDrawer();
    else if (key === "Q") window.GodV25?.toggleQuarantineDrawer();
    else if (key === "R") {
      fetch("/api/reports/open", { method: "POST" }).catch((e) => console.error("Reports open:", e));
      window.open(`/api/reports/${new Date().toISOString().slice(0, 10)}`, "_blank");
    } else if (key === "S") window.GodSound.toggleMute(document.getElementById("mute-btn"));
  },
};
