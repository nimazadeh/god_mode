"""WebSocket connection manager, state broadcaster, and command dispatcher."""

import asyncio
from datetime import datetime
import json
import logging
import time
import uuid
from typing import Any
from fastapi import WebSocket
import psutil
from api.schemas import CommandMessage, CommandResultMessage
from constants import ALLOWLIST_PATH, MAX_DOM_ALERTS, REPORTS_DIR, SETTINGS_PATH, WS_BROADCAST_INTERVAL_SEC
from engine.os_adapter import block_outbound_ip, compute_sha256, open_reports_folder, terminate_process_by_pid
from engine.threat_scorer import check_allowlist_match

logger = logging.getLogger("god_mode.websocket")


class MonitorHub:
    """Coordinates WebSocket clients, real-time state updates, and user commands."""

    def __init__(self, state: dict[str, Any]) -> None:
        self.state = state
        self.clients: set[WebSocket] = set()
        self.alerts: list[dict[str, Any]] = []
        self.start_time = time.monotonic()

    async def connect(self, ws: WebSocket) -> None:
        """Accept a client WebSocket and immediately push current state."""
        await ws.accept()
        self.clients.add(ws)
        await ws.send_json(self.build_state_payload())

    def disconnect(self, ws: WebSocket) -> None:
        """Remove a disconnected client WebSocket."""
        self.clients.discard(ws)

    async def broadcast(self, message: dict[str, Any]) -> None:
        """Send a JSON payload to all connected WebSocket clients."""
        for ws in list(self.clients):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(ws)

    def build_stats(self) -> dict[str, Any]:
        """Compute live summary metrics for the dashboard stat cards and chart."""
        procs, conns = self.state["process_watcher"].latest_processes, self.state["network_sentinel"].latest_connections
        threats = sum(1 for a in self.alerts if a.get("severity") in ("WARN", "HIGH", "CRITICAL") and not a.get("resolved"))
        return {
            "process_count": len(procs), "connection_count": len(conns),
            "files_watched": len(self.state["file_guard"].latest_files), "threat_count": threats,
            "cpu_percent": round(float(psutil.cpu_percent(interval=None)), 1),
            "net_outbound_mbps": self.state["network_sentinel"].outbound_mbps,
            "operation_mode": self.state["settings"].operation_mode, "uptime_seconds": int(time.monotonic() - self.start_time),
        }

    def build_state_payload(self) -> dict[str, Any]:
        """Construct the 2-second periodic state_update WebSocket payload."""
        p_guard = self.state.get("persistence_guard")
        return {
            "type": "state_update", "timestamp": datetime.now().isoformat(timespec="seconds"),
            "stats": self.build_stats(), "processes": self.state["process_watcher"].latest_processes[:120],
            "connections": self.state["network_sentinel"].latest_connections[:120],
            "files": self.state["file_guard"].latest_files[:100], "alerts": self.alerts[:MAX_DOM_ALERTS],
            "autoruns": p_guard.latest_autoruns if p_guard else [],
            "listening_ports": p_guard.latest_listening_ports if p_guard else [],
            "settings": self.state["settings"].model_dump(),
        }

    async def _purge_expired_rules(self) -> list[dict[str, Any]]:
        """Auto-remove expired allowlist rules, log removal, and return active rules."""
        now_iso, active = datetime.now().isoformat(), []
        for rule in await self.state["db"].list_allowlist_rules():
            if rule.get("expires_at") and rule["expires_at"] < now_iso:
                await self.state["db"].delete_allowlist_rule(int(rule["id"]))
                logger.info("Auto-removed expired allowlist rule id=%s path=%s", rule["id"], rule["process_path"])
            else:
                active.append(rule)
        return active

    async def process_single_event(self, raw: dict[str, Any]) -> None:
        """Evaluate allowlist rules, persist event to SQLite, and broadcast alert."""
        rules = await self._purge_expired_rules()
        p_path = str(raw.get("process_path") or "Unknown")
        e_hash = str(raw.get("exe_hash") or compute_sha256(p_path))
        a_type = str(raw.get("alert_type") or f"{raw.get('engine', 'SYS')}_{raw.get('severity', 'WARN')}")
        suppressed, needs_review = check_allowlist_match(rules, p_path, e_hash, a_type)
        if suppressed:
            return
        raw["description"] = f"[NEEDS REVIEW: Hash Changed] {raw['description']}" if needs_review else raw["description"]
        row_id = await self.state["db"].insert_event(raw)
        alert = self._to_alert_dict(raw, row_id, a_type, e_hash, needs_review)
        self.alerts = [alert] + self.alerts[: MAX_DOM_ALERTS - 1]
        await self.broadcast(alert)

    def _to_alert_dict(self, raw: dict[str, Any], row_id: int, a_type: str, e_hash: str, review: bool) -> dict[str, Any]:
        """Format a persisted event into a new_alert WebSocket payload."""
        return {
            "type": "new_alert", "id": str(uuid.uuid4()), "db_id": row_id,
            "severity": raw.get("severity", "WARN"), "engine": raw.get("engine", "PROCESS"),
            "alert_type": a_type, "timestamp": raw.get("timestamp", datetime.now().isoformat(timespec="seconds")),
            "process": raw.get("process_name") or "Unknown", "process_path": raw.get("process_path") or "Unknown",
            "pid": raw.get("pid"), "exe_hash": e_hash, "remote_ip": raw.get("remote_ip"),
            "country": raw.get("country"), "file_path": raw.get("file_path"), "description": raw.get("description", ""),
            "actions_available": raw.get("actions_available", ["allow", "ignore"]), "needs_review": review, "resolved": False,
        }

    async def handle_command(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Validate and execute a user command received over WebSocket."""
        cmd, mode = CommandMessage.model_validate(payload), self.state["settings"].operation_mode
        if cmd.action == "set_mode":
            return self._switch_mode(cmd.target)
        if cmd.action in ("kill_process", "block_ip", "quarantine_file") and not cmd.confirmed:
            return self._cmd_res(cmd, False, "Explicit user confirmation required")
        if cmd.action == "kill_process":
            return await self._exec_kill(cmd, mode)
        if cmd.action == "block_ip":
            return await self._exec_block(cmd, mode)
        if cmd.action == "quarantine_file":
            return await self._exec_quarantine(cmd, mode)
        return await (self._exec_allow(cmd) if cmd.action == "allow" else self._exec_ignore(cmd))

    def _cmd_res(self, cmd: CommandMessage, ok: bool, msg: str) -> dict[str, Any]:
        """Construct a serialized CommandResultMessage dictionary."""
        return CommandResultMessage(alert_id=cmd.alert_id, success=ok, message=msg, action_taken=cmd.action).model_dump()

    def _switch_mode(self, new_mode: str) -> dict[str, Any]:
        """Update and persist the active OperationMode in settings.json."""
        if new_mode not in ("WATCH", "GUARD", "WAR"):
            return {"type": "command_result", "success": False, "message": "Invalid mode", "action_taken": "set_mode"}
        self.state["settings"].operation_mode = new_mode
        SETTINGS_PATH.write_text(json.dumps(self.state["settings"].model_dump(), indent=2), encoding="utf-8")
        return {"type": "command_result", "success": True, "message": f"Mode set to {new_mode}", "action_taken": "set_mode"}

    async def _exec_kill(self, cmd: CommandMessage, mode: str) -> dict[str, Any]:
        """Execute user-confirmed process termination when in GUARD or WAR mode."""
        if mode == "WATCH":
            return self._cmd_res(cmd, False, "Process termination disabled in WATCH mode")
        ok, msg = terminate_process_by_pid(int(cmd.target)) if cmd.target.isdigit() else (False, "Invalid PID")
        await self._mark_alert_resolved(cmd.alert_id, "KILLED" if ok else None)
        return self._cmd_res(cmd, ok, msg)

    async def _exec_block(self, cmd: CommandMessage, mode: str) -> dict[str, Any]:
        """Execute user-confirmed firewall IP block when in WAR mode."""
        if mode != "WAR":
            return self._cmd_res(cmd, False, "Firewall IP blocking requires WAR MODE")
        ok, msg = await block_outbound_ip(cmd.target)
        if ok:
            self.state["network_sentinel"].blocked_ips.add(cmd.target)
        await self._mark_alert_resolved(cmd.alert_id, "BLOCKED" if ok else None)
        return self._cmd_res(cmd, ok, msg)

    async def _exec_quarantine(self, cmd: CommandMessage, mode: str) -> dict[str, Any]:
        """Execute user-confirmed file quarantine in GUARD or WAR mode."""
        if mode == "WATCH":
            return self._cmd_res(cmd, False, "Quarantine disabled in WATCH mode")
        ok, msg, _ = await self.state["quarantine_vault"].quarantine_file(cmd.target, cmd.note or "Alert quarantine")
        await self._mark_alert_resolved(cmd.alert_id, "QUARANTINED" if ok else None)
        return self._cmd_res(cmd, ok, msg)

    async def _exec_allow(self, cmd: CommandMessage) -> dict[str, Any]:
        """Create a 3-tuple allowlist rule from the target alert."""
        p_path = cmd.process_path or cmd.target or "Unknown"
        rule = {
            "process_path": p_path, "exe_hash": compute_sha256(p_path), "alert_type": cmd.alert_type or "MANUAL_ALLOW",
            "added_at": datetime.now().isoformat(timespec="seconds"), "expires_at": None, "note": cmd.note or "Allowed",
        }
        await self.state["db"].add_allowlist_rule(rule)
        ALLOWLIST_PATH.write_text(json.dumps(await self.state["db"].list_allowlist_rules(), indent=2), encoding="utf-8")
        await self._mark_alert_resolved(cmd.alert_id, "ALLOWED")
        return self._cmd_res(cmd, True, f"Allowlist rule created for {p_path}")

    async def _exec_ignore(self, cmd: CommandMessage) -> dict[str, Any]:
        """Dismiss an alert or handle auxiliary action such as open_reports."""
        if cmd.target == "open_reports":
            ok, msg = open_reports_folder(REPORTS_DIR)
            return self._cmd_res(cmd, ok, msg)
        await self._mark_alert_resolved(cmd.alert_id, "IGNORED")
        return self._cmd_res(cmd, True, "Alert dismissed")

    async def _mark_alert_resolved(self, alert_id: str | None, action: str | None) -> None:
        """Mark an in-memory alert resolved and update its SQLite row."""
        for alert in self.alerts:
            if alert["id"] == alert_id:
                alert["resolved"] = True
                if action and alert.get("db_id"):
                    await self.state["db"].record_event_action(int(alert["db_id"]), action, "user")

    async def run_broadcaster(self) -> None:
        """Drain EventBus and push state_update every WS_BROADCAST_INTERVAL_SEC."""
        while True:
            for raw in self.state["event_bus"].drain_pending():
                await self.process_single_event(raw)
            await self.broadcast(self.build_state_payload())
            await asyncio.sleep(WS_BROADCAST_INTERVAL_SEC)
