"""Browser E2E test and screenshot capture for Ticket 02: FileGuard live mutation & drawers."""

import asyncio
from pathlib import Path
import time
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")
VAULT_DIR = Path("/home/user/god-mode-monitor/watched_vault")


@pytest.mark.asyncio
async def test_ticket02_browser_alerts_and_detail_drawers():
    """Verify live FileGuard mutation alert, Process Detail drawer, and Hash Diff modal."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    VAULT_DIR.mkdir(parents=True, exist_ok=True)
    seed_file = VAULT_DIR / "system_integrity_seed.cfg"
    errors: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

        await page.goto("http://127.0.0.1:8080", wait_until="networkidle")
        await page.wait_for_function("Number(document.getElementById('stat-processes')?.textContent || '0') > 0")

        seed_file.write_text(f"god_mode_baseline=mutated_{int(time.time())}\n", encoding="utf-8")
        await asyncio.sleep(2.5)

        file_text = await page.locator("#files-tbody").text_content()
        assert "CHANGED 🔴" in (file_text or "")

        await page.locator("#processes-tbody tr").first.click()
        drawer_hidden = await page.locator("#process-drawer").evaluate("el => el.classList.contains('hidden')")
        assert drawer_hidden is False

        await page.locator("#files-tbody tr").first.click()
        diff_text = await page.locator("#diff-modal-body").text_content()
        assert "Baseline SHA-256:" in (diff_text or "") and "Current SHA-256:" in (diff_text or "")

        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_02_engines_and_drawers.png"))
        await browser.close()

    assert errors == [], f"Browser errors: {errors}"
