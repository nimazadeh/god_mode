"""FastAPI REST endpoints and WebSocket route wiring for God Mode Monitor."""

from datetime import datetime
import json
import logging
from typing import Any
from fastapi import APIRouter, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse
from api.rfc_routes import rfc_router
from api.schemas import AllowlistRuleCreate, QuarantineCreate, SettingsConfig
from constants import (
    ALLOWLIST_PATH,
    BASE_DIR,
    DASHBOARD_DIR,
    DEFAULT_EVENTS_LIMIT,
    REPORTS_DIR,
    SETTINGS_PATH,
)
from engine.os_adapter import compute_sha256, configure_windows_startup, open_reports_folder

logger = logging.getLogger("god_mode.routes")
router = APIRouter()
router.include_router(rfc_router)


def _enrich_allowlist_status(rules: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Annotate each allowlist rule with ACTIVE, EXPIRED, or NEEDS REVIEW."""
    now_iso = datetime.now().isoformat()
    enriched: list[dict[str, Any]] = []
    for rule in rules:
        cur_hash = compute_sha256(str(rule.get("process_path", "")))
        exp = rule.get("expires_at")
        if exp and exp < now_iso:
            status = "EXPIRED"
        elif cur_hash not in ("UNKNOWN", rule.get("exe_hash")):
            status = "NEEDS REVIEW"
        else:
            status = "ACTIVE"
        enriched.append({**rule, "status": status})
    return enriched


@router.get("/", response_class=HTMLResponse)
async def serve_dashboard() -> FileResponse:
    """Serve the main single-page dashboard HTML with no-cache headers."""
    return FileResponse(DASHBOARD_DIR / "index.html", headers={"Cache-Control": "no-store, max-age=0"})


@router.get("/static/{file_path:path}")
async def serve_static(file_path: str) -> FileResponse:
    """Serve CSS, font, and JS static assets from dashboard/ directory."""
    target = (DASHBOARD_DIR / file_path).resolve()
    if not str(target).startswith(str(DASHBOARD_DIR.resolve())) or not target.is_file():
        raise HTTPException(status_code=404, detail="Static asset not found")
    return FileResponse(target, headers={"Cache-Control": "no-store, max-age=0"})


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket) -> None:
    """Handle bidirectional real-time WebSocket stream."""
    hub = ws.app.state.monitor["hub"]
    await hub.connect(ws)
    try:
        while True:
            data = await ws.receive_json()
            if data.get("type") == "command":
                res = await hub.handle_command(data)
                await ws.send_json(res)
                await hub.broadcast(hub.build_state_payload())
    except WebSocketDisconnect:
        hub.disconnect(ws)
    except Exception:
        logger.exception("WebSocket error")
        hub.disconnect(ws)


@router.get("/api/stats")
async def get_live_stats(request: Request) -> dict[str, Any]:
    """Return current live stats snapshot."""
    return request.app.state.monitor["hub"].build_stats()


@router.get("/api/events")
async def get_recent_events(request: Request) -> list[dict[str, Any]]:
    """Return the last 100 security events from SQLite."""
    return await request.app.state.monitor["db"].get_recent_events(DEFAULT_EVENTS_LIMIT)


@router.get("/api/events/{date_str}")
async def get_events_for_date(date_str: str, request: Request) -> list[dict[str, Any]]:
    """Return all security events for a specific YYYY-MM-DD date."""
    return await request.app.state.monitor["db"].get_events_by_date(date_str)


@router.get("/api/allowlist")
async def list_allowlist(request: Request) -> list[dict[str, Any]]:
    """Return all allowlist rules with live hash verification status."""
    raw_rules = await request.app.state.monitor["db"].list_allowlist_rules()
    return _enrich_allowlist_status(raw_rules)


@router.post("/api/allowlist")
async def create_allowlist_rule(body: AllowlistRuleCreate, request: Request) -> dict[str, Any]:
    """Add a new 3-tuple allowlist rule and sync allowlist.json."""
    db = request.app.state.monitor["db"]
    exe_hash = body.exe_hash or compute_sha256(body.process_path)
    rule = {
        "process_path": body.process_path, "exe_hash": exe_hash,
        "alert_type": body.alert_type, "added_at": datetime.now().isoformat(timespec="seconds"),
        "expires_at": body.expires_at, "note": body.note,
    }
    rule_id = await db.add_allowlist_rule(rule)
    ALLOWLIST_PATH.write_text(json.dumps(await db.list_allowlist_rules(), indent=2), encoding="utf-8")
    return {**rule, "id": rule_id, "status": "ACTIVE"}


@router.delete("/api/allowlist/{rule_id}")
async def remove_allowlist_rule(rule_id: int, request: Request) -> dict[str, Any]:
    """Remove an allowlist rule by ID and sync allowlist.json."""
    db = request.app.state.monitor["db"]
    if not await db.delete_allowlist_rule(rule_id):
        raise HTTPException(status_code=404, detail="Allowlist rule not found")
    ALLOWLIST_PATH.write_text(json.dumps(await db.list_allowlist_rules(), indent=2), encoding="utf-8")
    return {"deleted": True, "id": rule_id}


@router.get("/api/settings")
async def get_settings(request: Request) -> dict[str, Any]:
    """Return current validated settings.json content."""
    return request.app.state.monitor["settings"].model_dump()


@router.post("/api/settings")
async def update_settings(new_cfg: SettingsConfig, request: Request) -> dict[str, Any]:
    """Validate and persist updated settings.json configuration."""
    mon = request.app.state.monitor
    mon["settings"] = new_cfg
    mon["process_watcher"].settings = new_cfg
    mon["network_sentinel"].settings = new_cfg
    mon["file_guard"].settings = new_cfg
    SETTINGS_PATH.write_text(json.dumps(new_cfg.model_dump(), indent=2), encoding="utf-8")
    configure_windows_startup(new_cfg.launch_on_startup, BASE_DIR / "main.py")
    return new_cfg.model_dump()


@router.get("/api/reports")
async def list_reports(request: Request) -> dict[str, Any]:
    """Ensure today's report exists and list all available daily report dates."""
    today_str = datetime.now().date().isoformat()
    await request.app.state.monitor["reports"].generate_for_date(today_str)
    files = sorted([p.stem for p in REPORTS_DIR.glob("*.html")], reverse=True)
    return {"reports": files}


@router.get("/api/reports/{date_str}", response_class=HTMLResponse)
async def get_report_html(date_str: str, request: Request) -> HTMLResponse:
    """Regenerate and serve the self-contained HTML report for a YYYY-MM-DD date."""
    path = await request.app.state.monitor["reports"].generate_for_date(date_str)
    return HTMLResponse(path.read_text(encoding="utf-8"))


@router.post("/api/reports/open")
async def trigger_open_reports() -> dict[str, Any]:
    """Open the reports folder in Windows Explorer."""
    ok, msg = open_reports_folder(REPORTS_DIR)
    return {"success": ok, "message": msg}


@router.get("/api/persistence")
async def get_persistence_and_ports(request: Request) -> dict[str, Any]:
    """Return latest startup autorun entries and local listening ports."""
    guard = request.app.state.monitor["persistence_guard"]
    return await guard.scan_once()


@router.get("/api/quarantine")
async def list_quarantine_items(request: Request) -> list[dict[str, Any]]:
    """Return all quarantine vault items ordered newest first."""
    return await request.app.state.monitor["quarantine_vault"].list_items()


@router.post("/api/quarantine")
async def quarantine_target_file(body: QuarantineCreate, request: Request) -> dict[str, Any]:
    """Quarantine a suspicious file into quarantine/ vault."""
    ok, msg, rec = await request.app.state.monitor["quarantine_vault"].quarantine_file(body.file_path, body.reason)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg, "record": rec}


@router.post("/api/quarantine/{item_id}/restore")
async def restore_quarantine_item(item_id: int, request: Request) -> dict[str, Any]:
    """Restore a quarantined file back to its original location."""
    ok, msg = await request.app.state.monitor["quarantine_vault"].restore_file(item_id)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"success": True, "message": msg}
