/* Country Threat Matrix Strip, Vector SVG Flag Renderer (Windows-safe), and Live Filter */
const FLAG_SVGS = {
  RU: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='3.7' fill='%23fff'/><rect y='3.7' width='15' height='3.6' fill='%230039a6'/><rect y='7.3' width='15' height='3.7' fill='%23d52b1e'/></svg>",
  CN: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%23de2910'/><circle cx='3.5' cy='3.5' r='1.6' fill='%23ffde00'/><circle cx='6.8' cy='2.2' r='0.6' fill='%23ffde00'/><circle cx='7.5' cy='3.8' r='0.6' fill='%23ffde00'/></svg>",
  KP: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%23024fa2'/><rect y='2' width='15' height='7' fill='%23fff'/><rect y='2.5' width='15' height='6' fill='%23ed1c27'/><circle cx='5.5' cy='5.5' r='2' fill='%23fff'/><circle cx='5.5' cy='5.5' r='1.3' fill='%23ed1c27'/></svg>",
  IR: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='3.7' fill='%23239f40'/><rect y='3.7' width='15' height='3.6' fill='%23fff'/><rect y='7.3' width='15' height='3.7' fill='%23da0000'/><circle cx='7.5' cy='5.5' r='1.2' fill='%23da0000'/></svg>",
  US: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%23b22234'/><rect y='1.6' width='15' height='1.4' fill='%23fff'/><rect y='4.6' width='15' height='1.4' fill='%23fff'/><rect y='7.6' width='15' height='1.4' fill='%23fff'/><rect width='7' height='6' fill='%233c3b6e'/></svg>",
  DE: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='3.7' fill='%23111'/><rect y='3.7' width='15' height='3.6' fill='%23dd0000'/><rect y='7.3' width='15' height='3.7' fill='%23ffce00'/></svg>",
  NL: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='3.7' fill='%23ae1c28'/><rect y='3.7' width='15' height='3.6' fill='%23fff'/><rect y='7.3' width='15' height='3.7' fill='%2321468b'/></svg>",
  GB: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%23012169'/><rect x='6' width='3' height='11' fill='%23fff'/><rect y='4' width='15' height='3' fill='%23fff'/><rect x='6.6' width='1.8' height='11' fill='%23c8102e'/><rect y='4.6' width='15' height='1.8' fill='%23c8102e'/></svg>",
  FR: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='5' height='11' fill='%23002395'/><rect x='5' width='5' height='11' fill='%23fff'/><rect x='10' width='5' height='11' fill='%23ed2939'/></svg>",
  LO: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%231b3a2b'/><rect x='4' y='3' width='7' height='5' fill='%2322cc66'/></svg>",
  EXT: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 15 11'><rect width='15' height='11' fill='%23162647'/><circle cx='7.5' cy='5.5' r='3.5' fill='%235c7cfa'/></svg>",
};

window.GodInspector = {
  createFlagIcon(code) {
    const key = String(code || "EXT").toUpperCase();
    const img = document.createElement("img");
    img.className = "flag-icon";
    img.alt = key;
    img.src = `data:image/svg+xml;utf8,${FLAG_SVGS[key] || FLAG_SVGS.EXT}`;
    return img;
  },

  renderCountryMatrix(connections) {
    const container = document.getElementById("country-matrix");
    if (!container) return;
    container.textContent = "";
    const counts = { RU: 0, CN: 0, KP: 0, IR: 0, EXT: 0, LO: 0 };
    (connections || []).forEach((c) => {
      const code = String(c.country_code || "UN").toUpperCase();
      if (code === "LO") counts.LO += 1;
      else if (counts[code] !== undefined) counts[code] += 1;
      else counts.EXT += 1;
    });
    [["RU", counts.RU, true], ["CN", counts.CN, true], ["KP", counts.KP, true], ["IR", counts.IR, true], ["EXT", counts.EXT, false], ["LO", counts.LO, false]].forEach(([code, val, isFlagged]) => {
      const chip = document.createElement("span");
      chip.className = isFlagged && val > 0 ? "matrix-chip flagged" : "matrix-chip";
      chip.appendChild(this.createFlagIcon(code));
      chip.appendChild(document.createTextNode(`${code === "LO" ? "LAN" : code}: ${val}`));
      container.appendChild(chip);
    });
  },

  inspectItem() {},

  filterList(items, textExtractor, isThreatFn) {
    const q = window.GodProto ? window.GodProto.searchQuery : "";
    const onlyThreats = window.GodProto ? window.GodProto.threatsOnly : false;
    return (items || []).filter((item) => {
      if (onlyThreats && !isThreatFn(item)) return false;
      return !q || textExtractor(item).toLowerCase().includes(q);
    });
  },
};
