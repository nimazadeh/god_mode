"""End-to-end Playwright Chromium tests following webapp-testing reconnaissance patterns."""

from __future__ import annotations

from pathlib import Path
import socket
import threading
import time
from playwright.sync_api import sync_playwright
import uvicorn

from sentinel.api import create_app


def get_free_tcp_port() -> int:
    """Allocate an ephemeral local port for the test HTTP server."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def test_linear_light_persian_ui_accessibility_geometry_and_workflow(
    tmp_path: Path,
) -> None:
    """Verify Persian RTL UI, Linear Light tokens, header geometry, and scan workflows."""
    port = get_free_tcp_port()
    db_path = tmp_path / "e2e_sentinel.db"
    app = create_app(database_path=db_path)

    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=port,
        log_level="error",
        server_header=False,
    )
    server = uvicorn.Server(config=config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    base_url = f"http://127.0.0.1:{port}"
    for _ in range(40):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)

    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(headless=True)
            page = browser.new_page(viewport={"width": 1280, "height": 850})

            console_errors: list[str] = []
            page_errors: list[str] = []
            page.on(
                "console",
                lambda msg: console_errors.append(msg.text)
                if msg.type == "error"
                else None,
            )
            page.on("pageerror", lambda err: page_errors.append(str(err)))

            page.goto(base_url, wait_until="networkidle")
            page.wait_for_selector("#diff-table-body tr")

            assert len(console_errors) == 0, f"Console errors: {console_errors}"
            assert len(page_errors) == 0, f"Page errors: {page_errors}"

            body_text_initial = page.locator("body").inner_text()
            assert "undefined" not in body_text_initial
            assert "NaN" not in body_text_initial
            assert "پایشگر قیمت گیاه‌کالا" in body_text_initial

            # Verify Linear Light-Mode surface colors and tabular-nums
            body_bg = page.evaluate(
                "() => getComputedStyle(document.body).backgroundColor"
            )
            assert body_bg == "rgb(247, 248, 249)"

            topbar_bg = page.evaluate(
                "() => getComputedStyle(document.querySelector('.topbar')).backgroundColor"
            )
            assert topbar_bg == "rgb(255, 255, 255)"

            num_font_variant = page.evaluate(
                "() => getComputedStyle(document.querySelector('.num-col')).fontVariantNumeric"
            )
            assert "tabular-nums" in num_font_variant

            # Verify Header & Table Bounding-Box Geometry (no overlap, no horizontal clipping)
            geometry = page.evaluate(
                """() => {
                    const topbar = document.querySelector('.topbar').getBoundingClientRect();
                    const skipLink = document.querySelector('.skip-link').getBoundingClientRect();
                    const srElements = Array.from(document.querySelectorAll('.sr-only')).map(
                        el => el.getBoundingClientRect()
                    );
                    const tableScroll = document.querySelector('.table-scroll');
                    return {
                        topbarBottom: topbar.bottom,
                        skipLinkBottom: skipLink.bottom,
                        srMaxHeight: Math.max(...srElements.map(r => r.height)),
                        scrollWidth: tableScroll.scrollWidth,
                        clientWidth: tableScroll.clientWidth,
                    };
                }"""
            )
            assert geometry["skipLinkBottom"] < 0
            assert geometry["srMaxHeight"] <= 1
            assert geometry["scrollWidth"] <= geometry["clientWidth"]

            # Verify Accessibility landmarks
            assert page.locator('header[role="banner"]').count() == 1
            assert page.locator("main#main-workspace").count() == 1
            assert page.locator('nav[role="tablist"]').count() == 1
            assert (
                page.locator('#live-status-region[aria-live="polite"]').count()
                == 1
            )

            # Default Changed Only tab should show 8 changed items
            assert page.locator("#diff-table-body tr").count() == 8
            assert page.locator("#metric-total-changed").inner_text() == "8"

            # Filter to Price Increased only (4 items)
            page.locator('button[data-filter="price_increased"]').click()
            assert page.locator("#diff-table-body tr").count() == 4

            # Switch to All Tracked (11 items)
            page.locator('button[data-filter="all"]').click()
            assert page.locator("#diff-table-body tr").count() == 11

            # Inspect a specific product row (Green Tea Polyphenols - ID 70731)
            page.locator('tr[data-product-id="70731"]').click()
            inspector_text = page.locator("#inspector-tiers").inner_text()
            assert "خلوص ۵۰ درصد" in inspector_text

            # Trigger an on-demand scan in Verified Catalog mode
            page.locator("#select-scan-mode").select_option("verified_catalog")
            page.locator("#btn-run-scan").click()
            page.wait_for_function(
                "() => document.getElementById('live-status-region').textContent.includes('اسکن با موفقیت انجام شد')"
            )

            body_text_after_scan = page.locator("body").inner_text()
            assert "undefined" not in body_text_after_scan
            assert "NaN" not in body_text_after_scan

            # Verify Apple iPhone 15/16 Pro (390x844) and iPhone SE (375x667) responsive card layout
            for iphone_width, iphone_height in [(390, 844), (375, 667)]:
                iphone_page = browser.new_page(
                    viewport={"width": iphone_width, "height": iphone_height},
                    is_mobile=True,
                    has_touch=True,
                )
                iphone_page.goto(base_url, wait_until="networkidle")
                iphone_page.wait_for_selector("#diff-table-body tr")
                mobile_geometry = iphone_page.evaluate(
                    """() => ({
                        docScrollWidth: document.documentElement.scrollWidth,
                        docClientWidth: document.documentElement.clientWidth,
                        tableScrollWidth: document.querySelector('.table-scroll').scrollWidth,
                        tableClientWidth: document.querySelector('.table-scroll').clientWidth,
                        firstRowDisplay: getComputedStyle(document.querySelector('#diff-table-body tr')).display,
                        inputFontSize: getComputedStyle(document.getElementById('input-search-filter')).fontSize,
                    })"""
                )
                assert (
                    mobile_geometry["docScrollWidth"]
                    <= mobile_geometry["docClientWidth"]
                )
                assert (
                    mobile_geometry["tableScrollWidth"]
                    <= mobile_geometry["tableClientWidth"]
                )
                assert mobile_geometry["firstRowDisplay"] == "grid"
                assert mobile_geometry["inputFontSize"] == "16px"
                iphone_page.close()

            browser.close()
    finally:
        server.should_exit = True
        thread.join(timeout=3.0)
