@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title GiyahKala Price Sentinel v1.0.0
echo ====================================================================
echo   GiyahKala Price Sentinel v1.0.0 - Affiliate Price Monitor
echo ====================================================================
if exist ".venv\Scripts\python.exe" goto VENV_READY
echo [SETUP] Creating isolated Python virtual environment...
python -m venv .venv
if errorlevel 1 goto ERROR_EXIT
:VENV_READY
echo [SETUP] Verifying required Python packages...
".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
if errorlevel 1 goto ERROR_EXIT
echo [START] Launching local dashboard at http://127.0.0.1:8090/ ...
start "" http://127.0.0.1:8090/
".venv\Scripts\python.exe" main.py --host 127.0.0.1 --port 8090
goto END_SCRIPT
:ERROR_EXIT
echo [ERROR] Startup failed. Please verify Python 3.11+ is installed.
pause
:END_SCRIPT
endlocal
