"""Pydantic schemas for REST endpoints, WebSocket messages, and configuration."""

from typing import Literal, Optional
from pydantic import BaseModel, Field


SeverityType = Literal["INFO", "WARN", "HIGH", "CRITICAL"]
EngineType = Literal["PROCESS", "NETWORK", "FILE", "PERSISTENCE"]
ModeType = Literal["WATCH", "GUARD", "WAR"]
ActionType = Literal["block_ip", "kill_process", "quarantine_file", "allow", "ignore", "set_mode"]


class QuarantineCreate(BaseModel):
    """Input payload for quarantining a suspicious file."""

    file_path: str = Field(min_length=1)
    reason: str = Field(default="Operator quarantine")
    alert_id: Optional[str] = None


class TimeWindow(BaseModel):
    """Start and end HH:MM strings defining a daily time window."""

    start: str = Field(pattern=r"^\d{2}:\d{2}$")
    end: str = Field(pattern=r"^\d{2}:\d{2}$")


class SettingsConfig(BaseModel):
    """Validated user configuration persisted in config/settings.json."""

    host: str = Field(default="0.0.0.0", min_length=1)
    port: int = Field(default=8080, ge=1, le=65535)
    operation_mode: ModeType
    flagged_countries: list[str] = Field(min_length=1)
    watched_paths: list[str] = Field(default_factory=list)
    sensitive_hours: TimeWindow
    quiet_hours: TimeWindow
    launch_on_startup: bool = False
    auto_open_browser: bool = False

    @classmethod
    def default_settings(cls) -> "SettingsConfig":
        """Construct the default valid configuration instance."""
        return cls(
            host="0.0.0.0",
            port=8080,
            operation_mode="GUARD",
            flagged_countries=["RU", "CN", "KP", "IR"],
            watched_paths=["watched_vault"],
            sensitive_hours=TimeWindow(start="00:00", end="06:00"),
            quiet_hours=TimeWindow(start="23:00", end="07:00"),
            launch_on_startup=False,
            auto_open_browser=False,
        )


class AllowlistRuleCreate(BaseModel):
    """Input payload for creating an allowlist suppression rule."""

    process_path: str = Field(min_length=1)
    exe_hash: Optional[str] = None
    alert_type: str = Field(min_length=1)
    expires_at: Optional[str] = None
    note: str = Field(default="Approved from dashboard")


class AllowlistRuleOut(BaseModel):
    """Stored allowlist rule returned to the dashboard."""

    id: int
    process_path: str
    exe_hash: str
    alert_type: str
    added_at: str
    expires_at: Optional[str] = None
    note: Optional[str] = None
    status: str = "ACTIVE"


class LiveStats(BaseModel):
    """Aggregate telemetry counters broadcast every 2 seconds."""

    process_count: int = 0
    connection_count: int = 0
    files_watched: int = 0
    threat_count: int = 0
    cpu_percent: float = 0.0
    net_outbound_mbps: float = 0.0
    operation_mode: ModeType = "GUARD"
    uptime_seconds: int = 0


class AlertPayload(BaseModel):
    """Real-time security alert pushed over WebSocket."""

    type: Literal["new_alert"] = "new_alert"
    id: str
    severity: SeverityType
    engine: EngineType
    timestamp: str
    process: str = "Unknown"
    process_path: str = "Unknown"
    pid: Optional[int] = None
    remote_ip: Optional[str] = None
    country: Optional[str] = None
    file_path: Optional[str] = None
    description: str
    actions_available: list[str] = Field(default_factory=list)
    needs_review: bool = False


class CommandMessage(BaseModel):
    """User action command received from the browser over WebSocket."""

    type: Literal["command"] = "command"
    action: ActionType
    target: str = ""
    alert_id: Optional[str] = None
    confirmed: bool = False
    process_path: Optional[str] = None
    alert_type: Optional[str] = None
    note: Optional[str] = None


class CommandResultMessage(BaseModel):
    """Result of executing a user command sent back over WebSocket."""

    type: Literal["command_result"] = "command_result"
    alert_id: Optional[str] = None
    success: bool
    message: str
    action_taken: str
