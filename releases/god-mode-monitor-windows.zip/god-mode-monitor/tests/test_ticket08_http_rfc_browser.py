"""Playwright E2E browser verification for Ticket 08: v3.0 HTTP RFC Sentinel Pack."""

from pathlib import Path
from playwright.async_api import async_playwright
import pytest


@pytest.mark.asyncio
async def test_ticket08_http_rfc_drawer_probes_and_variant_b_tab() -> None:
    """Verify HTTP RFC Sentinel drawer, RFC 9421/9530 badge, RFC 9112/9110 probes, and Variant B Tab 5."""
    screenshots_dir = Path("/home/user/screenshots")
    screenshots_dir.mkdir(parents=True, exist_ok=True)
    shot_path = screenshots_dir / "ticket_08_http_rfc_sentinel.png"

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        await page.goto("http://127.0.0.1:8080/?variant=A", wait_until="networkidle")

        await page.click("#rfc-open-btn")
        await page.wait_for_selector("#rfc-drawer:not(.hidden)")
        await page.wait_for_function(
            "document.getElementById('rfc-crypto-status')?.textContent.includes('VERIFIED')"
        )

        crypto_text = await page.text_content("#rfc-crypto-status")
        assert crypto_text is not None and "RFC 9530" in crypto_text and "RFC 9421" in crypto_text

        audits_text = await page.text_content("#rfc-audits-tbody")
        assert audits_text is not None and "100/100" in audits_text

        await page.click("[data-rfc-probe='smuggling_rfc9112']")
        await page.wait_for_function(
            "document.getElementById('rfc-firewall-tbody')?.textContent.includes('RFC 9112')"
        )
        await page.click("[data-rfc-probe='trace_rfc9110']")
        await page.wait_for_function(
            "document.getElementById('rfc-firewall-tbody')?.textContent.includes('RFC 9110')"
        )

        await page.screenshot(path=str(shot_path), full_page=False)

        await page.keyboard.press("Escape")
        await page.wait_for_selector("#rfc-drawer.hidden", state="attached")

        await page.goto("http://127.0.0.1:8080/?variant=B", wait_until="networkidle")
        await page.click(".wb-tab-btn[data-tab='http_rfc']")
        await page.wait_for_selector("#rfc-drawer:not(.hidden)")
        toast_text = await page.text_content("#toast-container")
        assert "Invalid mode" not in (toast_text or "")

        await browser.close()

    assert shot_path.exists() and shot_path.stat().st_size > 10000
