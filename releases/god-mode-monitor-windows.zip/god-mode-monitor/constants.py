"""System-wide constants for God Mode Monitor."""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
CONFIG_DIR = BASE_DIR / "config"
SETTINGS_PATH = CONFIG_DIR / "settings.json"
ALLOWLIST_PATH = CONFIG_DIR / "allowlist.json"
DASHBOARD_DIR = BASE_DIR / "dashboard"
REPORTS_DIR = BASE_DIR / "reports"
LOGS_DIR = BASE_DIR / "logs"
LOG_FILE_PATH = LOGS_DIR / "engine.log"
DB_FILE_PATH = BASE_DIR / "storage" / "god_mode.db"
WATCHED_SANDBOX_DIR = BASE_DIR / "watched_vault"
WATCHED_AUTORUNS_DIR = BASE_DIR / "watched_autoruns"
QUARANTINE_DIR = BASE_DIR / "quarantine"

RISKY_BACKDOOR_PORTS = (4444, 1337, 31337, 6667, 5900, 3389)
RFC_MAX_SINGLE_HEADER_BYTES = 4096
RFC_MAX_TOTAL_HEADERS_BYTES = 8192
RFC_SIGNING_SECRET = b"god-mode-rfc9421-local-hmac-key"
RFC_SCORE_FULL = 100
RFC_AUDIT_TIMEOUT_SEC = 4.0
PROTECTED_SYSTEM_PREFIXES = (
    "c:\\windows\\system32",
    "c:\\windows\\syswow64",
    "/usr/bin",
    "/bin",
    "/sbin",
    "/lib",
)

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8080

LOG_MAX_BYTES = 10 * 1024 * 1024
LOG_BACKUP_COUNT = 3

WS_BROADCAST_INTERVAL_SEC = 2.0
ENGINE_POLL_INTERVAL_SEC = 3.0

CPU_SPIKE_PERCENT = 80.0
CPU_SPIKE_DURATION_SEC = 30.0
HIGH_MEMORY_THRESHOLD_MB = 1024.0
BYTES_PER_MB = 1024 * 1024

IP_API_BASE_URL = "http://ip-api.com/json/"
IP_CACHE_TTL_SECONDS = 3600
IP_RATE_LIMIT_PER_MIN = 45
RATE_LIMIT_WINDOW_SEC = 60.0

AVG_PACKET_BYTES_ESTIMATE = 65536
HIGH_OUTBOUND_MB = 1.0
CRITICAL_OUTBOUND_MB = 5.0

MAX_DOM_ALERTS = 200
DEFAULT_EVENTS_LIMIT = 100
HOURS_IN_DAY = 24

SUSPICIOUS_PATH_TOKENS = ("\\temp\\", "/tmp/", "appdata\\local\\temp")
SYSTEM_PROCESS_NAMES = ("svchost.exe", "lsass.exe", "csrss.exe", "services.exe")
CRITICAL_NAME_TOKENS = ("keylog", "stealer", "rat", "spy", "hook", "inject")
DATACENTER_ORG_TOKENS = ("datacenter", "hosting", "cloud", "digitalocean", "hetzner", "ovh")
KNOWN_CLIENT_APPS = (
    "chrome",
    "msedge",
    "firefox",
    "brave",
    "code",
    "onedrive",
    "dropbox",
    "python",
    "python3",
)
