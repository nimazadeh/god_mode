"""Unit and integration tests for v3.0 HTTP RFC Sentinel Pack (RFC 9110/9111/9112/6585/9421/9530/9651)."""

from pathlib import Path
from httpx import ASGITransport, AsyncClient
import pytest
from engine.event_bus import EventBus
from engine.http_rfc_auditor import HttpRfcAuditor
from engine.rfc_firewall import (
    compute_rfc9530_digest,
    inspect_request_rfc_anomalies,
    sign_rfc9421_response,
    verify_rfc9421_headers,
)
from main import create_app


@pytest.mark.asyncio
async def test_rfc9530_digest_and_rfc9421_signature_roundtrip() -> None:
    """Verify RFC 9530 Repr-Digest (:base64: per RFC 9651) and RFC 9421 HMAC-SHA256 signatures."""
    payload = b'{"status":"ok","rfc":9421}'
    secret = b"god-mode-test-secret"
    digest = compute_rfc9530_digest(payload)
    assert digest.startswith("sha-256=:") and digest.endswith(":")

    sig_input, sig = sign_rfc9421_response(200, digest, secret)
    assert 'sig1=("@status" "repr-digest")' in sig_input
    assert 'alg="hmac-sha256"' in sig_input
    assert sig.startswith("sig1=:") and sig.endswith(":")

    headers = {
        "Repr-Digest": digest,
        "Signature-Input": sig_input,
        "Signature": sig,
    }
    verified = verify_rfc9421_headers(200, payload, headers, secret)
    assert verified["digest_valid"] is True
    assert verified["signature_valid"] is True
    assert verified["rfc9651_structured"] is True


@pytest.mark.asyncio
async def test_rfc9112_smuggling_rfc9110_trace_and_rfc6585_detection() -> None:
    """Verify RFC 9112 CL.TE smuggling, RFC 9110 TRACE, and RFC 6585 431 header flood detection."""
    smuggle = inspect_request_rfc_anomalies(
        "POST",
        "/api/stats",
        [(b"content-length", b"12"), (b"transfer-encoding", b"chunked")],
    )
    assert smuggle is not None
    assert smuggle["rfc"] == "RFC 9112"
    assert smuggle["status_code"] == 400
    assert smuggle["severity"] == "CRITICAL"

    trace_hit = inspect_request_rfc_anomalies("TRACE", "/api/stats", [(b"host", b"localhost")])
    assert trace_hit is not None
    assert trace_hit["rfc"] == "RFC 9110"
    assert trace_hit["status_code"] == 405
    assert trace_hit["severity"] == "HIGH"

    big_val = b"A" * 5000
    flood_hit = inspect_request_rfc_anomalies("GET", "/api/stats", [(b"x-oversized", big_val)])
    assert flood_hit is not None
    assert flood_hit["rfc"] == "RFC 6585"
    assert flood_hit["status_code"] == 431


@pytest.mark.asyncio
async def test_http_rfc_endpoints_auditor_and_probe_simulator(tmp_path: Path) -> None:
    """Verify FastAPI RFC 9421/9530 response headers, /api/http-rfc/audit, and /api/http-rfc/simulate-probe."""
    db_file = tmp_path / "test_rfc.db"
    app = create_app(db_path=str(db_file), start_background=False)
    async with app.router.lifespan_context(app):
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://localhost:8080") as client:
            stats_res = await client.get("/api/stats")
            assert stats_res.status_code == 200
            assert "repr-digest" in stats_res.headers
            assert "signature" in stats_res.headers
            assert "signature-input" in stats_res.headers

            audit_res = await client.post("/api/http-rfc/audit", json={"url": "http://localhost:8080/api/stats"})
            assert audit_res.status_code == 200
            report = audit_res.json()
            assert report["score"] >= 85
            assert report["rfc9530_digest_valid"] is True
            assert report["rfc9421_signature_valid"] is True

            sim_res = await client.post("/api/http-rfc/simulate-probe", json={"probe_type": "smuggling_rfc9112"})
            assert sim_res.status_code == 200
            sim_data = sim_res.json()
            assert sim_data["blocked"] is True
            assert sim_data["rfc"] == "RFC 9112"
            assert sim_data["status_code"] == 400
