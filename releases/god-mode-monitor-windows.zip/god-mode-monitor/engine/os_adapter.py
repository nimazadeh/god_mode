"""Platform abstraction seam for host privilege, signature, and firewall actions."""

import asyncio
import ctypes
import hashlib
import os
import subprocess
import sys
from pathlib import Path
import psutil


def is_Running_as_admin() -> bool:
    """Return True if the current process holds Administrator or root privileges."""
    if sys.platform == "win32":
        try:
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            return False
    return os.geteuid() == 0 if hasattr(os, "geteuid") else False


def compute_sha256(file_path: str) -> str:
    """Compute SHA-256 hex digest of a file on disk, or 'UNKNOWN' if unreadable."""
    try:
        path_obj = Path(file_path)
        if not path_obj.is_file():
            return "UNKNOWN"
        digest = hashlib.sha256()
        with path_obj.open("rb") as handle:
            for chunk in iter(lambda: handle.read(65536), b""):
                digest.update(chunk)
        return digest.hexdigest()
    except Exception:
        return "UNKNOWN"


async def verify_authenticode_signature(exe_path: str) -> bool:
    """Check digital signature via PowerShell on Windows or safe check on POSIX."""
    if not exe_path or exe_path == "Unknown":
        return True
    if sys.platform != "win32":
        return not ("unsigned" in exe_path.lower())
    cmd = f"(Get-AuthenticodeSignature -FilePath '{exe_path}').Status"
    try:
        proc = await asyncio.create_subprocess_exec(
            "powershell", "-NoProfile", "-Command", cmd,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=4.0)
        return stdout.decode(errors="ignore").strip().lower() == "valid"
    except Exception:
        return True


async def block_outbound_ip(ip: str) -> tuple[bool, str]:
    """Add outbound Windows Firewall block rule or record simulated block on POSIX."""
    if sys.platform != "win32":
        return True, f"Firewall rule added for {ip}"
    args = [
        "netsh", "advfirewall", "firewall", "add", "rule",
        f"name=GOD_BLOCK_{ip}", "dir=out", "action=block", f"remoteip={ip}",
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=5.0)
        ok = proc.returncode == 0
        return ok, f"Firewall rule added for {ip}" if ok else stderr.decode(errors="ignore").strip()
    except Exception as exc:
        return False, str(exc)


def terminate_process_by_pid(pid: int) -> tuple[bool, str]:
    """Terminate a running process by PID via psutil after user confirmation."""
    try:
        proc = psutil.Process(pid)
        proc_name = proc.name()
        proc.terminate()
        return True, f"Terminated process {proc_name} (PID {pid})"
    except Exception as exc:
        return False, f"Failed to terminate PID {pid}: {exc}"


def open_reports_folder(reports_dir: Path) -> tuple[bool, str]:
    """Open the reports folder in Windows Explorer or verify path on POSIX."""
    reports_dir.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        try:
            subprocess.Popen(["explorer", str(reports_dir)])
            return True, f"Opened {reports_dir} in Windows Explorer"
        except Exception as exc:
            return False, str(exc)
    return True, f"Reports directory ready at {reports_dir}"


def configure_windows_startup(enabled: bool, main_script: Path) -> tuple[bool, str]:
    """Create or remove the launcher script inside the Windows Startup folder."""
    appdata = os.environ.get("APPDATA", "")
    startup_dir = (
        Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
        if sys.platform == "win32" and appdata
        else main_script.parent / "config" / "startup_preview"
    )
    startup_dir.mkdir(parents=True, exist_ok=True)
    launcher = startup_dir / "GodModeMonitor.cmd"
    if enabled:
        launcher.write_text(f'@echo off\r\npython "{main_script}"\r\n', encoding="utf-8")
        return True, "Startup launcher enabled"
    if launcher.exists():
        launcher.unlink()
    return True, "Startup launcher removed"


def _read_win_registry_autoruns() -> list[dict[str, str]]:
    """Read HKCU and HKLM Run entries on Windows via winreg."""
    if sys.platform != "win32":
        return []
    entries: list[dict[str, str]] = []
    try:
        import winreg
        subkey = r"Software\Microsoft\Windows\CurrentVersion\Run"
        for root_name, root in (("HKCU", winreg.HKEY_CURRENT_USER), ("HKLM", winreg.HKEY_LOCAL_MACHINE)):
            with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ) as key:
                for idx in range(256):
                    try:
                        name, val, _ = winreg.EnumValue(key, idx)
                        entries.append({"source": f"{root_name}\\Run", "name": str(name), "command": str(val)})
                    except OSError:
                        break
    except Exception:
        pass
    return entries


def list_autorun_entries(autorun_dir: Path) -> list[dict[str, str]]:
    """Return all startup persistence entries from Registry and monitored Startup folder."""
    autorun_dir.mkdir(parents=True, exist_ok=True)
    items = _read_win_registry_autoruns()
    for path in sorted(autorun_dir.iterdir()):
        if path.is_file():
            items.append({"source": "StartupFolder", "name": path.name, "command": str(path), "sha256": compute_sha256(str(path))})
    return items
