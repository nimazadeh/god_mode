"""Browser E2E test and screenshot capture for UI Prototype Variants (?variant=A|B) and regression tests."""

import asyncio
from pathlib import Path
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")


@pytest.mark.asyncio
async def test_variant_b_workbench_tabs_do_not_trigger_invalid_mode_and_only_ab_variants():
    """Verify Variant A & B switching, Workbench tab clicking without 'Invalid mode', SVG flags, and Inter font."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

        await page.goto("http://127.0.0.1:8080/?variant=A", wait_until="networkidle")
        await page.wait_for_function("Number(document.getElementById('stat-processes')?.textContent || '0') > 0")
        assert "Variant A" in (await page.locator("#proto-variant-label").text_content() or "")
        await page.screenshot(path=str(SCREENSHOT_DIR / "proto_variant_A_grid.png"))

        await page.click("#proto-next-btn")
        assert "Variant B" in (await page.locator("#proto-variant-label").text_content() or "")
        assert "?variant=B" in page.url

        await page.click('.wb-tab-btn[data-tab="connections"]')
        await asyncio.sleep(0.25)
        toast_text = await page.locator("#toast-container").text_content() or ""
        assert "Invalid mode" not in toast_text, f"Unexpected Invalid mode toast: {toast_text}"

        await page.click('.wb-tab-btn[data-tab="files"]')
        await asyncio.sleep(0.25)
        toast_text = await page.locator("#toast-container").text_content() or ""
        assert "Invalid mode" not in toast_text, f"Unexpected Invalid mode toast: {toast_text}"

        await page.click('.wb-tab-btn[data-tab="processes"]')
        await asyncio.sleep(0.2)
        await page.screenshot(path=str(SCREENSHOT_DIR / "proto_variant_B_soc_split.png"))

        # Clicking next from Variant B should cycle back to Variant A (Variant C removed)
        await page.click("#proto-next-btn")
        assert "Variant A" in (await page.locator("#proto-variant-label").text_content() or "")

        # Verify SVG flags, Inter font, sort indicator, filter counter, and Escape drawer dismissal
        flag_imgs = await page.locator("#country-matrix img.flag-icon").count()
        assert flag_imgs >= 6
        font_family = await page.evaluate("getComputedStyle(document.body).fontFamily")
        assert "Inter" in font_family
        shown_txt = await page.locator("#filter-match-count").text_content() or ""
        assert "SHOWN" in shown_txt
        sorted_th = await page.locator("#processes-table th.th-sorted").count()
        assert sorted_th == 1
        await page.locator("#processes-tbody tr").first.click()
        assert await page.locator("#process-drawer").evaluate("el => !el.classList.contains('hidden')")
        await page.keyboard.press("Escape")
        assert await page.locator("#process-drawer").evaluate("el => el.classList.contains('hidden')")

        await browser.close()

    assert errors == [], f"Browser errors: {errors}"
