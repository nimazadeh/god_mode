"""File integrity guard using SHA-256 baselines and watchdog observers."""

import asyncio
from datetime import datetime
import logging
from pathlib import Path
from typing import Any, Optional
import psutil
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer
from api.schemas import SettingsConfig
from constants import BASE_DIR
from engine.event_bus import EventBus
from engine.os_adapter import compute_sha256
from engine.threat_scorer import score_file_mutation
from storage.db import Database

logger = logging.getLogger("god_mode.file_guard")


class _WatchdogBridge(FileSystemEventHandler):
    """Forwards watchdog filesystem callbacks into the asyncio event loop safely."""

    def __init__(self, loop: asyncio.AbstractEventLoop, guard: "FileGuard") -> None:
        super().__init__()
        self._loop = loop
        self._guard = guard

    def on_any_event(self, event: FileSystemEvent) -> None:
        """Schedule async handling for created, modified, deleted, or moved file events."""
        if event.is_directory:
            return
        ev_type = str(event.event_type).lower()
        if ev_type not in ("created", "modified", "deleted", "moved"):
            return
        src = str(getattr(event, "src_path", ""))
        dest = str(getattr(event, "dest_path", ""))
        self._loop.call_soon_threadsafe(
            lambda: asyncio.create_task(self._guard.handle_fs_event(ev_type, src, dest))
        )


class FileGuard:
    """Computes startup SHA-256 baselines and monitors watched paths for mutations."""

    def __init__(self, event_bus: EventBus, settings: SettingsConfig, db: Database) -> None:
        self.event_bus = event_bus
        self.settings = settings
        self.db = db
        self.latest_files: list[dict[str, Any]] = []
        self._baselines: dict[str, str] = {}
        self._observer: Optional[ Any ] = None

    def resolve_watched_dirs(self) -> list[Path]:
        """Resolve configured watched_paths into existing directories on disk."""
        resolved: list[Path] = []
        for raw in self.settings.watched_paths:
            candidate = Path(raw) if Path(raw).is_absolute() else (BASE_DIR / raw)
            candidate.mkdir(parents=True, exist_ok=True)
            resolved.append(candidate.resolve())
        return resolved

    async def initialize_baselines(self) -> int:
        """Hash every existing file in watched_paths and persist in SQLite."""
        now_iso = datetime.now().isoformat(timespec="seconds")
        dirs = self.resolve_watched_dirs()
        seed_file = dirs[0] / "system_integrity_seed.cfg" if dirs else None
        if seed_file and not seed_file.exists():
            seed_file.write_text("god_mode_baseline=verified\n", encoding="utf-8")
        for folder in dirs:
            for item in folder.rglob("*"):
                if item.is_file():
                    await self._record_baseline_file(item, now_iso)
        return len(self._baselines)

    async def _record_baseline_file(self, item: Path, now_iso: str) -> None:
        """Hash a single baseline file and add it to the initial File Guard list."""
        full = str(item.resolve())
        digest = compute_sha256(full)
        self._baselines[full] = digest
        await self.db.set_file_baseline(full, digest, now_iso)
        entry = {
            "file_path": full, "event_type": "baseline",
            "by_process": "System Baseline", "pid": None,
            "timestamp": now_iso, "old_hash": digest,
            "new_hash": digest, "hash_status": "UNCHANGED",
        }
        self.latest_files = [entry] + [f for f in self.latest_files if f["file_path"] != full]

    def _attribute_process(self, target_path: str) -> tuple[str, Optional[int], str]:
        """Scan open file handles across processes to identify the mutating actor."""
        for proc in psutil.process_iter(attrs=["pid", "name", "exe"]):
            try:
                for fh in proc.open_files():
                    if fh.path == target_path:
                        exe = proc.info.get("exe") or "Unknown"
                        return proc.info.get("name") or "Unknown", proc.pid, exe
            except Exception:
                continue
        return "Unknown Process", None, "Unknown"

    def _compute_hash_status(self, ev_type: str, old_h: str, new_h: str) -> str:
        """Determine UNCHANGED, CHANGED, DELETED, or UNKNOWN status."""
        if ev_type == "deleted":
            return "DELETED"
        if new_h == "UNKNOWN":
            return "UNKNOWN"
        return "CHANGED" if old_h != new_h else "UNCHANGED"

    async def handle_fs_event(self, ev_type: str, src_path: str, dest_path: str = "") -> None:
        """Process a file mutation event, compare SHA-256 to baseline, and emit alert."""
        target = str(Path(dest_path or src_path).resolve())
        old_hash = self._baselines.get(target) or await self.db.get_file_baseline(target) or "NONE"
        new_hash = "DELETED" if ev_type == "deleted" else compute_sha256(target)
        status = self._compute_hash_status(ev_type, old_hash, new_hash)
        proc_name, pid, proc_path = self._attribute_process(target)
        now = datetime.now()
        entry = {
            "file_path": target, "event_type": ev_type, "by_process": proc_name,
            "pid": pid, "timestamp": now.isoformat(timespec="seconds"),
            "old_hash": old_hash, "new_hash": new_hash, "hash_status": status,
        }
        self.latest_files = [entry] + [f for f in self.latest_files if f["file_path"] != target][:99]
        if old_hash == "NONE" and new_hash not in ("DELETED", "UNKNOWN"):
            self._baselines[target] = new_hash
        await self._publish_file_alert(entry, proc_path, now.strftime("%H:%M"))

    async def _publish_file_alert(self, entry: dict[str, Any], proc_path: str, hhmm: str) -> None:
        """Score the file mutation and publish onto the EventBus."""
        sev, a_type, desc = score_file_mutation(
            entry["event_type"], entry["file_path"],
            self.settings.sensitive_hours.start, self.settings.sensitive_hours.end, hhmm,
        )
        await self.event_bus.publish({
            "timestamp": entry["timestamp"], "engine": "FILE", "severity": sev,
            "alert_type": a_type, "process_name": entry["by_process"],
            "process_path": proc_path, "pid": entry["pid"],
            "exe_hash": compute_sha256(proc_path), "remote_ip": None, "country": None,
            "file_path": entry["file_path"], "description": desc,
            "actions_available": ["allow", "ignore"],
        })

    async def run(self) -> None:
        """Initialize baselines and run the watchdog observer until cancelled."""
        await self.initialize_baselines()
        observer = Observer()
        handler = _WatchdogBridge(asyncio.get_running_loop(), self)
        for folder in self.resolve_watched_dirs():
            observer.schedule(handler, str(folder), recursive=True)
        observer.start()
        self._observer = observer
        try:
            while True:
                await asyncio.sleep(1.0)
        finally:
            observer.stop()
