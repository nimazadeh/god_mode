"""Network sentinel engine monitoring outbound inet connections via psutil."""

import asyncio
from datetime import datetime
import logging
from typing import Any
import psutil
from api.schemas import SettingsConfig
from constants import (
    AVG_PACKET_BYTES_ESTIMATE,
    BYTES_PER_MB,
    ENGINE_POLL_INTERVAL_SEC,
)
from engine.event_bus import EventBus
from engine.ip_lookup import IPLookup
from engine.os_adapter import compute_sha256
from engine.threat_scorer import score_network_connection

logger = logging.getLogger("god_mode.network")


class NetworkSentinel:
    """Polls active inet sockets, enriches remote IPs, and scores outbound risks."""

    def __init__(self, event_bus: EventBus, settings: SettingsConfig, ip_lookup: IPLookup) -> None:
        self.event_bus = event_bus
        self.settings = settings
        self.ip_lookup = ip_lookup
        self.latest_connections: list[dict[str, Any]] = []
        self.blocked_ips: set[str] = set()
        self._conn_counts: dict[str, int] = {}
        self._emitted_keys: set[str] = set()
        self._last_bytes_sent: int = psutil.net_io_counters().bytes_sent
        self.outbound_mbps: float = 0.0

    def _update_throughput(self) -> None:
        """Compute rolling outbound network throughput in MB/s."""
        try:
            current = psutil.net_io_counters().bytes_sent
            delta = max(0, current - self._last_bytes_sent)
            self._last_bytes_sent = current
            self.outbound_mbps = round((delta / BYTES_PER_MB) / ENGINE_POLL_INTERVAL_SEC, 2)
        except Exception:
            self.outbound_mbps = 0.0

    def _fallback_socket_owner(self, conn: Any) -> tuple[str, str, str]:
        """Classify sockets whose PID is hidden by OS kernel privilege boundaries."""
        lport = conn.laddr.port if conn.laddr else 0
        rport = conn.raddr.port if conn.raddr else 0
        if self.settings.port in (lport, rport):
            return "python3 (GodMode)", "[Local Server]", "SERVER_SOCKET"
        if getattr(conn, "status", "") in ("TIME_WAIT", "CLOSE_WAIT", "FIN_WAIT2"):
            return "System (TIME_WAIT)", "[Closing Socket]", "KERNEL_SOCKET"
        return "System / Elevated", "[Protected Socket]", "KERNEL_SOCKET"

    def _resolve_pid_meta(self, conn: Any) -> tuple[str, str, str]:
        """Resolve (process_name, exe_path, sha256) for a socket without losing name on AccessDenied."""
        if not conn.pid:
            return self._fallback_socket_owner(conn)
        try:
            proc = psutil.Process(conn.pid)
            name = proc.name() or f"PID-{conn.pid}"
            exe = proc.exe() if hasattr(proc, "exe") else "[System Protected]"
            return name, exe or "[System Protected]", compute_sha256(exe) if exe else "PROTECTED"
        except psutil.AccessDenied:
            return f"System (PID {conn.pid})", "[System Protected]", "PROTECTED"
        except Exception:
            return self._fallback_socket_owner(conn)

    async def _build_conn_entry(self, conn: Any) -> dict[str, Any]:
        """Create an enriched connection record from a psutil socket tuple."""
        remote_ip, remote_port = conn.raddr.ip, conn.raddr.port
        local_addr = f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else "0.0.0.0:0"
        proc_name, proc_path, exe_hash = self._resolve_pid_meta(conn)
        key = f"{proc_name}:{remote_ip}"
        self._conn_counts[key] = self._conn_counts.get(key, 0) + 1
        est_mb = round((self._conn_counts[key] * AVG_PACKET_BYTES_ESTIMATE) / BYTES_PER_MB, 2)
        geo = await self.ip_lookup.lookup(remote_ip)
        return {
            "pid": conn.pid, "process_name": proc_name, "process_path": proc_path,
            "exe_hash": exe_hash, "local_addr": local_addr, "remote_ip": remote_ip,
            "remote_port": remote_port, "country": geo.get("country", "Unknown"),
            "country_code": geo.get("country_code", "UN"), "org": geo.get("org", "Unknown"),
            "isp": geo.get("isp", "Unknown"), "is_hosting": bool(geo.get("is_hosting", False)),
            "data_mb": est_mb, "data_label": f"~{est_mb} MB", "conn_status": conn.status,
        }

    async def _evaluate_connection(self, item: dict[str, Any]) -> None:
        """Assign status badge and publish security event when rules trigger."""
        sev, a_type, desc = score_network_connection(item, self.settings.flagged_countries)
        if item["remote_ip"] in self.blocked_ips:
            item["status_badge"] = "Blocked"
        elif sev in ("WARN", "HIGH", "CRITICAL"):
            item["status_badge"] = "Suspicious"
        else:
            item["status_badge"] = "Clean"
        item["flagged_country"] = item["country_code"] in self.settings.flagged_countries
        dedup = f"{item['process_name']}:{item['remote_ip']}:{a_type}"
        if sev != "INFO" and dedup not in self._emitted_keys:
            self._emitted_keys.add(dedup)
            await self.event_bus.publish(self._to_event(item, sev, a_type, desc))

    def _to_event(self, item: dict[str, Any], sev: str, a_type: str, desc: str) -> dict[str, Any]:
        """Build a normalized network security event payload."""
        return {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "engine": "NETWORK", "severity": sev, "alert_type": a_type,
            "process_name": item["process_name"], "process_path": item["process_path"],
            "pid": item["pid"], "exe_hash": item["exe_hash"],
            "remote_ip": item["remote_ip"], "country": item["country"],
            "file_path": None, "description": desc,
            "actions_available": ["block", "allow", "ignore"],
        }

    def _get_unique_inet_conns(self) -> list[Any]:
        """Return deduplicated active inet socket tuples with remote addresses."""
        unique: list[Any] = []
        seen: set[tuple[str, int, int | None]] = set()
        try:
            for conn in psutil.net_connections(kind="inet"):
                if conn.raddr and conn.raddr.ip:
                    sig = (conn.raddr.ip, conn.raddr.port, conn.pid)
                    if sig not in seen:
                        seen.add(sig)
                        unique.append(conn)
        except Exception:
            logger.exception("Unable to enumerate network connections")
        return unique

    async def scan_once(self) -> list[dict[str, Any]]:
        """Inspect all active outbound inet sockets and return enriched list."""
        self._update_throughput()
        results: list[dict[str, Any]] = []
        for conn in self._get_unique_inet_conns():
            item = await self._build_conn_entry(conn)
            await self._evaluate_connection(item)
            results.append(item)
        self.latest_connections = results
        return results

    async def run(self) -> None:
        """Continuously poll network sockets every ENGINE_POLL_INTERVAL_SEC seconds."""
        while True:
            try:
                await self.scan_once()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("NetworkSentinel scan cycle failed")
            await asyncio.sleep(ENGINE_POLL_INTERVAL_SEC)
