"""PersistenceGuard engine monitoring OS Autoruns and local Listening Ports."""

import asyncio
from datetime import datetime
import hashlib
import logging
from pathlib import Path
from typing import Any
import psutil
from constants import ENGINE_POLL_INTERVAL_SEC, RISKY_BACKDOOR_PORTS, WATCHED_AUTORUNS_DIR
from engine.event_bus import EventBus
from engine.os_adapter import list_autorun_entries

logger = logging.getLogger("god_mode.persistence")


def score_listening_port(entry: dict[str, Any]) -> tuple[str, str, str]:
    """Return (severity, alert_type, description) for a listening TCP/UDP socket."""
    port = int(entry.get("port", 0))
    proc = str(entry.get("process_name", "System"))
    bind_ip = str(entry.get("bind_ip", "127.0.0.1"))
    if port in RISKY_BACKDOOR_PORTS:
        return "CRITICAL", "PORT_BACKDOOR_LISTEN", f"High-risk port {port} listening ({proc} on {bind_ip})"
    if bind_ip in ("0.0.0.0", "::") and port not in (80, 443, 8080):
        return "WARN", "PORT_WILDCARD_LISTEN", f"Wildcard listener on {bind_ip}:{port} ({proc})"
    return "INFO", "PORT_NORMAL_LISTEN", f"Local listener on {bind_ip}:{port} ({proc})"


class PersistenceGuard:
    """Monitors OS startup persistence entries and local LISTEN sockets."""

    def __init__(self, event_bus: EventBus, autorun_dir: Path = WATCHED_AUTORUNS_DIR) -> None:
        self.event_bus = event_bus
        self.autorun_dir = autorun_dir
        self.latest_autoruns: list[dict[str, Any]] = []
        self.latest_listening_ports: list[dict[str, Any]] = []
        self._baseline_sigs: dict[str, str] = {}
        self._emitted_ports: set[str] = set()

    def _entry_digest(self, item: dict[str, str]) -> str:
        """Compute a deterministic fingerprint for an autorun entry."""
        raw = f"{item.get('source')}|{item.get('name')}|{item.get('command')}|{item.get('sha256', '')}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    async def initialize_baseline(self) -> None:
        """Seed initial autorun baseline so existing entries do not false-alert."""
        self.autorun_dir.mkdir(parents=True, exist_ok=True)
        seed = self.autorun_dir / "windows_defender_tray.cmd"
        if not any(self.autorun_dir.iterdir()):
            seed.write_text("@echo off\r\nrem Verified baseline startup item\r\n", encoding="utf-8")
        for entry in list_autorun_entries(self.autorun_dir):
            key = f"{entry['source']}:{entry['name']}"
            self._baseline_sigs[key] = self._entry_digest(entry)

    async def _scan_autoruns(self) -> list[dict[str, Any]]:
        """Compare current autorun entries against baseline and emit alerts on drift."""
        entries = list_autorun_entries(self.autorun_dir)
        enriched: list[dict[str, Any]] = []
        for entry in entries:
            key = f"{entry['source']}:{entry['name']}"
            sig = self._entry_digest(entry)
            is_new = key not in self._baseline_sigs
            is_mod = not is_new and self._baseline_sigs[key] != sig
            status = "NEW" if is_new else ("MODIFIED" if is_mod else "VERIFIED")
            enriched.append({**entry, "status": status})
            if is_new or is_mod:
                self._baseline_sigs[key] = sig
                await self._publish_autorun_alert(entry, status)
        self.latest_autoruns = enriched
        return enriched

    async def _publish_autorun_alert(self, entry: dict[str, str], status: str) -> None:
        """Publish a HIGH/CRITICAL persistence event to EventBus."""
        cmd_path = entry.get("command", "")
        await self.event_bus.publish({
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "engine": "PERSISTENCE",
            "severity": "CRITICAL" if "enc" in cmd_path.lower() or "temp" in cmd_path.lower() else "HIGH",
            "alert_type": f"AUTORUN_{status}",
            "process_name": entry.get("name", "Autorun"),
            "process_path": cmd_path,
            "pid": None,
            "exe_hash": entry.get("sha256", "UNKNOWN"),
            "remote_ip": None,
            "country": None,
            "file_path": cmd_path if Path(cmd_path).is_file() else None,
            "description": f"Startup persistence {status}: {entry.get('name')} ({entry.get('source')})",
            "actions_available": ["quarantine", "allow", "ignore"],
        })

    def _resolve_listener_proc(self, pid: int | None, port: int) -> str:
        """Resolve process name for a listening socket."""
        if not pid:
            return "python3 (GodMode)" if port == 8080 else "System / Kernel"
        try:
            return psutil.Process(pid).name() or f"PID-{pid}"
        except Exception:
            return f"System (PID {pid})"

    async def _scan_listening_ports(self) -> list[dict[str, Any]]:
        """Inspect all local sockets in LISTEN state and score risky backdoor ports."""
        listeners: list[dict[str, Any]] = []
        seen: set[tuple[str, int]] = set()
        try:
            for conn in psutil.net_connections(kind="inet"):
                if getattr(conn, "status", "") != "LISTEN" or not conn.laddr:
                    continue
                sig = (conn.laddr.ip, conn.laddr.port)
                if sig in seen:
                    continue
                seen.add(sig)
                listeners.append(await self._build_listener_item(conn))
        except Exception:
            logger.exception("Failed to scan listening ports")
        self.latest_listening_ports = sorted(listeners, key=lambda x: x["port"])
        return self.latest_listening_ports

    async def _build_listener_item(self, conn: Any) -> dict[str, Any]:
        """Construct and score a single ListeningPort telemetry dictionary."""
        port = int(conn.laddr.port)
        proc_name = self._resolve_listener_proc(conn.pid, port)
        item = {"port": port, "bind_ip": conn.laddr.ip, "pid": conn.pid, "process_name": proc_name}
        sev, a_type, desc = score_listening_port(item)
        item["risk_level"] = sev
        if sev in ("HIGH", "CRITICAL") and f"{port}:{a_type}" not in self._emitted_ports:
            self._emitted_ports.add(f"{port}:{a_type}")
            await self.event_bus.publish({
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "engine": "PERSISTENCE", "severity": sev, "alert_type": a_type,
                "process_name": proc_name, "process_path": "ListeningSocket", "pid": conn.pid,
                "exe_hash": "SOCKET", "remote_ip": None, "country": None, "file_path": None,
                "description": desc, "actions_available": ["kill", "ignore"],
            })
        return item

    async def scan_once(self) -> dict[str, list[dict[str, Any]]]:
        """Run a single scan of autoruns and listening ports."""
        return {
            "autoruns": await self._scan_autoruns(),
            "listening_ports": await self._scan_listening_ports(),
        }

    async def run(self) -> None:
        """Continuously poll autoruns and listening ports."""
        while True:
            try:
                await self.scan_once()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("PersistenceGuard scan failed")
            await asyncio.sleep(ENGINE_POLL_INTERVAL_SEC)
