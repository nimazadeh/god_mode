/* Main application controller: WebSocket lifecycle, state, and clock ticker */
const WS_RECONNECT_MS = 3000;
const WS_MAX_RETRIES = 10;
const MAX_ALERTS_DOM = 200;

window.GodApp = {
  ws: null,
  retries: 0,
  state: { mode: "GUARD", processes: [], connections: [], files: [], alerts: [], uptime: 0 },

  init() {
    try {
      if (window.lucide) window.lucide.createIcons();
      window.GodSound.init(document.getElementById("mute-btn"));
      window.GodCharts.init();
      window.GodCommands.bindSocket(() => this.ws);
      window.GodProto?.init(() => this.rerenderTables());
      window.GodDashboard.bindSortingAndKeyboard(() => this.rerenderTables());
      window.GodShortcuts.init(this);
      this.startClockTicker();
      this.connectWebSocket();
    } catch (err) { console.error("App init error:", err); }
  },
  rerenderTables() {
    window.GodDashboard.renderProcesses(this.state.processes, this.state.alerts);
    window.GodPanels.renderConnections(this.state.connections);
    window.GodPanels.renderFiles(this.state.files);
  },
  connectWebSocket() {
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    this.ws = new WebSocket(`${proto}//${window.location.host}/ws`);
    this.ws.onopen = () => {
      this.retries = 0;
      const el = document.getElementById("conn-status");
      if (el) el.textContent = "LIVE";
    };
    this.ws.onmessage = (ev) => this.handleMessage(JSON.parse(ev.data));
    this.ws.onerror = (err) => console.error("WebSocket error:", err);
    this.ws.onclose = () => this.scheduleReconnect();
  },
  scheduleReconnect() {
    const statusEl = document.getElementById("conn-status");
    if (statusEl) statusEl.textContent = "RECONNECTING...";
    if (this.retries >= WS_MAX_RETRIES) return;
    this.retries += 1;
    setTimeout(() => this.connectWebSocket(), WS_RECONNECT_MS);
  },
  handleMessage(msg) {
    if (msg.type === "state_update") {
      this.state = { ...this.state, ...msg, mode: msg.stats.operation_mode, uptime: msg.stats.uptime_seconds };
      if (msg.settings?.quiet_hours) window.GodSound.quietHours = msg.settings.quiet_hours;
      window.GodDashboard.updateHeaderAndStats(msg.stats);
      window.GodInspector?.renderCountryMatrix(msg.connections);
      this.rerenderTables();
      window.GodAlerts.renderFeed(msg.alerts, MAX_ALERTS_DOM);
      window.GodCharts.pushSample(msg.timestamp, msg.stats.cpu_percent, msg.stats.net_outbound_mbps);
    } else if (msg.type === "new_alert") {
      this.state.alerts.unshift(msg);
      window.GodAlerts.prependAlert(msg, MAX_ALERTS_DOM);
      if (msg.engine === "FILE") window.GodSound.play("FILE_MOD");
      else if (this.state.mode !== "WATCH" && (msg.severity === "HIGH" || msg.severity === "CRITICAL")) {
        window.GodSound.play(msg.severity);
      }
    } else if (msg.type === "command_result") {
      window.GodCommands.showToast(msg.message);
      if (msg.success && msg.action_taken === "block_ip") window.GodSound.play("BLOCK_OK");
    }
  },

  startClockTicker() {
    setInterval(() => {
      this.state.uptime += 1;
      const clockEl = document.getElementById("live-clock");
      const upEl = document.getElementById("uptime-display");
      if (clockEl) clockEl.textContent = new Date().toTimeString().slice(0, 8);
      if (upEl) upEl.textContent = `UP ${String(Math.floor(this.state.uptime / 60)).padStart(2, "0")}:${String(this.state.uptime % 60).padStart(2, "0")}`;
    }, 1000);
  },
};
window.addEventListener("DOMContentLoaded", () => window.GodApp.init());
