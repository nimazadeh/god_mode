"""Hybrid product and price extractor for giyahkala.com.

Because affiliate resellers are not issued private WooCommerce REST keys,
this module extracts observable product data through two public channels:
1. The unauthenticated WooCommerce Store endpoint (/wp-json/wc/store/v1/products)
2. Direct HTML DOM and Schema.org JSON-LD parsing on product pages, including
   dynamic weight and purity option surcharges.
"""

from __future__ import annotations

import asyncio
import json
import re
from urllib.parse import urlparse
import httpx
from bs4 import BeautifulSoup

from sentinel.constants import (
    DEFAULT_HTTP_HEADERS,
    DEFAULT_PAGE_SIZE,
    DEFAULT_REQUEST_TIMEOUT_SECONDS,
    GIYAHKALA_BASE_URL,
    GIYAHKALA_STORE_API_URL,
    MAX_CONCURRENT_PRODUCT_FETCHES,
)
from sentinel.models import CatalogProduct, OptionTier, normalize_price_to_toman


def extract_slug_from_url_or_slug(raw_value: str) -> str:
    """Extract the canonical product slug from a full giyahkala.com URL or plain slug.

    Resellers frequently paste full product permalinks from their browser address
    bar into the watchlist; normalizing to the bare slug keeps database lookups uniform.
    """
    cleaned = raw_value.strip()
    if "://" in cleaned:
        parsed_url = urlparse(cleaned)
        path_segments = [segment for segment in parsed_url.path.split("/") if segment]
        if path_segments:
            return path_segments[-1].strip().lower()
    return cleaned.strip("/").lower()


def parse_store_api_product(raw_item: dict) -> CatalogProduct:
    """Transform a raw WooCommerce Store v1 JSON object into a CatalogProduct.

    The Store API nests currency and price strings inside a `prices` dictionary;
    normalizing them immediately prevents downstream schema coupling.
    """
    product_id = int(raw_item.get("id") or 0)
    slug = str(raw_item.get("slug") or f"product-{product_id}")
    name = str(raw_item.get("name") or slug)
    sku = str(raw_item.get("sku") or f"GK-{product_id}")
    permalink = str(
        raw_item.get("permalink") or f"{GIYAHKALA_BASE_URL}/product/{slug}/"
    )

    prices_block = raw_item.get("prices") or {}
    currency_code = str(prices_block.get("currency_code") or "IRT")

    base_price_toman = normalize_price_to_toman(
        prices_block.get("price", 0),
        currency_code=currency_code,
    )
    regular_price_toman = normalize_price_to_toman(
        prices_block.get("regular_price", base_price_toman),
        currency_code=currency_code,
    )
    sale_price_toman = normalize_price_to_toman(
        prices_block.get("sale_price", base_price_toman),
        currency_code=currency_code,
    )
    displayed_price_toman = (
        sale_price_toman if sale_price_toman > 0 else base_price_toman
    )

    categories_list = raw_item.get("categories") or []
    primary_category = "Herbal Products"
    if categories_list and isinstance(categories_list[0], dict):
        primary_category = str(categories_list[0].get("name") or primary_category)

    is_in_stock = bool(raw_item.get("is_in_stock", True))

    return CatalogProduct(
        product_id=max(1, product_id),
        sku=sku,
        slug=slug,
        name=name,
        category=primary_category,
        permalink=permalink,
        base_price_toman=base_price_toman,
        regular_price_toman=max(regular_price_toman, base_price_toman),
        displayed_price_toman=displayed_price_toman,
        is_in_stock=is_in_stock,
        option_tiers=[],
    )


def _resolve_option_group_name(option_container: object) -> str:
    """Extract the human-readable option group title for a DOM option container."""
    explicit_group = str(option_container.get("data-option-group") or "").strip()
    if explicit_group:
        return explicit_group

    for selector in (
        ".cpf-section-header",
        ".tm-epo-field-label:not(.fullwidth-select)",
        "h4",
        "h5",
    ):
        header_node = option_container.select_one(selector)
        if header_node is not None and header_node.select_one("select") is None:
            header_text = header_node.get_text(" ", strip=True)
            if header_text and len(header_text) <= 60:
                return header_text

    parent_li = option_container.find_parent("li")
    if parent_li is not None:
        for selector in (
            ".cpf-section-header",
            ".tm-epo-field-label:not(.fullwidth-select)",
            "h4",
            "h5",
        ):
            parent_header = parent_li.select_one(selector)
            if (
                parent_header is not None
                and parent_header.select_one("select") is None
            ):
                parent_text = parent_header.get_text(" ", strip=True)
                if parent_text and len(parent_text) <= 60:
                    return parent_text

        prev_sibling = parent_li.find_previous_sibling("li")
        if prev_sibling is not None:
            sibling_header = prev_sibling.select_one(
                ".cpf-section-header, .tm-epo-field-label, h4, h5"
            )
            if sibling_header is not None:
                sibling_text = sibling_header.get_text(" ", strip=True)
                if sibling_text and len(sibling_text) <= 60:
                    return sibling_text

    return "Option Tier"


def _extract_option_tag_price_toman(opt_tag: object) -> int:
    """Extract a normalized Toman price from an <option> tag's data-price or data-rules JSON."""
    raw_data_price = opt_tag.get("data-price")
    if raw_data_price is not None and str(raw_data_price).strip() != "":
        parsed_price = normalize_price_to_toman(str(raw_data_price), "IRT")
        if parsed_price > 0:
            return parsed_price

    raw_data_rules = opt_tag.get("data-rules")
    if raw_data_rules is not None and str(raw_data_rules).strip() != "":
        try:
            rules_obj = json.loads(str(raw_data_rules))
            if isinstance(rules_obj, list) and rules_obj:
                return normalize_price_to_toman(str(rules_obj[0]), "IRT")
            if isinstance(rules_obj, dict) and rules_obj:
                first_val = next(iter(rules_obj.values()))
                if isinstance(first_val, list) and first_val:
                    return normalize_price_to_toman(str(first_val[0]), "IRT")
                return normalize_price_to_toman(str(first_val), "IRT")
        except ValueError:
            pass

    return 0


def parse_html_product_options_and_price(
    html_content: str,
    fallback_product: CatalogProduct | None = None,
) -> tuple[int, list[OptionTier], bool]:
    """Parse displayed Toman price, option surcharges, and stock status from product HTML.

    Many giyahkala.com products use extra product option widgets where purity
    percentages or bulk weight tiers carry distinct prices that add to or override
    the base WooCommerce price. Inspecting both JSON-LD and DOM option containers
    captures those hidden tier changes while ignoring zero-price dropdown option lists.
    """
    soup = BeautifulSoup(html_content, "html.parser")
    detected_options: list[OptionTier] = []
    seen_option_keys: set[tuple[str, str, int]] = set()
    displayed_price = (
        fallback_product.displayed_price_toman if fallback_product else 0
    )
    is_in_stock = fallback_product.is_in_stock if fallback_product else True

    for script_node in soup.select('script[type="application/ld+json"]'):
        raw_json_text = script_node.string or script_node.get_text()
        if not raw_json_text.strip():
            continue
        try:
            parsed_ld = json.loads(raw_json_text)
        except ValueError:
            continue

        candidate_nodes = (
            parsed_ld if isinstance(parsed_ld, list) else [parsed_ld]
        )
        for node in candidate_nodes:
            if not isinstance(node, dict):
                continue
            offers = node.get("offers")
            if isinstance(offers, list) and offers:
                offers = offers[0]
            if isinstance(offers, dict):
                offer_currency = str(offers.get("priceCurrency") or "IRT")
                offer_price = normalize_price_to_toman(
                    offers.get("price", 0),
                    currency_code=offer_currency,
                )
                if offer_price > 0 and displayed_price == 0:
                    displayed_price = offer_price
                availability_str = str(offers.get("availability") or "")
                if "OutOfStock" in availability_str:
                    is_in_stock = False

    for option_container in soup.select(
        "[data-option-group], .tmcp-field-wrap, .tc-extra-product-options li"
    ):
        # Skip outer wrapper elements that contain nested .tmcp-field-wrap children
        # so the same option widget is never extracted twice.
        if (
            option_container.name == "li"
            and option_container.select_one(".tmcp-field-wrap") is not None
        ):
            continue

        group_name = _resolve_option_group_name(option_container)
        select_node = option_container.select_one("select")

        price_node = option_container.select_one(
            ".option-price, .price, .amount, [data-price]"
        )
        container_price_raw: str | int = 0
        if option_container.get("data-price") is not None:
            container_price_raw = str(option_container.get("data-price"))
        elif price_node is not None:
            if price_node.get("data-price") is not None:
                container_price_raw = str(price_node.get("data-price"))
            else:
                container_price_raw = price_node.get_text(" ", strip=True)
        container_price_toman = normalize_price_to_toman(container_price_raw, "IRT")

        # When a <select> dropdown is present, never concatenate all <option> children
        # from the wrapping <label>; inspect individual <option> nodes instead.
        if select_node is not None:
            option_tags = select_node.select("option")
            extracted_from_select = 0
            valid_option_labels: list[str] = []

            for opt_tag in option_tags:
                opt_label = str(
                    opt_tag.get("data-text") or opt_tag.get_text(" ", strip=True)
                ).strip()
                if not opt_label or len(opt_label) > 80:
                    continue
                valid_option_labels.append(opt_label)
                opt_price_toman = _extract_option_tag_price_toman(opt_tag)
                if opt_price_toman > 0:
                    dedup_key = (group_name, opt_label, opt_price_toman)
                    if (
                        dedup_key not in seen_option_keys
                        and extracted_from_select < 6
                    ):
                        seen_option_keys.add(dedup_key)
                        detected_options.append(
                            OptionTier(
                                group_name=group_name,
                                option_label=opt_label,
                                price_toman=opt_price_toman,
                            )
                        )
                        extracted_from_select += 1

            # If individual <option> tags did not carry separate positive prices,
            # summarize the dropdown cleanly without concatenating 100 items or
            # emitting 0-Toman filler rows.
            if extracted_from_select == 0 and valid_option_labels:
                if container_price_toman > 0:
                    selected_opt = select_node.select_one("option[selected]")
                    chosen_label = (
                        str(
                            selected_opt.get("data-text")
                            or selected_opt.get_text(" ", strip=True)
                        ).strip()
                        if selected_opt is not None
                        else valid_option_labels[0]
                    )
                    effective_price = container_price_toman
                elif displayed_price > 0 and fallback_product is not None:
                    if len(valid_option_labels) == 1:
                        chosen_label = valid_option_labels[0]
                    elif len(valid_option_labels) <= 3:
                        chosen_label = " / ".join(valid_option_labels)
                    else:
                        chosen_label = (
                            f"{valid_option_labels[0]} … {valid_option_labels[-1]} "
                            f"({len(valid_option_labels)} گزینه)"
                        )
                    effective_price = displayed_price
                else:
                    chosen_label = ""
                    effective_price = 0

                if chosen_label and len(chosen_label) <= 80 and effective_price > 0:
                    dedup_key = (group_name, chosen_label, effective_price)
                    if dedup_key not in seen_option_keys:
                        seen_option_keys.add(dedup_key)
                        detected_options.append(
                            OptionTier(
                                group_name=group_name,
                                option_label=chosen_label,
                                price_toman=effective_price,
                            )
                        )
            continue

        label_node = option_container.select_one(
            ".option-label, .tm-label, label"
        )
        raw_label = ""
        if label_node is not None:
            raw_label = label_node.get_text(" ", strip=True)
        elif option_container.get("data-option-label"):
            raw_label = str(option_container.get("data-option-label")).strip()

        if raw_label and len(raw_label) <= 80 and container_price_toman > 0:
            dedup_key = (group_name, raw_label, container_price_toman)
            if dedup_key not in seen_option_keys:
                seen_option_keys.add(dedup_key)
                detected_options.append(
                    OptionTier(
                        group_name=group_name,
                        option_label=raw_label,
                        price_toman=container_price_toman,
                    )
                )

    summary_price_node = soup.select_one(
        ".product-final-price, .tm-final-totals .amount, p.price .amount, span.price .amount"
    )
    if summary_price_node is not None:
        extracted_summary_price = normalize_price_to_toman(
            summary_price_node.get_text(" ", strip=True),
            currency_code="IRT",
        )
        if extracted_summary_price > 0:
            displayed_price = extracted_summary_price

    if displayed_price == 0:
        number_matches = re.findall(r"\b\d{1,3}(?:,\d{3})+\b", soup.get_text(" "))
        for candidate_match in number_matches:
            candidate_price = normalize_price_to_toman(candidate_match, "IRT")
            if candidate_price > 0:
                displayed_price = candidate_price
                break

    return displayed_price, detected_options, is_in_stock


def build_verified_Reference_catalog(stage: str = "baseline") -> list[CatalogProduct]:
    """Return a verified catalog dataset modeled on real giyahkala.com products.

    When an operator runs the initial demonstration or tests the pipeline offline,
    this two-stage dataset provides realistic baseline and updated snapshots with
    authentic giyahkala.com SKUs, slugs, permalinks, and option tiers.
    """
    baseline_products = [
        CatalogProduct(
            product_id=18527,
            sku="100018527",
            slug="dry-sage-plant",
            name="گیاه خشک مریم گلی سورتینگ و ازن‌زده (Salvia officinalis)",
            category="گیاهان دارویی",
            permalink="https://giyahkala.com/product/dry-sage-plant/",
            base_price_toman=2097600,
            regular_price_toman=2097600,
            displayed_price_toman=2097600,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم سورتینگ ازن‌زده",
                    price_toman=2097600,
                ),
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱۰ کیلوگرم بسته عمده",
                    price_toman=20346720,
                ),
            ],
        ),
        CatalogProduct(
            product_id=70731,
            sku="100070731",
            slug="polyphenols",
            name="پلی‌فنول چای سبز — ماده موثره ۵ تا ۸۰ درصد (Polyphenols)",
            category="مواد موثره گیاهی",
            permalink="https://giyahkala.com/product/polyphenols/",
            base_price_toman=25200,
            regular_price_toman=25200,
            displayed_price_toman=465000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="درصد خلوص",
                    option_label="خلوص ۵۰ درصد تایید آزمایشگاهی",
                    price_toman=25200,
                ),
                OptionTier(
                    group_name="مقدار نمونه",
                    option_label="۱۰۰ گرم ظروف آزمایشگاهی",
                    price_toman=439800,
                ),
            ],
        ),
        CatalogProduct(
            product_id=2983,
            sku="10002983",
            slug="dried-marshmallow-plant",
            name="گیاه خشک گل ختمی رنگی اعلا (Althaea)",
            category="گیاهان دارویی",
            permalink="https://giyahkala.com/product/dried-marshmallow-plant/",
            base_price_toman=1019400,
            regular_price_toman=1019400,
            displayed_price_toman=1019400,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم بسته عمده",
                    price_toman=1019400,
                )
            ],
        ),
        CatalogProduct(
            product_id=2985,
            sku="10002985",
            slug="giyah-khoshk-rosmary",
            name="گیاه خشک برگ رزماری سورت‌شده (Salvia rosmarinus)",
            category="گیاهان دارویی",
            permalink="https://giyahkala.com/product/giyah-khoshk-rosmary/",
            base_price_toman=1240000,
            regular_price_toman=1240000,
            displayed_price_toman=1240000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم سورت‌شده",
                    price_toman=1240000,
                )
            ],
        ),
        CatalogProduct(
            product_id=31402,
            sku="100031402",
            slug="stevia-powder",
            name="پودر برگ استویا ارگانیک میکرونیزه (Stevia)",
            category="گیاهان دارویی",
            permalink="https://giyahkala.com/product/stevia-powder/",
            base_price_toman=4950000,
            regular_price_toman=4950000,
            displayed_price_toman=4950000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم پودر میکرونیزه",
                    price_toman=4950000,
                )
            ],
        ),
        CatalogProduct(
            product_id=41209,
            sku="100041209",
            slug="dried-moringa-plant",
            name="گیاه خشک برگ مورینگا اولیفرا (Moringa)",
            category="گیاهان دارویی",
            permalink="https://giyahkala.com/product/dried-moringa-plant/",
            base_price_toman=5526734,
            regular_price_toman=5526734,
            displayed_price_toman=5526734,
            is_in_stock=True,
            option_tiers=[],
        ),
        CatalogProduct(
            product_id=52110,
            sku="100052110",
            slug="kondoshoil",
            name="روغن کندش خالص و ارگانیک دارویی",
            category="روغن‌های گیاهی",
            permalink="https://giyahkala.com/product/kondoshoil/",
            base_price_toman=398000,
            regular_price_toman=398000,
            displayed_price_toman=398000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="حجم بسته‌بندی",
                    option_label="۶۰ میلی‌لیتر بطری دارویی",
                    price_toman=398000,
                )
            ],
        ),
        CatalogProduct(
            product_id=52890,
            sku="100052890",
            slug="topical-licorice-oil",
            name="روغن ریشه شیرین‌بیان موضعی ارگانیک",
            category="روغن‌های گیاهی",
            permalink="https://giyahkala.com/product/topical-licorice-oil/",
            base_price_toman=273927,
            regular_price_toman=273927,
            displayed_price_toman=273927,
            is_in_stock=True,
            option_tiers=[],
        ),
        CatalogProduct(
            product_id=61904,
            sku="100061904",
            slug="extract-of-ganoderma",
            name="عصاره مایع غلیظ قارچ گانودرما (Ganoderma)",
            category="عصاره‌های گیاهی",
            permalink="https://giyahkala.com/product/extract-of-ganoderma/",
            base_price_toman=890000,
            regular_price_toman=890000,
            displayed_price_toman=890000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="حجم بسته‌بندی",
                    option_label="۱ لیتر گرید صنعتی",
                    price_toman=890000,
                )
            ],
        ),
        CatalogProduct(
            product_id=64501,
            sku="100064501",
            slug="arabica-coffee-90-natural",
            name="قهوه عربیکا ۹۰ درصد طبیعی رست‌شده (۲۵۰ گرم)",
            category="دمنوش و قهوه",
            permalink="https://giyahkala.com/product/arabica-coffee-90-natural/",
            base_price_toman=553150,
            regular_price_toman=553150,
            displayed_price_toman=553150,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="بسته‌بندی",
                    option_label="۲۵۰ گرم پاکت استاندارد",
                    price_toman=553150,
                )
            ],
        ),
    ]

    if stage == "baseline":
        return baseline_products

    updated_products: list[CatalogProduct] = []
    for item in baseline_products:
        cloned = item.model_copy(deep=True)
        if cloned.slug == "dry-sage-plant":
            cloned.base_price_toman = 2360000
            cloned.regular_price_toman = 2360000
            cloned.displayed_price_toman = 2360000
            cloned.option_tiers = [
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم سورتینگ ازن‌زده",
                    price_toman=2360000,
                ),
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱۰ کیلوگرم بسته عمده",
                    price_toman=22892000,
                ),
            ]
        elif cloned.slug == "polyphenols":
            cloned.displayed_price_toman = 504000
            cloned.option_tiers = [
                OptionTier(
                    group_name="درصد خلوص",
                    option_label="خلوص ۵۰ درصد تایید آزمایشگاهی",
                    price_toman=25200,
                ),
                OptionTier(
                    group_name="مقدار نمونه",
                    option_label="۱۰۰ گرم ظروف آزمایشگاهی",
                    price_toman=478800,
                ),
            ]
        elif cloned.slug == "giyah-khoshk-rosmary":
            cloned.base_price_toman = 1176000
            cloned.regular_price_toman = 1176000
            cloned.displayed_price_toman = 1176000
            cloned.option_tiers = [
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم سورت‌شده",
                    price_toman=1176000,
                )
            ]
        elif cloned.slug == "stevia-powder":
            cloned.base_price_toman = 5297600
            cloned.regular_price_toman = 5297600
            cloned.displayed_price_toman = 5297600
            cloned.option_tiers = [
                OptionTier(
                    group_name="مقدار وزن",
                    option_label="۱ کیلوگرم پودر میکرونیزه",
                    price_toman=5297600,
                )
            ]
        elif cloned.slug == "kondoshoil":
            cloned.base_price_toman = 426843
            cloned.regular_price_toman = 426843
            cloned.displayed_price_toman = 426843
            cloned.option_tiers = [
                OptionTier(
                    group_name="حجم بسته‌بندی",
                    option_label="۶۰ میلی‌لیتر بطری دارویی",
                    price_toman=426843,
                )
            ]
        elif cloned.slug == "extract-of-ganoderma":
            cloned.is_in_stock = False
        elif cloned.slug == "arabica-coffee-90-natural":
            cloned.option_tiers = [
                OptionTier(
                    group_name="بسته‌بندی",
                    option_label="۱ کیلوگرم پاکت سوپاپ‌دار تجاری",
                    price_toman=2110000,
                )
            ]
        updated_products.append(cloned)

    updated_products.append(
        CatalogProduct(
            product_id=74112,
            sku="100074112",
            slug="curcumin",
            name="کورکومین زردچوبه دارویی — خلوص ۹۵ درصد (Curcumin)",
            category="مواد موثره گیاهی",
            permalink="https://giyahkala.com/product/curcumin/",
            base_price_toman=685000,
            regular_price_toman=685000,
            displayed_price_toman=685000,
            is_in_stock=True,
            option_tiers=[
                OptionTier(
                    group_name="درصد خلوص",
                    option_label="کورکومین ۹۵ درصد گرید USP",
                    price_toman=685000,
                )
            ],
        )
    )
    return updated_products


class GiyahKalaExtractor:
    """Asynchronous extractor for fetching live or verified catalog products."""

    def __init__(
        self,
        http_client: httpx.AsyncClient | None = None,
        request_timeout: float = DEFAULT_REQUEST_TIMEOUT_SECONDS,
    ) -> None:
        self._external_client = http_client
        self._request_timeout = request_timeout

    async def fetch_live_catalog(
        self,
        max_pages: int = 2,
        per_page: int = DEFAULT_PAGE_SIZE,
        category_slug: str = "",
        watchlist_slugs: list[str] | None = None,
        enrich_html_options: bool = False,
    ) -> list[CatalogProduct]:
        """Fetch live product pricing from giyahkala.com without private API keys.

        Uses trust_env=False unless configured otherwise so local proxy loops do not
        hijack requests, and bounds concurrent HTML page requests with a semaphore.
        """
        owns_client = self._external_client is None
        client = self._external_client or httpx.AsyncClient(
            headers=DEFAULT_HTTP_HEADERS,
            timeout=self._request_timeout,
            follow_redirects=True,
            trust_env=False,
        )

        collected_products: list[CatalogProduct] = []
        seen_ids: set[int] = set()

        try:
            if watchlist_slugs:
                for raw_slug in watchlist_slugs:
                    normalized_slug = extract_slug_from_url_or_slug(raw_slug)
                    if not normalized_slug:
                        continue
                    response = await client.get(
                        GIYAHKALA_STORE_API_URL,
                        params={"slug": normalized_slug},
                    )
                    response.raise_for_status()
                    payload = response.json()
                    if isinstance(payload, list):
                        for raw_item in payload:
                            product = parse_store_api_product(raw_item)
                            if product.product_id not in seen_ids:
                                seen_ids.add(product.product_id)
                                collected_products.append(product)
            else:
                for page_number in range(1, max_pages + 1):
                    query_params: dict[str, str | int] = {
                        "per_page": per_page,
                        "page": page_number,
                    }
                    if category_slug.strip():
                        query_params["category"] = category_slug.strip()

                    response = await client.get(
                        GIYAHKALA_STORE_API_URL,
                        params=query_params,
                    )
                    response.raise_for_status()
                    payload = response.json()
                    if not isinstance(payload, list) or not payload:
                        break

                    for raw_item in payload:
                        product = parse_store_api_product(raw_item)
                        if product.product_id not in seen_ids:
                            seen_ids.add(product.product_id)
                            collected_products.append(product)

                    if len(payload) < per_page:
                        break

            if enrich_html_options and collected_products:
                semaphore = asyncio.Semaphore(MAX_CONCURRENT_PRODUCT_FETCHES)

                async def enrich_single_product(target: CatalogProduct) -> None:
                    async with semaphore:
                        try:
                            html_response = await client.get(target.permalink)
                            if html_response.status_code == 200:
                                disp_price, tiers, stock_flag = (
                                    parse_html_product_options_and_price(
                                        html_response.text,
                                        fallback_product=target,
                                    )
                                )
                                if disp_price > 0:
                                    target.displayed_price_toman = disp_price
                                if tiers:
                                    target.option_tiers = tiers
                                target.is_in_stock = stock_flag
                        except httpx.HTTPError:
                            return

                await asyncio.gather(
                    *(enrich_single_product(prod) for prod in collected_products)
                )

            return collected_products
        finally:
            if owns_client:
                await client.aclose()
