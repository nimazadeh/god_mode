# PRODUCT.md — God Mode Monitor

## 1. Product Purpose & Operating Context
**God Mode Monitor** is a real-time, zero-cloud endpoint security operations dashboard running on `localhost` (`127.0.0.1:8080`). It fuses live process telemetry (`psutil`), outbound socket & geolocation attribution (`ip-api.com` cached in SQLite), and SHA-256 critical file integrity monitoring (`watchdog`) into a unified operator command center.

## 2. Audience & Surface Mode
- **Primary Audience**: Security operators, incident responders, and power users inspecting live endpoint behavior under active or suspected threat conditions.
- **Impeccable Visitor Mode**: **`Operate`** (`skills/design/impeccable/reference/operate.md`).
  - Scanability, tabular numeric alignment (`tabular-nums`), deterministic state vocabulary, keyboard-first workflows (`[P] [N] [F] [A] [R] [S]` + `← / →`), and sub-250ms transitions outrank decorative flourish.
  - The interface disappears into the task while honoring the pinned dark/red tactical security brief.

## 3. Core Capabilities & Invariants
- **Three Operation Postures**:
  - `WATCH`: Passive telemetry and visual alerts without destructive actions or `INFO` audio.
  - `GUARD` *(Default)*: Active threat scoring (`INFO`, `WARN`, `HIGH`, `CRITICAL`) with Web Audio alerts and operator-confirmed process termination (`Kill`) and 3-tuple SHA-256 `AllowlistRule` creation.
  - `WAR`: Elevated incident response posture with pulsing header indicator and operator-confirmed outbound IP firewall blocking (`Block IP`).
- **Two Switchable Structural Variants (`/prototype`)**:
  - `Variant A`: Tactical Command Grid (5 simultaneous telemetry panels).
  - `Variant B`: SOC Incident Split + Full-Height Tabbed Workbench (`[1: PROCESSES]`, `[2: NETWORK]`, `[3: FILE GUARD]`).
- **Hard Guardrails**:
  - 100% English codebase and UI; zero external cloud telemetry; all colors isolated in `dashboard/css/variables.css`; zero `!important`; `textContent`-only DOM rendering; Python files <= 200 lines (functions <= 20 lines); JS files <= 80 lines.
