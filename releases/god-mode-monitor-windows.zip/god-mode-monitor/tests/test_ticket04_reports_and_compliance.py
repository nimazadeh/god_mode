"""TDD and structural compliance tests for Ticket 04: Reports, Packaging, and Hygiene."""

import ast
from pathlib import Path
import re
import pytest
from constants import BASE_DIR
from storage.db import Database
from storage.report_generator import ReportGenerator

REQUIRED_DELIVERABLES = (
    "requirements.txt",
    "setup.bat",
    "build.bat",
    "config/settings.json",
    "engine/event_bus.py",
    "engine/ip_lookup.py",
    "engine/threat_scorer.py",
    "engine/process_watcher.py",
    "engine/network_sentinel.py",
    "engine/file_guard.py",
    "storage/db.py",
    "storage/models.py",
    "storage/report_generator.py",
    "api/schemas.py",
    "api/websocket.py",
    "api/routes.py",
    "main.py",
    "dashboard/css/variables.css",
    "dashboard/css/layout.css",
    "dashboard/css/components.css",
    "dashboard/css/animations.css",
    "dashboard/js/sound.js",
    "dashboard/js/commands.js",
    "dashboard/js/alerts.js",
    "dashboard/js/charts.js",
    "dashboard/js/dashboard.js",
    "dashboard/js/app.js",
    "dashboard/index.html",
)


@pytest.mark.asyncio
async def test_daily_html_report_generation_and_all_eight_sections(tmp_path: Path):
    db = Database(str(tmp_path / "rep.db"))
    await db.initialize()
    try:
        await db.insert_event({
            "timestamp": "2026-10-16T03:15:00",
            "engine": "NETWORK",
            "severity": "CRITICAL",
            "process_name": "svchost.exe",
            "process_path": "C:\\Temp\\svchost.exe",
            "remote_ip": "185.220.101.5",
            "country": "Russia",
            "file_path": None,
            "description": "Outbound traffic to flagged country",
            "action_taken": "BLOCKED",
            "confirmed_by": "user",
        })
        gen = ReportGenerator(db, tmp_path / "reports")
        report_file = await gen.generate_for_date("2026-10-16")
        assert report_file.exists()
        html = report_file.read_text(encoding="utf-8")
        assert "#0D0D0D" in html and "#FF2222" in html
        for heading in (
            "God Mode Monitor — Daily Security Report",
            "Hour-by-Hour Timeline (24h)",
            "Top 5 Suspicious Processes",
            "Top 5 Foreign IPs Contacted",
            "File Integrity Events",
            "Actions Taken",
            "Periods Not Monitored",
        ):
            assert heading in html
    finally:
        await db.close()


def test_all_28_deliverables_exist_and_non_empty():
    for rel_path in REQUIRED_DELIVERABLES:
        full = BASE_DIR / rel_path
        assert full.is_file(), f"Missing deliverable: {rel_path}"
        assert full.stat().st_size > 0, f"Empty deliverable: {rel_path}"


def test_python_file_and_function_line_limits():
    py_files = [
        p for p in BASE_DIR.rglob("*.py")
        if "tests" not in p.parts and "venv" not in p.parts
    ]
    assert len(py_files) >= 12
    for py_file in py_files:
        lines = py_file.read_text(encoding="utf-8").splitlines()
        assert len(lines) <= 200, f"{py_file.name} has {len(lines)} lines (>200)"
        tree = ast.parse("\n".join(lines), filename=str(py_file))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                span = (node.end_lineno or node.lineno) - node.lineno + 1
                assert span <= 20, f"{py_file.name}:{node.name} is {span} lines (>20)"


def test_javascript_file_line_limits_and_no_unsafe_apis():
    js_dir = BASE_DIR / "dashboard" / "js"
    js_files = [p for p in js_dir.glob("*.js")]
    assert len(js_files) >= 6
    for js_file in js_files:
        text = js_file.read_text(encoding="utf-8")
        lines = text.splitlines()
        assert len(lines) <= 80, f"{js_file.name} has {len(lines)} lines (>80)"
        assert "innerHTML" not in text, f"innerHTML forbidden in {js_file.name}"
        assert "eval(" not in text and "Function(" not in text


def test_css_colors_only_in_variables_and_no_important():
    css_dir = BASE_DIR / "dashboard" / "css"
    color_re = re.compile(r"(#[0-9a-fA-F]{3,8}\b|\brgba?\(|\bhsla?\()")
    for css_file in css_dir.glob("*.css"):
        text = css_file.read_text(encoding="utf-8")
        assert "!important" not in text, f"!important found in {css_file.name}"
        if css_file.name != "variables.css":
            match = color_re.search(text)
            assert match is None, f"Hardcoded color {match.group(0)} in {css_file.name}"


def test_zero_persian_or_farsi_characters_in_codebase():
    persian_re = re.compile(r"[\u0600-\u06FF]")
    for path in BASE_DIR.rglob("*"):
        if not path.is_file() or "venv" in path.parts or path.suffix in (".db", ".png", ".pyc", ".woff2"):
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        assert persian_re.search(text) is None, f"Non-English/Persian character found in {path}"


def test_windows_bat_files_crlf_and_safe_parentheses():
    """Retro guardrail: prevent cmd.exe '... was unexpected at this time' and LF batch bugs."""
    for bat_path in BASE_DIR.glob("*.bat"):
        raw = bat_path.read_bytes()
        assert b"\r\n" in raw, f"{bat_path.name} must use Windows CRLF line endings"
        in_block = False
        for line in raw.decode("utf-8").splitlines():
            stripped = line.strip()
            if stripped.endswith("("):
                in_block = True
            elif stripped == ")":
                in_block = False
            elif in_block and stripped.lower().startswith("echo "):
                assert ")" not in stripped or "^)" in stripped, (
                    f"Unescaped ')' inside parenthesized echo in {bat_path.name}: {stripped}"
                )


def test_mode_btn_selectors_qualified_and_variant_c_removed():
    """Retro guardrail: prevent .mode-btn selector collision with .wb-tab-btn and ensure Variant C teardown."""
    for js_path in (BASE_DIR / "dashboard" / "js").glob("*.js"):
        text = js_path.read_text(encoding="utf-8")
        assert 'querySelectorAll(".mode-btn")' not in text, f"Unqualified .mode-btn selector in {js_path.name}"
        assert "variant-c" not in text, f"Leftover variant-c reference in {js_path.name}"
