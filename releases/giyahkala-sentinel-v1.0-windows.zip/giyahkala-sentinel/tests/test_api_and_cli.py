"""Integration tests for the FastAPI endpoints and CLI one-shot execution."""

from __future__ import annotations

from pathlib import Path
import httpx
import pytest

from main import run_cli_one_shot
from sentinel.api import create_app


@pytest.mark.asyncio
async def test_fastapi_endpoints_and_scan_workflow(tmp_path: Path) -> None:
    """Verify health, diff, on-demand scan, watchlist, baseline sync, and CSV routes."""
    db_path = tmp_path / "api_test.db"
    app = create_app(database_path=db_path)
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://testserver",
    ) as client:
        health_res = await client.get("/api/health")
        assert health_res.status_code == 200
        health_data = health_res.json()
        assert health_data["status"] == "ok"
        assert health_data["snapshot_count"] == 2

        diff_res = await client.get("/api/diff?changed_only=true")
        assert diff_res.status_code == 200
        diff_data = diff_res.json()
        assert diff_data["summary"]["total_changed"] == 8
        assert len(diff_data["items"]) == 8

        watch_res = await client.post(
            "/api/watchlist",
            json={"slug_or_url": "https://giyahkala.com/product/polyphenols/"},
        )
        assert watch_res.status_code == 200
        assert watch_res.json()["added"]["slug"] == "polyphenols"

        scan_res = await client.post(
            "/api/scan",
            json={
                "mode": "verified_catalog",
                "watchlist_only": True,
                "note": "Targeted watchlist scan",
            },
        )
        assert scan_res.status_code == 200
        scan_payload = scan_res.json()
        assert scan_payload["summary"]["total_compared"] == 1
        assert scan_payload["items"][0]["slug"] == "polyphenols"

        csv_res = await client.get("/api/export.csv?changed_only=true")
        assert csv_res.status_code == 200
        assert "polyphenols" in csv_res.text

        latest_id = scan_payload["current_snapshot_id"]
        sync_res = await client.post(f"/api/baseline/{latest_id}")
        assert sync_res.status_code == 200
        assert sync_res.json()["baseline_snapshot_id"] == latest_id


@pytest.mark.asyncio
async def test_api_export_csv_respects_custom_snapshot_ids(tmp_path: Path) -> None:
    """Verify /api/export.csv honors custom baseline_id and current_id query parameters."""
    db_path = tmp_path / "csv_snapshots_test.db"
    app = create_app(database_path=db_path)
    transport = httpx.ASGITransport(app=app)

    async with httpx.AsyncClient(
        transport=transport,
        base_url="http://testserver",
    ) as client:
        same_snapshot_csv = await client.get(
            "/api/export.csv?changed_only=true&baseline_id=1&current_id=1"
        )
        assert same_snapshot_csv.status_code == 200
        non_empty_lines = [
            line
            for line in same_snapshot_csv.text.strip().splitlines()
            if line.strip()
        ]
        assert len(non_empty_lines) == 1
        assert "Product ID" in non_empty_lines[0]


@pytest.mark.asyncio
async def test_cli_one_shot_creates_csv_export(tmp_path: Path) -> None:

    """Verify CLI --scan-once mode runs a comparison and writes the CSV file."""
    db_path = tmp_path / "cli_test.db"
    csv_path = tmp_path / "exported_changes.csv"
    exit_code = await run_cli_one_shot(
        database_path=db_path,
        mode="verified_catalog",
        output_csv=csv_path,
    )
    assert exit_code == 0
    assert csv_path.exists()
    content = csv_path.read_text(encoding="utf-8")
    assert "dry-sage-plant" in content
