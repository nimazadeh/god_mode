@echo off
setlocal enabledelayedexpansion
title God Mode Monitor - PyInstaller Builder

echo [1/3] Activating virtual environment...
if not exist "venv\Scripts\activate.bat" (
    echo [ERROR] venv not found. Please run setup.bat first.
    exit /b 1
)
call venv\Scripts\activate.bat
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to activate virtual environment.
    exit /b 1
)

echo [2/3] Ensuring PyInstaller is installed...
pip install pyinstaller
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Failed to install PyInstaller.
    exit /b 1
)

echo [3/3] Packaging standalone executable dist\god_mode.exe...
pyinstaller --onefile --add-data "dashboard;dashboard" --add-data "config;config" --name god_mode main.py
if %ERRORLEVEL% neq 0 (
    echo [ERROR] PyInstaller build failed.
    exit /b 1
)

echo.
echo ✅ Build complete: dist\god_mode.exe
exit /b 0
