/* v3.0 HTTP RFC Sentinel Inspector: RFC 9110/9111/9112/6585/9421/9530/9651 */
window.GodRfc = {
  init() {
    const byId = (id) => document.getElementById(id);
    byId("rfc-open-btn")?.addEventListener("click", () => this.toggleDrawer());
    byId("close-rfc-drawer")?.addEventListener("click", () => this.toggleDrawer(false));
    byId("rfc-scan-btn")?.addEventListener("click", () => this.scanUrl());
    document.querySelectorAll("[data-rfc-probe]").forEach((btn) => {
      btn.addEventListener("click", () => this.runProbe(btn.dataset.rfcProbe));
    });
  },

  toggleDrawer(forceOpen) {
    const el = document.getElementById("rfc-drawer");
    if (!el) return;
    const show = typeof forceOpen === "boolean" ? forceOpen : el.classList.contains("hidden");
    el.classList.toggle("hidden", !show);
    if (show) this.refresh();
  },

  async refresh() {
    try {
      const res = await fetch("/api/http-rfc");
      const digest = res.headers.get("repr-digest") || "";
      const sig = res.headers.get("signature") || "";
      const badge = document.getElementById("rfc-crypto-status");
      if (badge) {
        const ok = digest.startsWith("sha-256=:") && sig.startsWith("sig1=:");
        badge.textContent = ok ? `VERIFIED • RFC 9530 ${digest.slice(0, 22)}... • RFC 9421 HMAC-SHA256` : "UNSIGNED";
      }
      const data = await res.json();
      this.renderAudits(data.audits || []);
      this.renderFirewallLog(data.firewall_log || []);
    } catch (err) { console.error("HTTP RFC fetch error:", err); }
  },

  renderAudits(audits) {
    const tbody = document.getElementById("rfc-audits-tbody");
    if (!tbody) return;
    tbody.textContent = "";
    audits.forEach((a) => {
      const tr = document.createElement("tr");
      if (a.score < 70) tr.className = "row-critical";
      else if (a.score < 90) tr.className = "row-suspicious";
      const dTag = a.rfc9530_digest_valid ? "RFC9530 OK" : "UNSIGNED";
      const sTag = a.rfc9421_signature_valid ? "RFC9421 OK" : "UNSIGNED";
      [a.url, `${a.http_version} (${a.status_code})`, `${a.score}/100 (${a.grade})`, a.cache_control, `${dTag} / ${sTag}`].forEach((v) => window.GodPanels.appendCell(tr, v));
      tbody.appendChild(tr);
    });
  },

  renderFirewallLog(logs) {
    const tbody = document.getElementById("rfc-firewall-tbody");
    if (!tbody) return;
    tbody.textContent = "";
    logs.forEach((item) => {
      const tr = document.createElement("tr");
      tr.className = item.severity === "CRITICAL" ? "row-critical" : "row-suspicious";
      [item.timestamp || "-", `${item.rfc} (${item.section})`, item.method, item.status_code, item.title].forEach((v) => window.GodPanels.appendCell(tr, v));
      tbody.appendChild(tr);
    });
  },

  async scanUrl() {
    const input = document.getElementById("rfc-audit-url-input");
    const url = (input?.value || "http://localhost:8080/api/stats").trim();
    const res = await fetch("/api/http-rfc/audit", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url }) });
    const out = await res.json();
    window.GodCommands.showToast(`RFC Audit ${out.url}: ${out.score}/100 (${out.grade})`);
    this.refresh();
  },

  async runProbe(probeType) {
    const res = await fetch("/api/http-rfc/simulate-probe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ probe_type: probeType }) });
    const out = await res.json();
    window.GodCommands.showToast(`[BLOCKED ${out.status_code}] ${out.rfc}: ${out.title}`);
    this.refresh();
  },
};
window.addEventListener("DOMContentLoaded", () => window.GodRfc.init());
