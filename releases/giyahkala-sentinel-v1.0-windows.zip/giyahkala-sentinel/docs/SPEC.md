# GiyahKala Price Sentinel — Technical Specification

## Problem Statement

Affiliate resellers who list `giyahkala.com` herbal, extract, essential oil, and bulk botanical products on their own online stores have no automated way to detect when the source supplier changes product prices, modifies weight/purity option surcharges, or marks items out of stock. Manual checking across thousands of products is slow and error-prone, causing resellers to sell products below replacement cost whenever source prices rise unnoticed.

## Solution

An on-demand price monitoring web application and CLI utility (`GiyahKala Price Sentinel`) that fetches observable product prices and option tiers from `giyahkala.com` without requiring private API credentials, compares the newly captured `CatalogSnapshot` against the stored `BaselineSnapshot` in a local SQLite database, displays only products whose prices or availability changed in a clean Linear Light-Mode interface, and exports ready-to-import CSV reports.

## User Stories

1. As an affiliate reseller, I want to trigger an on-demand scan of `giyahkala.com` at any time with a single click, so that I can inspect all price changes before fulfilling orders or updating my store.
2. As an affiliate reseller, I want the default view to display only products whose price, option tiers, or stock status have changed since the last baseline, so that I do not waste time scrolling through unchanged products.
3. As an affiliate reseller, I want to see the previous price, current price, exact Toman difference, and percentage change for every modified product, so that I can immediately prioritize high-impact price increases.
4. As an affiliate reseller, I want the scanner to detect changes in product option surcharges (such as bulk weight tiers and extract purity percentages) in addition to the displayed base price, so that multi-option products never cause hidden margin loss.
5. As an affiliate reseller, I want to filter changed products by change category (`All Changes`, `Price Increased`, `Price Decreased`, `Option / Stock Changed`, `New Products`, or `All Tracked`), so that I can process urgent price increases first.
6. As an affiliate reseller, I want to search across monitored products by SKU, slug, product name, or category in real time, so that I can verify any specific item in milliseconds.
7. As an affiliate reseller, I want to add specific product URLs or slugs to a custom Watchlist or select specific product categories to scan, so that I can run rapid targeted checks on the exact products I carry.
8. As an affiliate reseller, I want to lock and advance the `BaselineSnapshot` only when I click "Sync Baseline", so that running multiple checks before updating my store never loses track of pending changes.
9. As an affiliate reseller, I want to compare any two historical `CatalogSnapshot` runs, so that I can audit supplier price trends over time.
10. As an affiliate reseller, I want to export the filtered `DiffReport` to a clean, Excel-compatible CSV file with one click, so that I can bulk-update prices in my own e-commerce platform.

## Implementation Decisions

- **Single Responsibility Module Decomposition**:
  - `models`: Immutable domain models (`CatalogProduct`, `OptionTier`, `CatalogSnapshot`, `PriceDelta`, `DiffReport`) and currency normalization helpers (converting `IRR` to `IRT` Toman consistently).
  - `extractor`: Hybrid 3-phase scraper combining public WooCommerce Store JSON pagination, HTML DOM option-tier parsing, and a verified offline/demo catalog seed for instant repeatable verification.
  - `diff_engine`: Pure functional comparison engine that pairs records by canonical `product_id` or `slug`, computes base and option-tier price deltas, and produces summary metrics.
  - `storage`: Local SQLite repository using WAL mode to persist snapshots, product rows, and watchlists without external database servers.
  - `exporter`: RFC 4180 CSV generator with UTF-8 BOM support for seamless opening in Microsoft Excel.
  - `service` & `api`: Application orchestration layer and FastAPI HTTP routes serving both the JSON API and the static Linear Light-Mode web interface.
- **Linear Light-Mode UI Architecture**:
  - Crisp neutral surfaces (`#F7F8F9` canvas, `#FFFFFF` elevated panels), `1px solid #EAECEF` structural borders, self-hosted `Inter` and `Geist` fonts with `font-variant-numeric: tabular-nums`, semantic status pills, keyboard shortcuts (`/` search, `s` scan, `e` export), and batched `DocumentFragment` rendering.

## Testing Decisions

- **External Behavior Verification at Clean Seams**:
  - Unit and integration tests exercise the public interfaces of `extractor`, `diff_engine`, `storage`, `exporter`, and the FastAPI application.
  - Code hygiene tests scan the entire project directory to guarantee 100% English source files, zero unsafe DOM tokens, zero forced CSS specificity overrides, and safe Windows `.bat` launcher syntax.
  - End-to-end Playwright Chromium tests verify rendered accessibility landmarks, computed Light-Mode tokens, interactive on-demand scan execution, diff filtering, baseline synchronization, and zero `undefined` or `NaN` values in the rendered DOM.

## Out of Scope

- Automated modification of the reseller's external storefront database (the tool outputs the exact diff report and Excel/CSV export for safe storefront import).
- Paid third-party CAPTCHA solving services.
