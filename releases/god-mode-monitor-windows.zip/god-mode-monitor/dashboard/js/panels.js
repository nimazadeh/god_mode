/* Connection Table and File Guard Table DOM renderers with Windows-safe SVG flags */
const STATUS_BADGES = {
  Clean: { text: "✅ Clean", cls: "badge badge-clean" },
  Suspicious: { text: "⚠️ Suspicious", cls: "badge badge-warn" },
  Blocked: { text: "🔴 Blocked", cls: "badge badge-critical" },
};

const HASH_LABELS = { UNCHANGED: "UNCHANGED ✅", CHANGED: "CHANGED 🔴", DELETED: "DELETED 💀", UNKNOWN: "UNKNOWN ❓" };

window.GodPanels = {
  appendRow(container, text) {
    const row = document.createElement("div");
    row.className = "alert-row";
    row.textContent = text;
    container.appendChild(row);
  },

  appendCell(tr, text) {
    const td = document.createElement("td");
    td.textContent = text == null ? "Unknown" : String(text);
    tr.appendChild(td);
    return td;
  },

  renderConnections(connections) {
    const tbody = document.getElementById("connections-tbody");
    if (!tbody) return;
    tbody.textContent = "";
    const filtered = window.GodInspector
      ? window.GodInspector.filterList(connections, (c) => `${c.process_name} ${c.remote_ip} ${c.country} ${c.isp}`, (c) => c.status_badge !== "Clean")
      : (connections || []);
    filtered.forEach((conn) => {
      const tr = document.createElement("tr");
      tr.tabIndex = 0;
      if (conn.flagged_country || conn.status_badge === "Blocked") tr.className = "row-critical";
      else if (conn.status_badge === "Suspicious") tr.className = "row-suspicious";
      this.appendCell(tr, conn.process_name);
      this.appendCell(tr, `${conn.remote_ip}:${conn.remote_port}`);
      const countryTd = document.createElement("td");
      if (window.GodInspector) countryTd.appendChild(window.GodInspector.createFlagIcon(conn.country_code));
      countryTd.appendChild(document.createTextNode(conn.country || "Unknown"));
      tr.appendChild(countryTd);
      this.appendCell(tr, conn.isp || conn.org || "Unknown");
      this.appendCell(tr, conn.data_label || "~0.0 MB");
      const statusTd = document.createElement("td");
      const badgeSpec = STATUS_BADGES[conn.status_badge] || STATUS_BADGES.Clean;
      const badge = document.createElement("span");
      badge.className = badgeSpec.cls;
      badge.textContent = badgeSpec.text;
      statusTd.appendChild(badge);
      tr.appendChild(statusTd);
      tbody.appendChild(tr);
    });
  },

  renderFiles(files) {
    const tbody = document.getElementById("files-tbody");
    if (!tbody) return;
    tbody.textContent = "";
    (files || []).forEach((file) => {
      const tr = document.createElement("tr");
      tr.tabIndex = 0;
      if (file.hash_status === "CHANGED" || file.hash_status === "DELETED") tr.className = "row-critical";
      this.appendCell(tr, file.file_path);
      this.appendCell(tr, file.event_type);
      this.appendCell(tr, file.by_process);
      this.appendCell(tr, (file.timestamp || "").slice(11, 19) || file.timestamp);
      this.appendCell(tr, HASH_LABELS[file.hash_status] || HASH_LABELS.UNKNOWN);
      tr.addEventListener("click", () => window.GodModals.showFileDiff(file));
      tbody.appendChild(tr);
    });
  },
};
