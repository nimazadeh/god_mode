"""Application-wide constants for GiyahKala Price Sentinel.

Keeping URLs, rate limits, and schema defaults in one module enforces DRY
and prevents configuration drift between the CLI, HTTP API, and extractor.
"""

SENTINEL_VERSION = "1.0.0"
APP_TITLE = "GiyahKala Price Sentinel"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8090

GIYAHKALA_BASE_URL = "https://giyahkala.com"
GIYAHKALA_STORE_API_URL = "https://giyahkala.com/wp-json/wc/store/v1/products"
GIYAHKALA_SITEMAP_INDEX_URL = "https://giyahkala.com/sitemap_index.xml"

# Browser-grade headers prevent false-positive bot rejection by upstream WAF rules.
DEFAULT_HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json,text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
}

DEFAULT_REQUEST_TIMEOUT_SECONDS = 15.0
DEFAULT_PAGE_SIZE = 50
MAX_CONCURRENT_PRODUCT_FETCHES = 4
