"""Application orchestration service for GiyahKala Price Sentinel.

Coordinates extraction, snapshot persistence, baseline management, and diff
computation behind a single clean interface used by both FastAPI and the CLI.
"""

from __future__ import annotations

from pathlib import Path
import httpx

from sentinel.diff_engine import compute_catalog_diff
from sentinel.exporter import export_diff_report_to_csv
from sentinel.extractor import (
    GiyahKalaExtractor,
    build_verified_Reference_catalog,
)
from sentinel.models import (
    CatalogProduct,
    CatalogSnapshot,
    DiffReport,
    ScanRequest,
)
from sentinel.storage import SnapshotRepository


class PriceSentinelService:
    """High-level service managing on-demand price scans and diff reports."""

    def __init__(
        self,
        database_path: str | Path,
        extractor: GiyahKalaExtractor | None = None,
        seed_initial_data: bool = True,
    ) -> None:
        self.repository = SnapshotRepository(database_path)
        self.extractor = extractor or GiyahKalaExtractor()
        if seed_initial_data:
            self.ensure_initial_snapshots()

    def ensure_initial_snapshots(self) -> None:
        """Seed baseline and initial comparison snapshots when the database is empty.

        Having an initial baseline and comparison scan ready on first launch lets
        the reseller immediately inspect how changed products are surfaced before
        running their own live or watchlist scans.
        """
        existing_headers = self.repository.list_snapshot_headers()
        if existing_headers:
            return

        baseline_products = build_verified_Reference_catalog("baseline")
        self.repository.save_snapshot(
            products=baseline_products,
            source_mode="verified_catalog",
            note="Initial reference baseline from giyahkala.com catalog",
            mark_as_baseline=True,
        )

        current_products = build_verified_Reference_catalog("current")
        self.repository.save_snapshot(
            products=current_products,
            source_mode="verified_catalog",
            note="On-demand catalog check against baseline",
            mark_as_baseline=False,
        )

    async def execute_on_demand_scan(
        self,
        scan_request: ScanRequest,
    ) -> DiffReport:
        """Execute an on-demand catalog scan, store the snapshot, and compute the diff."""
        watchlist_slugs: list[str] = []
        if scan_request.watchlist_only:
            watchlist_items = self.repository.list_watchlist_items()
            watchlist_slugs = [str(item["slug"]) for item in watchlist_items]

        fetched_products: list[CatalogProduct] = []
        effective_source_mode = "live"

        if scan_request.mode == "verified_catalog":
            fetched_products = build_verified_Reference_catalog("current")
            effective_source_mode = "verified_catalog"
        else:
            try:
                fetched_products = await self.extractor.fetch_live_catalog(
                    max_pages=scan_request.max_pages,
                    per_page=scan_request.per_page,
                    category_slug=scan_request.category_slug,
                    watchlist_slugs=watchlist_slugs if watchlist_slugs else None,
                    enrich_html_options=scan_request.enrich_html_options,
                )
            except (httpx.HTTPError, OSError):
                if scan_request.mode == "live":
                    raise
                fetched_products = []

            if not fetched_products:
                fetched_products = build_verified_Reference_catalog("current")
                effective_source_mode = "verified_catalog"

        if watchlist_slugs and effective_source_mode == "verified_catalog":
            allowed_slugs = set(watchlist_slugs)
            filtered = [
                prod for prod in fetched_products if prod.slug in allowed_slugs
            ]
            if filtered:
                fetched_products = filtered

        if scan_request.category_slug.strip() and effective_source_mode == "verified_catalog":
            category_query = scan_request.category_slug.strip().lower()
            filtered_by_cat = [
                prod
                for prod in fetched_products
                if category_query in prod.category.lower()
                or category_query in prod.slug.lower()
            ]
            if filtered_by_cat:
                fetched_products = filtered_by_cat

        scan_note = (
            scan_request.note.strip()
            or f"On-demand scan ({effective_source_mode})"
        )
        new_snapshot = self.repository.save_snapshot(
            products=fetched_products,
            source_mode=effective_source_mode,
            note=scan_note,
            mark_as_baseline=False,
        )

        baseline_snapshot = self.repository.get_baseline_snapshot()
        if baseline_snapshot is None:
            baseline_snapshot = new_snapshot

        return compute_catalog_diff(
            baseline_snapshot=baseline_snapshot,
            current_snapshot=new_snapshot,
            changed_only=False,
        )

    def get_current_diff_report(
        self,
        changed_only: bool = False,
        baseline_id: int | None = None,
        current_id: int | None = None,
    ) -> DiffReport:
        """Compute the diff report between the active baseline and latest snapshot."""
        self.ensure_initial_snapshots()

        baseline_snapshot = (
            self.repository.get_snapshot(baseline_id)
            if baseline_id is not None
            else self.repository.get_baseline_snapshot()
        )
        current_snapshot = (
            self.repository.get_snapshot(current_id)
            if current_id is not None
            else self.repository.get_latest_snapshot()
        )

        if baseline_snapshot is None or current_snapshot is None:
            raise ValueError("No catalog snapshots available for comparison.")

        return compute_catalog_diff(
            baseline_snapshot=baseline_snapshot,
            current_snapshot=current_snapshot,
            changed_only=changed_only,
        )

    def get_health_status(self, version: str) -> dict:
        """Return service health metadata and active snapshot identifiers."""
        snapshots = self.repository.list_snapshot_headers()
        baseline = self.repository.get_baseline_snapshot()
        latest = self.repository.get_latest_snapshot()
        return {
            "status": "ok",
            "version": version,
            "snapshot_count": len(snapshots),
            "baseline_snapshot_id": baseline.snapshot_id if baseline else None,
            "latest_snapshot_id": latest.snapshot_id if latest else None,
        }

    def list_snapshots(self) -> list[dict]:
        """List lightweight headers for all saved catalog snapshots."""
        return self.repository.list_snapshot_headers()

    def list_watchlist(self) -> list[dict]:
        """Return all monitored watchlist items."""
        return self.repository.list_watchlist_items()

    def add_watchlist_item(self, slug_or_url: str, label: str = "") -> dict:
        """Add a product URL or slug to the monitored watchlist and return updated state."""
        added = self.repository.add_watchlist_item(
            slug_or_url=slug_or_url,
            label=label,
        )
        return {
            "added": added,
            "items": self.repository.list_watchlist_items(),
        }

    def remove_watchlist_item(self, slug: str) -> dict:
        """Remove a product slug from the watchlist and return updated state."""
        removed = self.repository.remove_watchlist_item(slug)
        return {
            "removed": removed,
            "items": self.repository.list_watchlist_items(),
        }

    def sync_baseline_to_snapshot(self, snapshot_id: int) -> CatalogSnapshot:
        """Advance the active baseline pointer to the specified snapshot ID."""
        updated_baseline = self.repository.set_baseline_snapshot(snapshot_id)
        if updated_baseline is None:
            raise ValueError(f"Snapshot #{snapshot_id} was not found.")
        return updated_baseline

    def export_current_diff_csv(
        self,
        changed_only: bool = True,
        baseline_id: int | None = None,
        current_id: int | None = None,
    ) -> str:
        """Generate an Excel-compatible CSV string for the selected snapshot comparison."""
        report = self.get_current_diff_report(
            changed_only=changed_only,
            baseline_id=baseline_id,
            current_id=current_id,
        )
        return export_diff_report_to_csv(report, include_utf8_bom=True)

