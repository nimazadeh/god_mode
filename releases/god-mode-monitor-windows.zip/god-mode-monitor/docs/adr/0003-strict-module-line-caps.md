# Enforce strict line caps via cohesive sub-module decomposition

Every Python file is capped at 200 lines (20 lines per function) and every JavaScript file is capped at 80 lines, while preserving the 28 canonical file paths required by the project specification. Canonical files act as public module facades and delegate specialized rendering, modal workflows, and OS operations to focused sibling modules (`constants.py`, `engine/os_adapter.py`, `dashboard/js/panels.js`, `dashboard/js/modals.js`).
