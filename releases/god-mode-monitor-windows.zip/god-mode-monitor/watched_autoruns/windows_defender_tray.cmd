@echo off
rem Verified baseline startup item
