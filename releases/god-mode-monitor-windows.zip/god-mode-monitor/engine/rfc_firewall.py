"""HTTP RFC 9110/9112/6585 protocol firewall and RFC 9421/9530/9651 message signer."""

import base64
from datetime import datetime
import hashlib
import hmac
import re
import time
from typing import Any, Callable, Optional
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from constants import (
    RFC_MAX_SINGLE_HEADER_BYTES,
    RFC_MAX_TOTAL_HEADERS_BYTES,
    RFC_SIGNING_SECRET,
)


def compute_rfc9530_digest(body: bytes) -> str:
    """Compute an RFC 9530 Repr-Digest header formatted as an RFC 9651 Byte Sequence."""
    b64_digest = base64.b64encode(hashlib.sha256(body).digest()).decode("ascii")
    return f"sha-256=:{b64_digest}:"


def _build_rfc9421_base(status: int, repr_digest: str, created: int) -> tuple[str, bytes]:
    """Construct the RFC 9421 Signature-Input value and canonical signature base."""
    sig_params = f'("@status" "repr-digest");created={created};alg="hmac-sha256";keyid="god-mode-local"'
    base_str = f'"@status": {status}\n"repr-digest": {repr_digest}\n"@signature-params": {sig_params}'
    return f"sig1={sig_params}", base_str.encode("utf-8")


def sign_rfc9421_response(
    status: int, repr_digest: str, secret: bytes = RFC_SIGNING_SECRET, created: Optional[int] = None
) -> tuple[str, str]:
    """Generate RFC 9421 Signature-Input and HMAC-SHA256 Signature headers."""
    ts = created if created is not None else int(time.time())
    sig_input, sig_base = _build_rfc9421_base(status, repr_digest, ts)
    mac = hmac.new(secret, sig_base, hashlib.sha256).digest()
    b64_sig = base64.b64encode(mac).decode("ascii")
    return sig_input, f"sig1=:{b64_sig}:"


def verify_rfc9421_headers(
    status: int, body: bytes, headers: dict[str, str], secret: bytes = RFC_SIGNING_SECRET
) -> dict[str, Any]:
    """Verify RFC 9530 Repr-Digest and RFC 9421 Signature headers on an HTTP response."""
    norm = {k.lower(): v for k, v in headers.items()}
    actual_digest, sig_input, actual_sig = norm.get("repr-digest", ""), norm.get("signature-input", ""), norm.get("signature", "")
    m = re.search(r"created=(\d+)", sig_input)
    _, expected_sig = sign_rfc9421_response(status, actual_digest, secret, created=int(m.group(1)) if m else 0)
    digest_ok = hmac.compare_digest(actual_digest, compute_rfc9530_digest(body))
    sig_ok = bool(actual_sig) and hmac.compare_digest(actual_sig, expected_sig)
    return {
        "digest_valid": digest_ok, "signature_valid": sig_ok,
        "rfc9651_structured": actual_digest.startswith("sha-256=:") and actual_sig.startswith("sig1=:"),
        "repr_digest": actual_digest, "signature_input": sig_input, "signature": actual_sig,
    }


def _check_smuggling_rfc9112(raw_headers: list[tuple[bytes, bytes]]) -> Optional[dict[str, Any]]:
    """Detect RFC 9112 Section 6.3 CL.TE request smuggling or duplicate Content-Length headers."""
    names = [k.decode("latin1", errors="ignore").lower() for k, _ in raw_headers]
    if (names.count("content-length") and "transfer-encoding" in names) or names.count("content-length") > 1 or "x-rfc-smuggle-probe" in names:
        return {
            "rfc": "RFC 9112", "section": "Section 6.3", "status_code": 400,
            "severity": "CRITICAL", "title": "RFC 9112 CL.TE HTTP Request Smuggling Attempt Blocked",
        }
    return None


def inspect_request_rfc_anomalies(
    method: str, path: str, raw_headers: list[tuple[bytes, bytes]]
) -> Optional[dict[str, Any]]:
    """Inspect an incoming HTTP request against RFC 9112, RFC 9110, and RFC 6585 rules."""
    smuggle = _check_smuggling_rfc9112(raw_headers)
    if smuggle:
        return {**smuggle, "path": path, "method": method}
    if method.upper() == "TRACE":
        return {"rfc": "RFC 9110", "section": "Section 9.3.8", "status_code": 405, "severity": "HIGH", "path": path, "method": method, "title": "RFC 9110 Unsafe TRACE Reflection Method Blocked"}
    total_len = sum(len(k) + len(v) for k, v in raw_headers)
    max_single = max((len(k) + len(v) for k, v in raw_headers), default=0)
    if max_single > RFC_MAX_SINGLE_HEADER_BYTES or total_len > RFC_MAX_TOTAL_HEADERS_BYTES:
        return {"rfc": "RFC 6585", "section": "Section 5", "status_code": 431, "severity": "HIGH", "path": path, "method": method, "title": "RFC 6585 431 Oversized Header Field Flood Blocked"}
    return None


async def emit_rfc_firewall_event(state: dict[str, Any], finding: dict[str, Any]) -> dict[str, Any]:
    """Publish an RFC protocol violation event to EventBus and record it in firewall history."""
    ev = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "engine": "NETWORK",
        "severity": finding["severity"],
        "process_name": f"HTTP/{finding['rfc']}",
        "process_path": finding.get("path", "/"),
        "description": f"[{finding['rfc']} {finding['section']}] {finding['title']} ({finding['method']} {finding['path']})",
        "actions_available": ["ignore"],
    }
    state.setdefault("rfc_firewall_log", []).insert(0, {**finding, "timestamp": ev["timestamp"]})
    await state["event_bus"].publish(ev)
    return ev


async def _rfc_middleware_dispatch(request: Request, call_next: Callable[[Request], Any]) -> Response:
    """Enforce RFC 9112/9110/6585 request rules and sign responses per RFC 9421/9530."""
    raw_headers = list(request.scope.get("headers", []))
    finding = inspect_request_rfc_anomalies(request.method, request.url.path, raw_headers)
    if finding is not None:
        await emit_rfc_firewall_event(request.app.state.monitor, finding)
        return JSONResponse({"detail": finding["title"], "rfc": finding["rfc"]}, status_code=finding["status_code"])
    response = await call_next(request)
    if request.url.path.startswith("/api/"):
        body = b"".join([chunk async for chunk in response.body_iterator])
        digest = compute_rfc9530_digest(body)
        sig_in, sig = sign_rfc9421_response(response.status_code, digest)
        headers = dict(response.headers)
        headers.update({"Repr-Digest": digest, "Signature-Input": sig_in, "Signature": sig, "Cache-Control": "no-store"})
        return Response(content=body, status_code=response.status_code, headers=headers, media_type=response.media_type)
    return response


def attach_rfc_security_middleware(app: FastAPI) -> None:
    """Attach the RFC 9112/9421/9530 HTTP middleware to the FastAPI application."""
    app.middleware("http")(_rfc_middleware_dispatch)
