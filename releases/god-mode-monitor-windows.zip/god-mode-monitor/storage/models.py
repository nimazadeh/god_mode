"""SQLite schema definitions and parameterized SQL statements."""

SCHEMA_STATEMENTS = (
    """
    CREATE TABLE IF NOT EXISTS events (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp    TEXT    NOT NULL,
      engine       TEXT    NOT NULL,
      severity     TEXT    NOT NULL,
      process_name TEXT,
      process_path TEXT,
      remote_ip    TEXT,
      country      TEXT,
      file_path    TEXT,
      description  TEXT    NOT NULL,
      action_taken TEXT,
      confirmed_by TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS ip_cache (
      ip           TEXT PRIMARY KEY,
      country      TEXT,
      country_code TEXT,
      org          TEXT,
      isp          TEXT,
      is_hosting   INTEGER,
      fetched_at   TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS allowlist (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      process_path TEXT NOT NULL,
      exe_hash     TEXT NOT NULL,
      alert_type   TEXT NOT NULL,
      added_at     TEXT NOT NULL,
      expires_at   TEXT,
      note         TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS daily_stats (
      date              TEXT PRIMARY KEY,
      total_events      INTEGER,
      critical_count    INTEGER,
      high_count        INTEGER,
      warn_count        INTEGER,
      info_count        INTEGER,
      actions_taken     INTEGER,
      monitoring_uptime TEXT
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS file_baselines (
      file_path   TEXT PRIMARY KEY,
      sha256_hash TEXT NOT NULL,
      updated_at  TEXT NOT NULL
    );
    """,
    """
    CREATE TABLE IF NOT EXISTS quarantine_items (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      original_path  TEXT NOT NULL,
      vault_path     TEXT NOT NULL,
      sha256_hash    TEXT NOT NULL,
      reason         TEXT NOT NULL,
      quarantined_at TEXT NOT NULL,
      status         TEXT NOT NULL
    );
    """,
)

INSERT_EVENT_SQL = """
INSERT INTO events (
  timestamp, engine, severity, process_name, process_path,
  remote_ip, country, file_path, description, action_taken, confirmed_by
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""

SELECT_RECENT_EVENTS_SQL = """
SELECT id, timestamp, engine, severity, process_name, process_path,
       remote_ip, country, file_path, description, action_taken, confirmed_by
FROM events ORDER BY id DESC LIMIT ?
"""

SELECT_EVENTS_BY_DATE_SQL = """
SELECT id, timestamp, engine, severity, process_name, process_path,
       remote_ip, country, file_path, description, action_taken, confirmed_by
FROM events WHERE substr(timestamp, 1, 10) = ? ORDER BY id ASC
"""

UPDATE_EVENT_ACTION_SQL = """
UPDATE events SET action_taken = ?, confirmed_by = ? WHERE id = ?
"""

UPSERT_IP_CACHE_SQL = """
INSERT OR REPLACE INTO ip_cache (
  ip, country, country_code, org, isp, is_hosting, fetched_at
) VALUES (?, ?, ?, ?, ?, ?, ?)
"""

SELECT_IP_CACHE_SQL = """
SELECT ip, country, country_code, org, isp, is_hosting, fetched_at
FROM ip_cache WHERE ip = ?
"""

INSERT_ALLOWLIST_SQL = """
INSERT INTO allowlist (
  process_path, exe_hash, alert_type, added_at, expires_at, note
) VALUES (?, ?, ?, ?, ?, ?)
"""

SELECT_ALLOWLIST_SQL = """
SELECT id, process_path, exe_hash, alert_type, added_at, expires_at, note
FROM allowlist ORDER BY id DESC
"""

DELETE_ALLOWLIST_SQL = "DELETE FROM allowlist WHERE id = ?"

UPSERT_BASELINE_SQL = """
INSERT OR REPLACE INTO file_baselines (file_path, sha256_hash, updated_at)
VALUES (?, ?, ?)
"""

SELECT_BASELINE_SQL = "SELECT sha256_hash FROM file_baselines WHERE file_path = ?"

UPSERT_DAILY_STATS_SQL = """
INSERT OR REPLACE INTO daily_stats (
  date, total_events, critical_count, high_count,
  warn_count, info_count, actions_taken, monitoring_uptime
) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
"""
