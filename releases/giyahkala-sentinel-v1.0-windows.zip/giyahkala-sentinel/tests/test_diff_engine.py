"""Unit tests for the pure price and option diff engine."""

from __future__ import annotations

from sentinel.diff_engine import compute_catalog_diff
from sentinel.extractor import build_verified_Reference_catalog
from sentinel.models import CatalogSnapshot, PriceChangeType


def test_compute_catalog_diff_identifies_all_change_types() -> None:
    """Verify baseline vs. current comparison classifies all six product states."""
    baseline_products = build_verified_Reference_catalog("baseline")
    current_products = build_verified_Reference_catalog("current")

    baseline_snap = CatalogSnapshot(
        snapshot_id=1,
        created_at_iso="2026-10-20T08:00:00Z",
        source_mode="verified_catalog",
        is_baseline=True,
        product_count=len(baseline_products),
        products=baseline_products,
    )
    current_snap = CatalogSnapshot(
        snapshot_id=2,
        created_at_iso="2026-10-21T08:00:00Z",
        source_mode="verified_catalog",
        is_baseline=False,
        product_count=len(current_products),
        products=current_products,
    )

    changed_report = compute_catalog_diff(
        baseline_snapshot=baseline_snap,
        current_snapshot=current_snap,
        changed_only=True,
    )

    assert changed_report.summary.total_compared == 11
    assert changed_report.summary.total_changed == 8
    assert changed_report.summary.price_increased_count == 4
    assert changed_report.summary.price_decreased_count == 1
    assert changed_report.summary.stock_changed_count == 1
    assert changed_report.summary.option_changed_count == 1
    assert changed_report.summary.new_product_count == 1
    assert changed_report.summary.unchanged_count == 3

    assert len(changed_report.items) == 8
    assert all(
        item.change_type != PriceChangeType.UNCHANGED
        for item in changed_report.items
    )

    sage_delta = next(
        item for item in changed_report.items if item.slug == "dry-sage-plant"
    )
    assert sage_delta.change_type == PriceChangeType.PRICE_INCREASED
    assert sage_delta.previous_price_toman == 2097600
    assert sage_delta.current_price_toman == 2360000
    assert sage_delta.delta_toman == 262400

    rosemary_delta = next(
        item for item in changed_report.items if item.slug == "giyah-khoshk-rosmary"
    )
    assert rosemary_delta.change_type == PriceChangeType.PRICE_DECREASED
    assert rosemary_delta.delta_toman == -64000


def test_diff_engine_ignores_first_time_html_enrichment_when_base_price_unchanged() -> None:
    """Verify enabling HTML enrichment does not flag unchanged base-price items as option_changed."""
    from sentinel.diff_engine import compare_single_product
    from sentinel.models import CatalogProduct, OptionTier

    baseline_item = CatalogProduct(
        product_id=3761,
        sku="10003761",
        slug="arnica-extract",
        name="Liquid Arnica Extract",
        category="Liquid Extracts",
        permalink="https://giyahkala.com/product/arnica-extract/",
        base_price_toman=10200000,
        regular_price_toman=10200000,
        displayed_price_toman=10200000,
        is_in_stock=True,
        option_tiers=[],
    )
    enriched_item = CatalogProduct(
        product_id=3761,
        sku="10003761",
        slug="arnica-extract",
        name="Liquid Arnica Extract",
        category="Liquid Extracts",
        permalink="https://giyahkala.com/product/arnica-extract/",
        base_price_toman=10200000,
        regular_price_toman=10200000,
        displayed_price_toman=10200000,
        is_in_stock=True,
        option_tiers=[
            OptionTier(
                group_name="Select Grade",
                option_label="Grade A",
                price_toman=10200000,
            )
        ],
    )

    delta = compare_single_product(baseline_item, enriched_item)
    assert delta.change_type == PriceChangeType.UNCHANGED
    assert delta.delta_toman == 0
    assert delta.option_change_summary == ""

