/* v2.5 Security Pack controller: Quarantine Vault [Q] and Listening Ports & Autoruns [L] */
window.GodV25 = {
  togglePortsDrawer(forceOpen) {
    const el = document.getElementById("ports-drawer");
    if (!el) return;
    const show = typeof forceOpen === "boolean" ? forceOpen : el.classList.contains("hidden");
    el.classList.toggle("hidden", !show);
    if (show) this.refreshPersistence();
  },

  toggleQuarantineDrawer(forceOpen) {
    const el = document.getElementById("quarantine-drawer");
    if (!el) return;
    const show = typeof forceOpen === "boolean" ? forceOpen : el.classList.contains("hidden");
    el.classList.toggle("hidden", !show);
    if (show) this.refreshQuarantine();
  },

  async refreshPersistence() {
    try {
      const res = await fetch("/api/persistence");
      const data = await res.json();
      this.renderPortsAndAutoruns(data.listening_ports || [], data.autoruns || []);
    } catch (err) { console.error("Persistence fetch error:", err); }
  },

  renderPortsAndAutoruns(ports, autoruns) {
    const pBody = document.getElementById("listening-ports-tbody");
    if (pBody) {
      pBody.textContent = "";
      ports.forEach((p) => {
        const tr = document.createElement("tr");
        if (p.risk_level === "CRITICAL") tr.className = "row-critical";
        else if (p.risk_level === "WARN") tr.className = "row-suspicious";
        [p.port, p.bind_ip, p.pid || "-", p.process_name, p.risk_level].forEach((v) => window.GodPanels.appendCell(tr, v));
        pBody.appendChild(tr);
      });
    }
    const aBody = document.getElementById("autoruns-tbody");
    if (aBody) {
      aBody.textContent = "";
      autoruns.forEach((a) => {
        const tr = document.createElement("tr");
        if (a.status !== "VERIFIED") tr.className = "row-critical";
        [a.source, a.name, a.command, a.status].forEach((v) => window.GodPanels.appendCell(tr, v));
        aBody.appendChild(tr);
      });
    }
  },

  async refreshQuarantine() {
    const tbody = document.getElementById("quarantine-tbody");
    if (!tbody) return;
    try {
      const items = await (await fetch("/api/quarantine")).json();
      tbody.textContent = "";
      items.forEach((item) => {
        const tr = document.createElement("tr");
        [item.id, item.original_path, `${(item.sha256_hash || "").slice(0, 12)}...`, item.status].forEach((v) => window.GodPanels.appendCell(tr, v));
        const actTd = document.createElement("td");
        if (item.status === "QUARANTINED") {
          const btn = document.createElement("button");
          btn.className = "action-btn";
          btn.textContent = "Restore";
          btn.addEventListener("click", async () => {
            const res = await fetch(`/api/quarantine/${item.id}/restore`, { method: "POST" });
            const out = await res.json();
            window.GodCommands.showToast(out.message || "Restored");
            this.refreshQuarantine();
          });
          actTd.appendChild(btn);
        } else actTd.textContent = "-";
        tr.appendChild(actTd);
        tbody.appendChild(tr);
      });
    } catch (err) { console.error("Quarantine list error:", err); }
  },
};
