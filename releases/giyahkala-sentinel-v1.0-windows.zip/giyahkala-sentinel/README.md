# GiyahKala Price Sentinel (v1.0.0)

On-demand product price, option-tier, and stock change monitoring system for `giyahkala.com` affiliate resellers.

## Key Capabilities

1. **Keyless Hybrid Extraction**: Reads observable product prices and availability from `giyahkala.com` without requiring private API keys by combining the public WooCommerce Store endpoint with HTML DOM and JSON-LD option parsing.
2. **Baseline Snapshot Comparison**: Stores every scan in a local SQLite database (`WAL` mode) and highlights **only products whose price, option tiers, or stock status changed** relative to your active baseline.
3. **Linear Light-Mode Web Interface**: Fast, keyboard-accessible dashboard (`http://127.0.0.1:8090/`) with instant search (`/`), status filters, option-tier inspector, and one-click Excel CSV export (`E`).
4. **CLI One-Shot Mode**: Run quick terminal checks and export CSV reports directly from the command line.

## Quick Start (Windows)

Double-click `run-windows.bat` (or `start_sentinel.bat`). The launcher automatically creates an isolated `.venv` environment, installs required dependencies, starts the local web server at `http://127.0.0.1:8090/`, and opens your browser.

## Command-Line Usage

```bash
# Start the interactive web dashboard
python main.py --host 127.0.0.1 --port 8090

# Run a single on-demand scan in the terminal and export changed items to CSV
python main.py --scan-once --mode auto --export-csv changed-prices.csv
```

## Running the Test Suite

```bash
pytest
```
