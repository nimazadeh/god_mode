"""Reversible QuarantineVault subsystem for isolating and restoring suspicious files."""

from datetime import datetime
from pathlib import Path
import shutil
from typing import Any
import uuid
from constants import PROTECTED_SYSTEM_PREFIXES, QUARANTINE_DIR
from engine.os_adapter import compute_sha256
from storage.db import Database

INSERT_QUARANTINE_SQL = """
INSERT INTO quarantine_items (
  original_path, vault_path, sha256_hash, reason, quarantined_at, status
) VALUES (?, ?, ?, ?, ?, ?)
"""

SELECT_QUARANTINE_SQL = """
SELECT id, original_path, vault_path, sha256_hash, reason, quarantined_at, status
FROM quarantine_items ORDER BY id DESC
"""

SELECT_ONE_QUARANTINE_SQL = """
SELECT id, original_path, vault_path, sha256_hash, reason, quarantined_at, status
FROM quarantine_items WHERE id = ?
"""

UPDATE_QUARANTINE_STATUS_SQL = "UPDATE quarantine_items SET status = ? WHERE id = ?"


class QuarantineVault:
    """Safely isolates suspicious files into quarantine/ and restores them on confirmation."""

    def __init__(self, db: Database, vault_dir: Path = QUARANTINE_DIR) -> None:
        self.db = db
        self.vault_dir = vault_dir
        self.vault_dir.mkdir(parents=True, exist_ok=True)

    def _is_protected_path(self, file_path: str) -> bool:
        """Return True if file_path belongs to a protected OS binary directory."""
        norm = file_path.strip().lower()
        return any(norm.startswith(prefix) for prefix in PROTECTED_SYSTEM_PREFIXES)

    async def quarantine_file(self, file_path: str, reason: str = "Operator quarantine") -> tuple[bool, str, dict[str, Any] | None]:
        """Move a suspicious file into the quarantine vault and record metadata in SQLite."""
        if not file_path or self._is_protected_path(file_path):
            return False, f"Refused: '{file_path}' is a protected OS system path", None
        src = Path(file_path)
        if not src.is_file():
            return False, f"File not found on disk: {file_path}", None
        sha256 = compute_sha256(str(src))
        dest = self.vault_dir / f"{uuid.uuid4().hex[:8]}_{src.name}.qvault"
        shutil.move(str(src), str(dest))
        record = await self._insert_record(str(src), str(dest), sha256, reason)
        return True, f"Quarantined {src.name}", record

    async def _insert_record(self, orig: str, vault_p: str, sha: str, reason: str) -> dict[str, Any]:
        """Persist a new QUARANTINED record in SQLite and return it."""
        conn = self.db._require_conn()
        ts = datetime.now().isoformat(timespec="seconds")
        cur = await conn.execute(INSERT_QUARANTINE_SQL, (orig, vault_p, sha, reason, ts, "QUARANTINED"))
        await conn.commit()
        return {
            "id": int(cur.lastrowid or 0), "original_path": orig, "vault_path": vault_p,
            "sha256_hash": sha, "reason": reason, "quarantined_at": ts, "status": "QUARANTINED",
        }

    async def restore_file(self, item_id: int) -> tuple[bool, str]:
        """Restore a quarantined file back to its original path and mark RESTORED."""
        conn = self.db._require_conn()
        cur = await conn.execute(SELECT_ONE_QUARANTINE_SQL, (item_id,))
        row = await cur.fetchone()
        if not row:
            return False, f"Quarantine item #{item_id} not found"
        item = dict(row)
        v_path, orig_path = Path(item["vault_path"]), Path(item["original_path"])
        if not v_path.is_file():
            return False, "Quarantined payload missing from vault"
        orig_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(v_path), str(orig_path))
        await conn.execute(UPDATE_QUARANTINE_STATUS_SQL, ("RESTORED", item_id))
        await conn.commit()
        return True, f"Restored {orig_path.name} to {orig_path}"

    async def list_items(self) -> list[dict[str, Any]]:
        """Return all quarantine records ordered newest first."""
        conn = self.db._require_conn()
        cur = await conn.execute(SELECT_QUARANTINE_SQL)
        rows = await cur.fetchall()
        return [dict(r) for r in rows]
