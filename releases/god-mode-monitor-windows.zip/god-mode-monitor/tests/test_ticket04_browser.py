"""Browser E2E test and screenshot capture for Ticket 04: 1280x800, Reconnect, and Daily Report."""

import asyncio
from datetime import datetime
from pathlib import Path
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")


@pytest.mark.asyncio
async def test_ticket04_browser_responsive_reconnect_and_daily_report():
    """Verify 1280x800 zero-overflow layout, WebSocket auto-reconnect, and Daily Report HTML."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1280, "height": 800})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

        await page.goto("http://127.0.0.1:8080", wait_until="networkidle")
        await page.wait_for_function("Number(document.getElementById('stat-processes')?.textContent || '0') > 0")

        overflow = await page.evaluate(
            """() => ({
                x: document.documentElement.scrollWidth > document.documentElement.clientWidth,
                y: document.documentElement.scrollHeight > document.documentElement.clientHeight
            })"""
        )
        assert overflow["x"] is False and overflow["y"] is False
        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_04_dashboard_1280x800.png"))

        await page.evaluate("window.GodApp.ws.close()")
        await page.wait_for_function("document.getElementById('conn-status')?.textContent === 'RECONNECTING...'")
        await page.wait_for_function(
            "document.getElementById('conn-status')?.textContent === 'LIVE'",
            timeout=6000,
        )

        today = datetime.now().date().isoformat()
        report_page = await browser.new_page(viewport={"width": 1440, "height": 960})
        await report_page.goto(f"http://127.0.0.1:8080/api/reports/{today}", wait_until="networkidle")
        heading = await report_page.locator("h1").text_content()
        assert "God Mode Monitor" in (heading or "")
        await report_page.screenshot(path=str(SCREENSHOT_DIR / "ticket_04_daily_report.png"), full_page=True)

        await browser.close()

    assert errors == [], f"Browser errors: {errors}"
