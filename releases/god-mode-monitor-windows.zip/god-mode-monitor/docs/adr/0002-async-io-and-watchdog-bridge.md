# Bridge Watchdog and OS subprocesses into AsyncIO without blocking

To satisfy the strict non-blocking event loop constraint while using `watchdog.observers.Observer` and OS utilities (`netsh`, `powershell`), all subprocess execution uses `asyncio.create_subprocess_exec` and `watchdog` filesystem callbacks forward events into the `EventBus` (`asyncio.Queue`) exclusively via `loop.call_soon_threadsafe`. No application code spawns custom threads or invokes blocking `subprocess.run` on the event loop.
