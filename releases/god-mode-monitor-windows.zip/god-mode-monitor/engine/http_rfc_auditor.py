"""HTTP RFC 9110/9111/6265/7838/9421/9530/9651 compliance and security auditor."""

from datetime import datetime
from typing import Any, Optional
import httpx
from httpx import ASGITransport
from constants import RFC_AUDIT_TIMEOUT_SEC, RFC_SCORE_FULL
from engine.rfc_firewall import verify_rfc9421_headers


def _score_rfc_headers(
    norm: dict[str, str], sig_info: dict[str, Any], trace_blocked: bool
) -> tuple[int, list[dict[str, str]]]:
    """Evaluate RFC 9110, 9111, 6265, 9530, and 9421 compliance rules and return score + checks."""
    score = RFC_SCORE_FULL
    checks: list[dict[str, str]] = []
    cc = norm.get("cache-control", "").lower()
    cache_ok = "no-store" in cc or "max-age" in cc
    if not cache_ok:
        score -= 15
    checks.append({"rfc": "RFC 9111", "rule": "Cache-Control Directive", "status": "PASS" if cache_ok else "WARN", "detail": cc or "Missing Cache-Control"})
    if not trace_blocked:
        score -= 25
    checks.append({"rfc": "RFC 9110", "rule": "TRACE Reflection Disabled", "status": "PASS" if trace_blocked else "FAIL", "detail": "405 Blocked" if trace_blocked else "TRACE Enabled"})
    cookie = norm.get("set-cookie", "").lower()
    cookie_ok = (not cookie) or ("httponly" in cookie and "samesite" in cookie)
    if not cookie_ok:
        score -= 15
    checks.append({"rfc": "RFC 6265", "rule": "Cookie Security Flags", "status": "PASS" if cookie_ok else "WARN", "detail": "Stateless / Hardened" if cookie_ok else "Missing HttpOnly/SameSite"})
    return max(0, score), checks


def _append_crypto_checks(
    score: int, checks: list[dict[str, str]], sig_info: dict[str, Any]
) -> tuple[int, list[dict[str, str]]]:
    """Evaluate RFC 9530 Repr-Digest, RFC 9651 Structured Fields, and RFC 9421 Message Signatures."""
    d_ok = bool(sig_info.get("digest_valid"))
    s_ok = bool(sig_info.get("signature_valid"))
    if not d_ok:
        score -= 10
    if not s_ok:
        score -= 10
    checks.append({"rfc": "RFC 9530 / 9651", "rule": "Repr-Digest Byte Sequence", "status": "PASS" if d_ok else "INFO", "detail": sig_info.get("repr_digest") or "Not signed"})
    checks.append({"rfc": "RFC 9421", "rule": "HTTP Message Signature", "status": "PASS" if s_ok else "INFO", "detail": "HMAC-SHA256 Verified" if s_ok else "Unsigned endpoint"})
    return max(0, score), checks


def build_rfc_audit_report(
    url: str, status_code: int, http_version: str, headers: dict[str, str], body: bytes, trace_blocked: bool
) -> dict[str, Any]:
    """Assemble a complete RFC 9110/9111/6265/9421/9530 compliance report for an HTTP response."""
    norm = {k.lower(): v for k, v in headers.items()}
    sig_info = verify_rfc9421_headers(status_code, body, norm)
    score, checks = _score_rfc_headers(norm, sig_info, trace_blocked)
    score, checks = _append_crypto_checks(score, checks, sig_info)
    grade = "A+" if score >= 95 else ("A" if score >= 85 else ("B" if score >= 70 else "C"))
    return {
        "url": url, "timestamp": datetime.now().isoformat(timespec="seconds"),
        "status_code": status_code, "http_version": http_version, "score": score, "grade": grade,
        "cache_control": norm.get("cache-control", "None"), "alt_svc": norm.get("alt-svc", "None"),
        "rfc9530_digest_valid": sig_info["digest_valid"], "rfc9421_signature_valid": sig_info["signature_valid"],
        "rfc9651_structured": sig_info["rfc9651_structured"], "repr_digest": sig_info["repr_digest"] or "None",
        "signature": sig_info["signature"] or "None", "checks": checks,
    }


class HttpRfcAuditor:
    """Audits local loopback and operator-specified HTTP endpoints against IETF HTTPWG RFCs."""

    def __init__(self) -> None:
        """Initialize in-memory audit report history."""
        self._audits: list[dict[str, Any]] = []

    def list_audits(self) -> list[dict[str, Any]]:
        """Return recent HTTP RFC audit reports newest first."""
        return list(self._audits[:25])

    async def _probe_target(self, url: str, app: Optional[Any]) -> dict[str, Any]:
        """Execute GET and TRACE probes against a target URL using httpx."""
        use_asgi = app is not None and ("localhost:8080" in url or "127.0.0.1:8080" in url)
        transport = ASGITransport(app=app) if use_asgi else None
        async with httpx.AsyncClient(transport=transport, timeout=RFC_AUDIT_TIMEOUT_SEC, follow_redirects=True) as client:
            res = await client.get(url)
            trace_res = await client.request("TRACE", url)
            trace_blocked = trace_res.status_code in (400, 405, 501)
            return build_rfc_audit_report(
                url, res.status_code, res.http_version or "HTTP/1.1",
                dict(res.headers), res.content, trace_blocked,
            )

    async def audit_url(self, url: str, app: Optional[Any] = None) -> dict[str, Any]:
        """Audit an HTTP/HTTPS URL and record the resulting RFC compliance report."""
        target = url.strip() if url.strip().startswith(("http://", "https://")) else f"http://{url.strip()}"
        try:
            report = await self._probe_target(target, app)
        except Exception as exc:
            report = {
                "url": target, "timestamp": datetime.now().isoformat(timespec="seconds"),
                "status_code": 0, "http_version": "ERR", "score": 0, "grade": "ERR",
                "cache_control": "Unreachable", "alt_svc": "None",
                "rfc9530_digest_valid": False, "rfc9421_signature_valid": False,
                "rfc9651_structured": False, "repr_digest": "None", "signature": "None",
                "checks": [{"rfc": "RFC 9110", "rule": "Connection Reachability", "status": "FAIL", "detail": str(exc)[:80]}],
            }
        self._audits = [r for r in self._audits if r.get("url") != target]
        self._audits.insert(0, report)
        return report
