# GiyahKala Price Sentinel

A price monitoring and comparison system that tracks observable product prices, option add-ons, and stock availability on `giyahkala.com` for affiliate resellers.

## Language

**CatalogProduct**:
An individual product listed on `giyahkala.com`, identified by its canonical `product_id`, `sku`, and `slug`, along with its normalized Toman price, stock state, and option tiers.
_Avoid_: Item, article, post

**OptionTier**:
A selectable weight, purity percentage, or packaging variant on a product page that carries its own price or additive price delta in Toman.
_Avoid_: Sub-product, attribute row

**CatalogSnapshot**:
An immutable, timestamped capture of all observed `CatalogProduct` records from a single on-demand scan run.
_Avoid_: Backup, dump, history log

**BaselineSnapshot**:
The designated reference `CatalogSnapshot` representing the prices currently synchronized with the reseller's own storefront.
_Avoid_: Old table, previous file

**PriceDelta**:
The computed difference between a product's state in the latest `CatalogSnapshot` and its state in the `BaselineSnapshot`, classified as `price_increased`, `price_decreased`, `option_changed`, `stock_changed`, `new_product`, or `unchanged`.
_Avoid_: Diff row, change item

**DiffReport**:
The filtered collection of `PriceDelta` records showing only products whose price, option tiers, or stock status changed relative to the `BaselineSnapshot`.
_Avoid_: Scan log, output list

**Watchlist**:
A reseller-curated subset of product URLs, slugs, or category slugs monitored during targeted on-demand scans.
_Avoid_: Bookmark list, favorites
