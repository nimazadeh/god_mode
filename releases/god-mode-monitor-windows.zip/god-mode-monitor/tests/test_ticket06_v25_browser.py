"""Browser E2E test and screenshot capture for Ticket 06: Ports, Autoruns, and Quarantine Vault."""

import asyncio
from pathlib import Path
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")
AUTORUN_DIR = Path("/home/user/god-mode-monitor/watched_autoruns")


@pytest.mark.asyncio
async def test_ticket06_browser_ports_autoruns_and_quarantine_restore():
    """Verify Listening Ports & Autoruns drawer [L], Quarantine Vault [Q], and 1-click Restore."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    AUTORUN_DIR.mkdir(parents=True, exist_ok=True)
    suspect_file = AUTORUN_DIR / "malicious_persistence.bat"
    suspect_file.write_text("@echo off\r\npowershell -enc AAAA\r\n", encoding="utf-8")
    errors: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

        await page.goto("http://127.0.0.1:8080/?variant=A", wait_until="networkidle")
        await page.wait_for_function("Number(document.getElementById('stat-processes')?.textContent || '0') > 0")

        # Open Ports & Autoruns drawer [L]
        await page.click("#ports-open-btn")
        await asyncio.sleep(0.4)
        ports_txt = await page.locator("#listening-ports-tbody").text_content() or ""
        autorun_txt = await page.locator("#autoruns-tbody").text_content() or ""
        assert "8080" in ports_txt
        assert "malicious_persistence.bat" in autorun_txt
        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_06_ports_and_autoruns.png"))
        await page.keyboard.press("Escape")

        # Quarantine the suspicious persistence file via API and inspect in Quarantine Vault [Q]
        await page.evaluate(
            """async (p) => {
                await fetch('/api/quarantine', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({file_path: p, reason: 'Suspicious Autorun Persistence'})
                });
            }""",
            str(suspect_file),
        )
        assert not suspect_file.exists()

        await page.click("#quarantine-open-btn")
        await asyncio.sleep(0.4)
        q_txt = await page.locator("#quarantine-tbody").text_content() or ""
        assert "malicious_persistence.bat" in q_txt and "QUARANTINED" in q_txt
        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_06_quarantine_vault.png"))

        # Click Restore button inside Quarantine Vault drawer
        await page.locator("#quarantine-tbody button.action-btn").first.click()
        await asyncio.sleep(0.4)
        assert suspect_file.exists()
        suspect_file.unlink(missing_ok=True)
        await browser.close()

    assert errors == [], f"Browser errors: {errors}"
