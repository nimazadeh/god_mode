"""Browser E2E test and screenshot capture for Ticket 03: Modes, Sound, Shortcuts, Allowlist."""

import asyncio
from pathlib import Path
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")


@pytest.mark.asyncio
async def test_ticket03_browser_modes_mute_allowlist_and_shortcuts():
    """Verify WATCH/GUARD/WAR switching, mute persistence, keyboard shortcuts, and Allowlist UI."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)

        await page.goto("http://127.0.0.1:8080", wait_until="networkidle")
        await page.wait_for_function("Number(document.getElementById('stat-processes')?.textContent || '0') > 0")

        await page.click("#btn-mode-watch")
        await page.wait_for_function("document.getElementById('posture-indicator')?.textContent === 'WATCH'")

        await page.click("#btn-mode-war")
        await page.wait_for_function("document.getElementById('posture-indicator')?.textContent === 'WAR ACTIVE'")
        has_war_cls = await page.locator("#main-header").evaluate("el => el.classList.contains('war-mode-header')")
        assert has_war_cls is True

        await page.keyboard.press("s")
        mute_txt = await page.locator("#mute-btn").text_content()
        assert mute_txt == "🔇"
        await page.reload(wait_until="networkidle")
        assert (await page.locator("#mute-btn").text_content()) == "🔇"
        await page.keyboard.press("s")
        assert (await page.locator("#mute-btn").text_content()) == "🔊"

        await page.evaluate(
            """async () => {
                await fetch('/api/allowlist', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        process_path: '/usr/local/bin/python3.13',
                        alert_type: 'PROC_MEM_SPIKE',
                        note: 'Verified developer runtime'
                    })
                });
            }"""
        )

        await page.keyboard.press("a")
        await asyncio.sleep(0.5)
        drawer_open = await page.locator("#allowlist-drawer").evaluate("el => !el.classList.contains('hidden')")
        assert drawer_open is True
        rule_rows = await page.locator("#allowlist-tbody tr").count()
        assert rule_rows >= 1

        await page.locator("#allowlist-tbody button").first.click()
        confirm_open = await page.locator("#confirm-modal").evaluate("el => !el.classList.contains('hidden')")
        assert confirm_open is True

        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_03_war_mode_and_allowlist.png"))
        await page.click("#confirm-cancel-btn")
        await page.click("#btn-mode-guard")
        await asyncio.sleep(0.3)
        await browser.close()

    assert errors == [], f"Browser errors: {errors}"
