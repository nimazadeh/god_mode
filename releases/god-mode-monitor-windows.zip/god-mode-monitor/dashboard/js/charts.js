/* Rolling 60-second CPU % and Outbound Network MB/s Chart.js wrapper */
window.GodCharts = {
  chart: null,
  maxPoints: 30,

  readCssVar(name) {
    return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  },

  init() {
    const canvas = document.getElementById("telemetry-chart");
    if (!canvas || typeof window.Chart === "undefined") return;
    const redCore = this.readCssVar("--red-core");
    const redDim = this.readCssVar("--red-dim");
    const textMuted = this.readCssVar("--text-secondary");
    const borderCol = this.readCssVar("--border-default");
    this.chart = new window.Chart(canvas.getContext("2d"), {
      type: "line",
      data: {
        labels: [],
        datasets: [
          {
            label: "CPU %",
            data: [],
            borderColor: redCore,
            backgroundColor: redCore,
            borderWidth: 2,
            tension: 0.35,
            pointRadius: 2,
          },
          {
            label: "NET MB/s",
            data: [],
            borderColor: redDim,
            backgroundColor: redDim,
            borderDash: [5, 4],
            borderWidth: 2,
            tension: 0.35,
            pointRadius: 2,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 300 },
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: textMuted, maxTicksLimit: 6 }, grid: { color: borderCol } },
          y: { beginAtZero: true, suggestedMax: 100, ticks: { color: textMuted }, grid: { color: borderCol } },
        },
      },
    });
  },

  pushSample(timestampIso, cpuPercent, netMbps) {
    if (!this.chart) return;
    const label = (timestampIso || "").slice(11, 19) || new Date().toTimeString().slice(0, 8);
    const { labels, datasets } = this.chart.data;
    labels.push(label);
    datasets[0].data.push(Number(cpuPercent || 0));
    datasets[1].data.push(Number(netMbps || 0));
    if (labels.length > this.maxPoints) {
      labels.shift();
      datasets[0].data.shift();
      datasets[1].data.shift();
    }
    this.chart.update("none");
  },
};
