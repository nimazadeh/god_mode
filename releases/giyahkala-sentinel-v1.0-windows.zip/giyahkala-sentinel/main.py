"""Command-line entrypoint and HTTP server runner for GiyahKala Price Sentinel.

Disables Windows console QuickEdit mode on startup so accidental mouse clicks
inside cmd.exe never suspend the asynchronous Uvicorn event loop.
"""

from __future__ import annotations

import argparse
import asyncio
import ctypes
from pathlib import Path
import sys
import uvicorn

from sentinel.api import create_app
from sentinel.constants import (
    APP_TITLE,
    DEFAULT_HOST,
    DEFAULT_PORT,
    SENTINEL_VERSION,
)
from sentinel.models import ScanRequest
from sentinel.service import PriceSentinelService


def disable_windows_quick_edit_mode() -> None:
    """Disable Windows QuickEdit mode to prevent console mouse clicks from pausing I/O."""
    if sys.platform != "win32":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        std_input_handle = kernel32.GetStdHandle(-10)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(std_input_handle, ctypes.byref(mode)):
            enable_quick_edit = 0x0040
            enable_extended_flags = 0x0080
            new_mode = (mode.value & ~enable_quick_edit) | enable_extended_flags
            kernel32.SetConsoleMode(std_input_handle, new_mode)
    except Exception:
        return


def build_cli_banner(host: str, port: int) -> str:
    """Format the ANSI terminal startup banner and vertical operator menu."""
    cyan = "\033[96m"
    green = "\033[92m"
    yellow = "\033[93m"
    reset = "\033[0m"
    lines = [
        f"{cyan}===================================================================={reset}",
        f"{cyan}  {APP_TITLE} v{SENTINEL_VERSION} — Affiliate Price Diff Engine{reset}",
        f"{cyan}===================================================================={reset}",
        f"  Dashboard URL : {green}http://{host}:{port}/{reset}",
        f"  Target Source : https://giyahkala.com (Hybrid Store JSON + HTML DOM)",
        f"{cyan}--------------------------------------------------------------------{reset}",
        f"  Operator Controls (Vertical Menu):",
        f"    {yellow}[S]{reset} Trigger on-demand price scan against baseline",
        f"    {yellow}[B]{reset} Synchronize active baseline to latest snapshot",
        f"    {yellow}[E]{reset} Export changed products to CSV (Excel UTF-8 BOM)",
        f"    {yellow}[W]{reset} Manage custom product URL / slug watchlist",
        f"    {yellow}[Q]{reset} Stop server and exit cleanly",
        f"{cyan}===================================================================={reset}",
    ]
    return "\n".join(lines)


async def run_cli_one_shot(
    database_path: Path,
    mode: str,
    output_csv: Path | None,
) -> int:
    """Execute a single CLI scan, print the diff summary, and optionally write CSV."""
    service = PriceSentinelService(database_path=database_path)
    report = await service.execute_on_demand_scan(
        ScanRequest(mode=mode, note="CLI on-demand price check")
    )
    changed_items = [item for item in report.items if item.has_changed]
    print(
        f"Scan completed (Snapshot #{report.current_snapshot_id} vs Baseline #{report.baseline_snapshot_id})"
    )
    print(
        f"Total Monitored: {report.summary.total_compared} | Changed Products: {report.summary.total_changed}"
    )
    for delta in changed_items:
        prev_str = (
            f"{delta.previous_price_toman:,}"
            if delta.previous_price_toman is not None
            else "NEW"
        )
        print(
            f" - [{delta.change_type.value}] {delta.slug} (SKU {delta.sku}): "
            f"{prev_str} -> {delta.current_price_toman:,} IRT ({delta.delta_percent:+.2f}%)"
        )

    if output_csv is not None:
        csv_content = service.export_current_diff_csv(changed_only=True)
        output_csv.parent.mkdir(parents=True, exist_ok=True)
        output_csv.write_text(csv_content, encoding="utf-8")
        print(f"Exported changed products CSV to: {output_csv}")
    return 0


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse command-line options for server or one-shot CLI scan execution."""
    parser = argparse.ArgumentParser(
        description="GiyahKala Price Sentinel — On-demand price change monitor"
    )
    parser.add_argument("--host", default=DEFAULT_HOST, help="Bind host address")
    parser.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help="Bind TCP port"
    )
    parser.add_argument(
        "--db",
        default=str(
            Path(__file__).resolve().parent / "data" / "sentinel.db"
        ),
        help="Path to local SQLite snapshot database",
    )
    parser.add_argument(
        "--scan-once",
        action="store_true",
        help="Run a single on-demand price scan and exit",
    )
    parser.add_argument(
        "--mode",
        default="auto",
        choices=["auto", "live", "verified_catalog"],
        help="Extraction mode for one-shot scan",
    )
    parser.add_argument(
        "--export-csv",
        default="",
        help="Optional file path to save changed products CSV during --scan-once",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    """Application entrypoint."""
    disable_windows_quick_edit_mode()
    args = parse_args(argv)
    database_path = Path(args.db)

    if args.scan_once:
        csv_target = Path(args.export_csv) if args.export_csv.strip() else None
        return asyncio.run(
            run_cli_one_shot(
                database_path=database_path,
                mode=args.mode,
                output_csv=csv_target,
            )
        )

    print(build_cli_banner(args.host, args.port))
    app = create_app(database_path=database_path)
    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        server_header=False,
        log_level="info",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
