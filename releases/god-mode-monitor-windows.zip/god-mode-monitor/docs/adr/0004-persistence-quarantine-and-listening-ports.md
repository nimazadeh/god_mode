# 0004. PersistenceGuard, Reversible QuarantineVault, and ListeningPort Telemetry

Date: 2026-10-16
Status: Accepted

## Context
Security operators using God Mode Monitor v2.5 need visibility into OS persistence mechanisms (`Run` registry keys and Startup folders), local sockets in `LISTEN` state (backdoor/RAT ports), and a reversible file containment workflow (`QuarantineVault`) that disarms suspicious binaries or mutated files without permanent data loss while respecting the 200-line Python and 80-line JavaScript module caps (`ADR-0003`).

## Decision
1. **PersistenceGuard (`engine/persistence_guard.py`)**:
   - Uses `OSAdapter.list_autorun_entries()` to read `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, `HKLM\Software\Microsoft\Windows\CurrentVersion\Run`, and the Windows Startup folder on `win32` (and `watched_autoruns/` + `/etc/xdg/autostart` on POSIX).
   - Computes baseline entry hashes at startup and emits `HIGH` / `CRITICAL` alerts on any newly added or modified autorun command.
2. **ListeningPort Scanner (`engine/persistence_guard.py` / `NetworkSentinel`)**:
   - Inspects `psutil.net_connections(kind="inet")` for `status == "LISTEN"`, attributes each listening port to its owning process, and flags risky backdoor ports (`4444`, `1337`, `31337`, `6667`, `5900`, `3389`) or unsigned wildcard listeners.
3. **QuarantineVault (`engine/quarantine_vault.py` + `quarantine_items` SQLite table)**:
   - Moves target files into `quarantine/<id>_<filename>.qvault`, records original path + SHA-256 + timestamp in SQLite, blocks quarantining protected OS paths (`C:\Windows\System32`, `/usr/bin`, `/bin`, `/sbin`), and provides 1-click `restore_quarantine_item(id)` to return the file to its original location.
4. **UI/UX Integration (`dashboard/js/v25_drawer.js`)**:
   - Adds `[QUARANTINE]` (`[Q]`) and `[PORTS & AUTORUN]` (`[L]`) header buttons and slide-in drawers, plus `[4: PORTS & AUTORUN]` workbench tab in Variant B, and a `Quarantine` action button on file/process alerts in `GUARD` and `WAR` modes.

## Consequences
- All new backend logic lives in deep modules (`engine/persistence_guard.py` and `engine/quarantine_vault.py`) and one new frontend controller (`dashboard/js/v25_drawer.js`), preserving all strict file/function line caps.
