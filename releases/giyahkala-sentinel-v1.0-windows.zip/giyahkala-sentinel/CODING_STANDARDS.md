# Coding Standards — GiyahKala Price Sentinel

See the root `/home/user/CODING_STANDARDS.md` and `GLOSSARY.md` for canonical domain terminology and deep-module seam rules.

## Automated Guardrails (`tests/test_code_hygiene.py`)

Every commit must pass `pytest -v`, which mechanically enforces:
1. Zero non-English characters in Python source files outside intentional Persian catalog/parser strings.
2. Zero unsafe DOM or CSS override tokens across `sentinel/` and `web/`.
3. Flat `if ... goto` control flow in Windows `.bat` launchers.
4. Strict service seam encapsulation (`sentinel/api.py` never accesses `.repository.` directly).
