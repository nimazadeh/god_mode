"""Async SQLite repository built on aiosqlite with parameterized queries."""

from pathlib import Path
from typing import Any, Optional
import aiosqlite
from constants import DEFAULT_EVENTS_LIMIT
from storage import models


class Database:
    """Manages SQLite connections, migrations, and parameterized queries."""

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self._conn: Optional[aiosqlite.Connection] = None

    async def initialize(self) -> None:
        """Open connection and execute idempotent schema migrations."""
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.db_path)
        self._conn.row_factory = aiosqlite.Row
        for statement in models.SCHEMA_STATEMENTS:
            await self._conn.execute(statement)
        await self._conn.commit()

    async def close(self) -> None:
        """Close the active database connection cleanly."""
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    def _require_conn(self) -> aiosqlite.Connection:
        """Return active connection or raise RuntimeError if uninitialized."""
        if self._conn is None:
            raise RuntimeError("Database connection is not initialized")
        return self._conn

    async def insert_event(self, event: dict[str, Any]) -> int:
        """Persist a security event and return its auto-incremented row ID."""
        conn = self._require_conn()
        params = (
            event.get("timestamp", ""),
            event.get("engine", "PROCESS"),
            event.get("severity", "INFO"),
            event.get("process_name"),
            event.get("process_path"),
            event.get("remote_ip"),
            event.get("country"),
            event.get("file_path"),
            event.get("description", ""),
            event.get("action_taken"),
            event.get("confirmed_by"),
        )
        cursor = await conn.execute(models.INSERT_EVENT_SQL, params)
        await conn.commit()
        return int(cursor.lastrowid or 0)

    async def get_recent_events(self, limit: int = DEFAULT_EVENTS_LIMIT) -> list[dict[str, Any]]:
        """Return the most recent events up to the requested limit."""
        conn = self._require_conn()
        cursor = await conn.execute(models.SELECT_RECENT_EVENTS_SQL, (limit,))
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]

    async def get_events_by_date(self, date_str: str) -> list[dict[str, Any]]:
        """Return all events recorded on a given YYYY-MM-DD date."""
        conn = self._require_conn()
        cursor = await conn.execute(models.SELECT_EVENTS_BY_DATE_SQL, (date_str,))
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]

    async def record_event_action(self, event_id: int, action: str, actor: str) -> None:
        """Update action_taken and confirmed_by on an existing event row."""
        conn = self._require_conn()
        await conn.execute(models.UPDATE_EVENT_ACTION_SQL, (action, actor, event_id))
        await conn.commit()

    async def get_cached_ip(self, ip: str) -> Optional[dict[str, Any]]:
        """Fetch a cached IP lookup entry if present."""
        conn = self._require_conn()
        cursor = await conn.execute(models.SELECT_IP_CACHE_SQL, (ip,))
        row = await cursor.fetchone()
        return dict(row) if row else None

    async def upsert_cached_ip(self, record: dict[str, Any]) -> None:
        """Insert or update an IP geolocation record in ip_cache."""
        conn = self._require_conn()
        params = (
            record["ip"],
            record.get("country", "Unknown"),
            record.get("country_code", "UN"),
            record.get("org", "Unknown"),
            record.get("isp", "Unknown"),
            int(bool(record.get("is_hosting", False))),
            record["fetched_at"],
        )
        await conn.execute(models.UPSERT_IP_CACHE_SQL, params)
        await conn.commit()

    async def add_allowlist_rule(self, rule: dict[str, Any]) -> int:
        """Insert a new allowlist rule and return its ID."""
        conn = self._require_conn()
        params = (
            rule["process_path"],
            rule["exe_hash"],
            rule["alert_type"],
            rule["added_at"],
            rule.get("expires_at"),
            rule.get("note", ""),
        )
        cursor = await conn.execute(models.INSERT_ALLOWLIST_SQL, params)
        await conn.commit()
        return int(cursor.lastrowid or 0)

    async def list_allowlist_rules(self) -> list[dict[str, Any]]:
        """Return all persisted allowlist rules ordered newest first."""
        conn = self._require_conn()
        cursor = await conn.execute(models.SELECT_ALLOWLIST_SQL)
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]

    async def delete_allowlist_rule(self, rule_id: int) -> bool:
        """Delete an allowlist rule by ID and return whether a row was removed."""
        conn = self._require_conn()
        cursor = await conn.execute(models.DELETE_ALLOWLIST_SQL, (rule_id,))
        await conn.commit()
        return (cursor.rowcount or 0) > 0

    async def get_file_baseline(self, file_path: str) -> Optional[str]:
        """Return stored baseline SHA-256 hash for a watched file path."""
        conn = self._require_conn()
        cursor = await conn.execute(models.SELECT_BASELINE_SQL, (file_path,))
        row = await cursor.fetchone()
        return str(row["sha256_hash"]) if row else None

    async def set_file_baseline(self, file_path: str, sha256_hash: str, ts: str) -> None:
        """Store or update baseline SHA-256 hash for a watched file path."""
        conn = self._require_conn()
        await conn.execute(models.UPSERT_BASELINE_SQL, (file_path, sha256_hash, ts))
        await conn.commit()

    async def save_daily_stats(self, snapshot: dict[str, Any]) -> None:
        """Insert or update daily summary metrics in daily_stats."""
        conn = self._require_conn()
        params = (
            snapshot["date"],
            snapshot["total_events"],
            snapshot["critical_count"],
            snapshot["high_count"],
            snapshot["warn_count"],
            snapshot["info_count"],
            snapshot["actions_taken"],
            snapshot["monitoring_uptime"],
        )
        await conn.execute(models.UPSERT_DAILY_STATS_SQL, params)
        await conn.commit()
