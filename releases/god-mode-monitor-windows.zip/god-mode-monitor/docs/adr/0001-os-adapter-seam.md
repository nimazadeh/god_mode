# Isolate OS-specific privileged actions behind OSAdapter seam

God Mode Monitor targets Windows endpoints (`netsh advfirewall`, PowerShell `Get-AuthenticodeSignature`, `explorer.exe`, and `%APPDATA%` startup shortcuts), while automated verification and CI/browser testing also run on Linux hosts. We place all platform-specific calls behind a single `OSAdapter` interface (`engine/os_adapter.py`) that executes native Windows commands on `win32` and safe local equivalents on POSIX systems, allowing full end-to-end verification without mocking internal engine logic.
