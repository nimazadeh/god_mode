"""Tests for SQLite snapshot persistence, watchlist management, and CSV export."""

from __future__ import annotations

from pathlib import Path

from sentinel.diff_engine import compute_catalog_diff
from sentinel.exporter import export_diff_report_to_csv
from sentinel.extractor import build_verified_Reference_catalog
from sentinel.storage import SnapshotRepository


def test_snapshot_repository_persists_and_rotates_baseline(tmp_path: Path) -> None:
    """Verify first snapshot becomes baseline automatically and can be rotated later."""
    db_file = tmp_path / "test_sentinel.db"
    repo = SnapshotRepository(db_file)

    first_snap = repo.save_snapshot(
        products=build_verified_Reference_catalog("baseline"),
        source_mode="verified_catalog",
        note="First scan",
    )
    assert first_snap.is_baseline is True

    second_snap = repo.save_snapshot(
        products=build_verified_Reference_catalog("current"),
        source_mode="verified_catalog",
        note="Second scan",
    )
    assert second_snap.is_baseline is False

    active_baseline = repo.get_baseline_snapshot()
    assert active_baseline is not None
    assert active_baseline.snapshot_id == first_snap.snapshot_id

    rotated = repo.set_baseline_snapshot(second_snap.snapshot_id)
    assert rotated is not None
    assert rotated.is_baseline is True
    assert repo.get_baseline_snapshot().snapshot_id == second_snap.snapshot_id


def test_watchlist_crud_and_csv_export(tmp_path: Path) -> None:
    """Verify watchlist URL normalization and UTF-8 BOM CSV formatting."""
    db_file = tmp_path / "watchlist_test.db"
    repo = SnapshotRepository(db_file)

    added = repo.add_watchlist_item(
        "https://giyahkala.com/product/dry-sage-plant/",
        label="Sage Bulk",
    )
    assert added["slug"] == "dry-sage-plant"
    assert len(repo.list_watchlist_items()) == 1
    assert repo.remove_watchlist_item("dry-sage-plant") is True
    assert len(repo.list_watchlist_items()) == 0

    snap_a = repo.save_snapshot(build_verified_Reference_catalog("baseline"))
    snap_b = repo.save_snapshot(build_verified_Reference_catalog("current"))
    report = compute_catalog_diff(snap_a, snap_b, changed_only=True)

    csv_output = export_diff_report_to_csv(report, include_utf8_bom=True)
    assert csv_output.startswith("\ufeff")
    assert "Product ID,SKU,Slug,Product Name" in csv_output
    assert "dry-sage-plant" in csv_output
    assert "2360000" in csv_output
