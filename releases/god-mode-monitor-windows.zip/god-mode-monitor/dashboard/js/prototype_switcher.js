/* UI Prototype Variant Switcher (?variant=A|B), Workbench Tabs, and Live Filter */
const PROTO_VARIANTS = [
  { key: "A", name: "A (Tactical Command Grid)" },
  { key: "B", name: "B (SOC Incident Split + Workbench)" },
];

window.GodProto = {
  current: "A",
  wbTab: "processes",
  searchQuery: "",
  threatsOnly: false,

  init(onFilterChange) {
    const params = new URLSearchParams(window.location.search);
    const saved = localStorage.getItem("god_mode_variant") || "A";
    const initial = (params.get("variant") || saved).toUpperCase();
    this.applyVariant(PROTO_VARIANTS.some((v) => v.key === initial) ? initial : "A");
    document.getElementById("proto-prev-btn")?.addEventListener("click", () => this.cycle(-1));
    document.getElementById("proto-next-btn")?.addEventListener("click", () => this.cycle(1));
    document.querySelectorAll(".wb-tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => this.setWorkbenchTab(btn.dataset.tab));
    });
    const searchEl = document.getElementById("quick-search-input");
    searchEl?.addEventListener("input", () => {
      this.searchQuery = searchEl.value.trim().toLowerCase();
      onFilterChange();
    });
    const threatBtn = document.getElementById("threats-only-btn");
    threatBtn?.addEventListener("click", () => {
      this.threatsOnly = !this.threatsOnly;
      threatBtn.classList.toggle("active", this.threatsOnly);
      onFilterChange();
    });
  },

  cycle(delta) {
    const idx = PROTO_VARIANTS.findIndex((v) => v.key === this.current);
    this.applyVariant(PROTO_VARIANTS[(idx + delta + PROTO_VARIANTS.length) % PROTO_VARIANTS.length].key);
  },

  applyVariant(key) {
    this.current = key;
    localStorage.setItem("god_mode_variant", key);
    const grid = document.querySelector(".app-grid");
    if (grid) { grid.classList.remove("variant-a", "variant-b"); grid.classList.add(`variant-${key.toLowerCase()}`); }
    const url = new URL(window.location.href);
    url.searchParams.set("variant", key);
    window.history.replaceState({}, "", url.toString());
    const found = PROTO_VARIANTS.find((v) => v.key === key) || PROTO_VARIANTS[0];
    const label = document.getElementById("proto-variant-label");
    if (label) label.textContent = `Variant ${found.name}`;
    document.getElementById("wb-tabs-group")?.classList.toggle("hidden", key !== "B");
    this.syncWorkbenchVisibility();
  },

  setWorkbenchTab(tabName) {
    if (tabName === "persistence") { window.GodV25?.togglePortsDrawer(true); return; }
    if (tabName === "http_rfc") { window.GodRfc?.toggleDrawer(true); return; }
    this.wbTab = tabName;
    document.querySelectorAll(".wb-tab-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === tabName));
    this.syncWorkbenchVisibility();
  },

  syncWorkbenchVisibility() {
    const els = ["panel-processes", "panel-connections", "mid-split-section", "file-guard-section"].map((id) => document.getElementById(id));
    if (this.current !== "B") { els.forEach((el) => el?.classList.remove("wb-hidden")); return; }
    els[2]?.classList.toggle("wb-hidden", this.wbTab === "files");
    els[3]?.classList.toggle("wb-hidden", this.wbTab !== "files");
    els[0]?.classList.toggle("wb-hidden", this.wbTab !== "processes");
    els[1]?.classList.toggle("wb-hidden", this.wbTab !== "connections");
  },
};
