/* Real-time Alert Feed renderer with DOM cap (200), selection state, and empty state */
window.GodAlerts = {
  selectedAlert: null,

  createBadge(severity) {
    const span = document.createElement("span");
    const sev = String(severity || "INFO").toUpperCase();
    span.className = `badge badge-${sev.toLowerCase()}`;
    span.textContent = sev;
    return span;
  },

  buildActionButtons(alertObj, rowEl) {
    const wrap = document.createElement("div");
    wrap.className = "mode-group";
    const actions = alertObj.actions_available || ["allow", "ignore"];
    actions.forEach((act) => {
      if (act === "kill" && !alertObj.pid) return;
      if (act === "block" && !alertObj.remote_ip) return;
      const btn = document.createElement("button");
      btn.className = "action-btn";
      btn.textContent = act.charAt(0).toUpperCase() + act.slice(1);
      const map = { kill: "kill_process", block: "block_ip", quarantine: "quarantine_file" };
      const mapped = map[act] || act;
      btn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        if (mapped === "ignore") rowEl.classList.add("alert-exit");
        window.GodCommands.requestAction(mapped, alertObj);
      });
      wrap.appendChild(btn);
    });
    return wrap;
  },

  createAlertRow(alertObj, isNew) {
    const row = document.createElement("div");
    row.className = "alert-row";
    row.dataset.alertId = alertObj.id;
    if (isNew) row.classList.add("alert-enter");
    if (alertObj.severity === "CRITICAL") row.classList.add("alert-critical-flash");
    const mid = document.createElement("div");
    const timeStr = (alertObj.timestamp || "").slice(11, 19) || alertObj.timestamp;
    const reviewPrefix = alertObj.needs_review ? "[NEEDS REVIEW] " : "";
    mid.textContent = `${timeStr} | ${alertObj.process || "System"} | ${reviewPrefix}${alertObj.description}`;
    row.appendChild(this.createBadge(alertObj.severity));
    row.appendChild(mid);
    row.appendChild(this.buildActionButtons(alertObj, row));
    row.addEventListener("click", () => {
      this.selectedAlert = alertObj;
      document.querySelectorAll("#alert-feed-list .alert-row").forEach((el) => el.classList.remove("row-selected"));
      row.classList.add("row-selected");
      window.GodCommands.showToast(`Selected alert: ${alertObj.process}`);
    });
    return row;
  },

  renderFeed(alertsList, maxAlerts) {
    const container = document.getElementById("alert-feed-list");
    if (!container) return;
    container.textContent = "";
    const active = (alertsList || []).filter((a) => !a.resolved).slice(0, maxAlerts);
    if (active.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = "All monitored subsystems nominal — watching processes, sockets & critical files.";
      container.appendChild(empty);
      return;
    }
    active.forEach((item) => container.appendChild(this.createAlertRow(item, false)));
  },

  prependAlert(alertObj, maxAlerts) {
    const container = document.getElementById("alert-feed-list");
    if (!container) return;
    const empty = container.querySelector(".empty-state");
    if (empty) empty.remove();
    container.prepend(this.createAlertRow(alertObj, true));
    while (container.children.length > maxAlerts) container.removeChild(container.lastChild);
  },
};
