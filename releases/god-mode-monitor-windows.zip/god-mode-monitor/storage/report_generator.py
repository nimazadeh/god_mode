"""Self-contained Daily HTML Report generator with inline CSS styling."""

from collections import Counter
from datetime import datetime, timedelta
from html import escape
from pathlib import Path
from typing import Any
from constants import HOURS_IN_DAY, REPORTS_DIR
from storage.db import Database

REPORT_STYLE = """
:root { --bg: #0D0D0D; --panel: #141414; --card: #181818; --red: #FF2222;
--text: #F0F0F0; --muted: #999999; --border: #222222; --info: #4444FF;
--warn: #FFB800; --high: #FF6600; }
body { background: var(--bg); color: var(--text); font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; margin: 24px; }
h1, h2 { text-transform: uppercase; letter-spacing: 0.1em; color: var(--text); }
.panel { background: var(--panel); border: 1px solid var(--border); border-left: 3px solid var(--red); padding: 16px; margin-bottom: 18px; }
.cards { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 18px; }
.card { background: var(--card); border: 1px solid var(--border); border-left: 3px solid var(--red); padding: 14px; }
.num { font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; font-size: 1.8rem; color: var(--red); font-variant-numeric: tabular-nums; }
.lbl { color: var(--muted); font-size: 0.75rem; text-transform: uppercase; }
.timeline { display: grid; grid-template-columns: repeat(24, 1fr); gap: 4px; align-items: end; height: 90px; padding-top: 12px; }
.bar { background: var(--red); min-height: 6px; text-align: center; font-size: 0.65rem; }
.bar.unmonitored { background: #333333; color: var(--muted); }
table { width: 100%; border-collapse: collapse; font-family: 'Inter', 'Segoe UI', system-ui, sans-serif; font-variant-numeric: tabular-nums; font-size: 0.85rem; }
th, td { border-bottom: 1px solid var(--border); padding: 8px; text-align: left; }
th { color: var(--muted); text-transform: uppercase; }
"""


class ReportGenerator:
    """Builds daily self-contained security HTML reports from SQLite telemetry."""

    def __init__(self, db: Database, reports_dir: Path = REPORTS_DIR) -> None:
        self.db = db
        self.reports_dir = reports_dir
        self.reports_dir.mkdir(parents=True, exist_ok=True)

    def _count_severities(self, events: list[dict[str, Any]]) -> dict[str, int]:
        """Tally event counts per severity level and actions taken."""
        counts = {"CRITICAL": 0, "HIGH": 0, "WARN": 0, "INFO": 0, "ACTIONS": 0}
        for ev in events:
            sev = str(ev.get("severity", "INFO")).upper()
            if sev in counts:
                counts[sev] += 1
            if ev.get("action_taken"):
                counts["ACTIONS"] += 1
        return counts

    def _build_hourly_grid(self, events: list[dict[str, Any]]) -> tuple[str, list[str]]:
        """Render the 24-column CSS grid bar chart and list unmonitored hours."""
        buckets: Counter[int] = Counter(
            int(str(e.get("timestamp", ""))[11:13])
            for e in events
            if len(str(e.get("timestamp", ""))) >= 13 and str(e.get("timestamp", ""))[11:13].isdigit()
        )
        max_v = max(buckets.values(), default=1)
        bars, unmonitored = [], []
        for hr in range(HOURS_IN_DAY):
            cnt = buckets.get(hr, 0)
            if cnt == 0:
                unmonitored.append(f"{hr:02d}:00–{hr:02d}:59")
            pct = max(12, int((cnt / max_v) * 100)) if cnt else 15
            cls = "bar" if cnt > 0 else "bar unmonitored"
            bars.append(f'<div class="{cls}" style="height:{pct}%" title="{hr:02d}:00 ({cnt})">{hr:02d}</div>')
        return "".join(bars), unmonitored

    def _build_top_rows(self, events: list[dict[str, Any]], key: str, extra: str) -> str:
        """Render top 5 rows for suspicious processes or foreign IPs."""
        counter: Counter[tuple[str, str]] = Counter()
        for ev in events:
            val = ev.get(key)
            if val and ev.get("severity") != "INFO":
                counter[(str(val), str(ev.get(extra) or "Unknown"))] += 1
        if not counter:
            return "<tr><td colspan='3'>No suspicious records recorded</td></tr>"
        rows = []
        for (primary, secondary), count in counter.most_common(5):
            rows.append(f"<tr><td>{escape(primary)}</td><td>{escape(secondary)}</td><td>{count}</td></tr>")
        return "".join(rows)

    def _build_event_rows(self, events: list[dict[str, Any]], filter_fn: Any) -> str:
        """Render table rows for filtered file events or user actions."""
        matched = [e for e in events if filter_fn(e)]
        if not matched:
            return "<tr><td colspan='4'>None recorded in this period</td></tr>"
        rows = []
        for ev in matched[:25]:
            col1 = escape(str(ev.get("timestamp", "")))
            col2 = escape(str(ev.get("file_path") or ev.get("process_name") or ev.get("remote_ip") or "-"))
            col3 = escape(str(ev.get("description", "")))
            col4 = escape(str(ev.get("action_taken") or ev.get("severity") or "-"))
            rows.append(f"<tr><td>{col1}</td><td>{col2}</td><td>{col3}</td><td>{col4}</td></tr>")
        return "".join(rows)

    def _assemble_html(self, date_str: str, events: list[dict[str, Any]], counts: dict[str, int]) -> str:
        """Compose the complete standalone HTML document with all 8 sections."""
        bars_html, gaps = self._build_hourly_grid(events)
        uptime_pct = round(((HOURS_IN_DAY - len(gaps)) / HOURS_IN_DAY) * 100, 1)
        proc_rows = self._build_top_rows(events, "process_name", "process_path")
        ip_rows = self._build_top_rows(events, "remote_ip", "country")
        file_rows = self._build_event_rows(events, lambda e: e.get("engine") == "FILE")
        act_rows = self._build_event_rows(events, lambda e: bool(e.get("action_taken")))
        gap_txt = ", ".join(gaps[:12]) if gaps else "Continuous monitoring (0 gaps)"
        cards = "".join(f"<div class='card'><div class='num'>{counts[k]}</div><div class='lbl'>{k.title()}</div></div>" for k in ("CRITICAL", "HIGH", "WARN", "INFO"))
        return (
            f"<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'><title>God Mode Report {escape(date_str)}</title><style>{REPORT_STYLE}</style></head><body>"
            f"<div class='panel'><h1>God Mode Monitor — Daily Security Report</h1><p>Date: <b>{escape(date_str)}</b> | Total Events: <b>{len(events)}</b> | Monitored Coverage: <b>{uptime_pct}%</b></p></div>"
            f"<div class='cards'>{cards}</div><div class='panel'><h2>Hour-by-Hour Timeline (24h)</h2><div class='timeline'>{bars_html}</div></div>"
            f"<div class='panel'><h2>Top 5 Suspicious Processes</h2><table><tr><th>Process</th><th>Path</th><th>Events</th></tr>{proc_rows}</table></div>"
            f"<div class='panel'><h2>Top 5 Foreign IPs Contacted</h2><table><tr><th>Remote IP</th><th>Country</th><th>Events</th></tr>{ip_rows}</table></div>"
            f"<div class='panel'><h2>File Integrity Events</h2><table><tr><th>Time</th><th>File Path</th><th>Details</th><th>Severity</th></tr>{file_rows}</table></div>"
            f"<div class='panel'><h2>Actions Taken</h2><table><tr><th>Time</th><th>Target</th><th>Reason</th><th>Action</th></tr>{act_rows}</table></div>"
            f"<div class='panel'><h2>Periods Not Monitored</h2><p>{escape(gap_txt)}</p></div></body></html>"
        )

    async def generate_for_date(self, date_str: str, uptime_str: str = "24h 00m") -> Path:
        """Generate and persist the HTML report and daily_stats row for date_str."""
        events = await self.db.get_events_by_date(date_str)
        counts = self._count_severities(events)
        await self.db.save_daily_stats({
            "date": date_str, "total_events": len(events),
            "critical_count": counts["CRITICAL"], "high_count": counts["HIGH"],
            "warn_count": counts["WARN"], "info_count": counts["INFO"],
            "actions_taken": counts["ACTIONS"], "monitoring_uptime": uptime_str,
        })
        html_doc = self._assemble_html(date_str, events, counts)
        out_path = self.reports_dir / f"{date_str}.html"
        out_path.write_text(html_doc, encoding="utf-8")
        return out_path

    async def ensure_recent_reports(self) -> list[str]:
        """Generate any missing daily report for yesterday and today on startup."""
        generated: list[str] = []
        today = datetime.now().date()
        for offset in (1, 0):
            day_str = (today - timedelta(days=offset)).isoformat()
            target = self.reports_dir / f"{day_str}.html"
            if not target.exists():
                await self.generate_for_date(day_str)
                generated.append(day_str)
        return generated
