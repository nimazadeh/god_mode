/*
 * GiyahKala Price Sentinel Frontend Controller
 * Why: Separates state management, API communication, and safe DOM rendering
 * using createElement and textContent so zero untrusted HTML is ever injected.
 */

(function () {
  "use strict";

  var appState = {
    diffReport: null,
    snapshots: [],
    watchlist: [],
    activeFilter: "changed_only",
    searchQuery: "",
    selectedProductId: null,
    isScanning: false
  };

  function formatToman(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) {
      return "—";
    }
    return Number(value).toLocaleString("en-US");
  }

  function formatSignedToman(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) {
      return "—";
    }
    var numeric = Number(value);
    if (numeric > 0) {
      return "+" + numeric.toLocaleString("en-US");
    }
    if (numeric < 0) {
      return numeric.toLocaleString("en-US");
    }
    return "0";
  }

  function formatPercentage(value) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) {
      return "—";
    }
    var numeric = Number(value);
    var prefix = numeric > 0 ? "+" : "";
    return prefix + numeric.toFixed(2) + "%";
  }

  function formatSourceModePersian(mode) {
    if (mode === "live") {
      return "سایت زنده";
    }
    if (mode === "verified_catalog" || mode === "verified_catalog_fallback") {
      return "کاتالوگ مرجع";
    }
    return mode || "کاتالوگ";
  }

  function formatOptionSummaryPersian(rawSummary) {
    if (!rawSummary) {
      return "";
    }
    var cleaned = String(rawSummary)
      .replace(/New catalog product discovered/g, "کالای جدید در کاتالوگ")
      .replace(/Variant Tier/g, "سطح آپشن")
      .replace(/Option Tier/g, "سطح آپشن")
      .replace(/Added /g, "افزودن آپشن ")
      .replace(/Removed /g, "حذف آپشن ")
      .replace(/ -> /g, " ← ")
      .replace(/ IRT/g, " تومان")
      .replace(/; /g, " ، ");
    if (cleaned.length > 140) {
      return cleaned.slice(0, 140) + "…";
    }
    return cleaned;
  }

  function getStatusMeta(changeType) {
    var mapping = {
      price_increased: { label: "▲ افزایش قیمت", cssClass: "status-pill-up" },
      price_decreased: { label: "▼ کاهش قیمت", cssClass: "status-pill-down" },
      option_changed: { label: "◆ تغییر آپشن", cssClass: "status-pill-info" },
      stock_changed: { label: "● تغییر موجودی", cssClass: "status-pill-warn" },
      new_product: { label: "★ کالای جدید", cssClass: "status-pill-info" },
      removed_product: { label: "✕ حذف شده", cssClass: "status-pill-warn" },
      unchanged: { label: "بدون تغییر", cssClass: "status-pill-neutral" }
    };
    return mapping[changeType] || mapping.unchanged;
  }

  function setStatusBanner(message, isError) {
    var banner = document.getElementById("live-status-region");
    var msgEl = document.getElementById("status-message-text");
    var timeEl = document.getElementById("status-timestamp-text");
    if (!banner || !msgEl) {
      return;
    }
    msgEl.textContent = message;
    if (timeEl) {
      var now = new Date();
      timeEl.textContent = now.toISOString().slice(11, 19) + " UTC";
    }
    if (isError) {
      banner.style.borderColor = "var(--status-up-border)";
      banner.style.backgroundColor = "var(--status-up-bg)";
      banner.style.color = "var(--status-up-text)";
    } else {
      banner.style.borderColor = "var(--status-info-border)";
      banner.style.backgroundColor = "var(--status-info-bg)";
      banner.style.color = "var(--status-info-text)";
    }
  }

  function filterDiffItems(items) {
    var activeFilter = appState.activeFilter;
    var query = (appState.searchQuery || "").trim().toLowerCase();

    return items.filter(function (item) {
      var matchesTab = true;
      if (activeFilter === "changed_only") {
        matchesTab = item.change_type !== "unchanged";
      } else if (activeFilter === "price_increased") {
        matchesTab = item.change_type === "price_increased";
      } else if (activeFilter === "price_decreased") {
        matchesTab = item.change_type === "price_decreased";
      } else if (activeFilter === "option_or_stock") {
        matchesTab =
          item.change_type === "option_changed" ||
          item.change_type === "stock_changed";
      } else if (activeFilter === "new_product") {
        matchesTab = item.change_type === "new_product";
      }

      if (!matchesTab) {
        return false;
      }

      if (!query) {
        return true;
      }

      var haystack = [
        item.name || "",
        item.sku || "",
        item.slug || "",
        item.category || ""
      ]
        .join(" ")
        .toLowerCase();
      return haystack.indexOf(query) !== -1;
    });
  }

  function updateSummaryMetrics(report) {
    var allItems = report.items || [];
    var summary = report.summary || {};
    var optionAndStockCount =
      Number(summary.option_changed_count || 0) +
      Number(summary.stock_changed_count || 0);

    document.getElementById("metric-total-changed").textContent = String(
      summary.total_changed || 0
    );
    document.getElementById("metric-price-increased").textContent = String(
      summary.price_increased_count || 0
    );
    document.getElementById("metric-price-decreased").textContent = String(
      summary.price_decreased_count || 0
    );
    document.getElementById("metric-option-stock").textContent = String(
      optionAndStockCount
    );
    document.getElementById("metric-new-products").textContent = String(
      summary.new_product_count || 0
    );
    document.getElementById("metric-total-monitored").textContent = String(
      summary.total_compared || allItems.length || 0
    );

    document.getElementById("count-changed-only").textContent = String(
      summary.total_changed || 0
    );
    document.getElementById("count-price-increased").textContent = String(
      summary.price_increased_count || 0
    );
    document.getElementById("count-price-decreased").textContent = String(
      summary.price_decreased_count || 0
    );
    document.getElementById("count-option-stock").textContent = String(
      optionAndStockCount
    );
    document.getElementById("count-new-product").textContent = String(
      summary.new_product_count || 0
    );
    document.getElementById("count-all").textContent = String(allItems.length);

    document.getElementById("baseline-meta-text").textContent =
      "#" + String(report.baseline_snapshot_id);
    document.getElementById("current-meta-text").textContent =
      "#" +
      String(report.current_snapshot_id) +
      " (" +
      formatSourceModePersian(report.source_mode) +
      ")";

    var exportBtn = document.getElementById("btn-export-csv");
    if (exportBtn) {
      var changedOnlyFlag = appState.activeFilter !== "all";
      exportBtn.href =
        "/api/export.csv?changed_only=" +
        String(changedOnlyFlag) +
        "&baseline_id=" +
        String(report.baseline_snapshot_id) +
        "&current_id=" +
        String(report.current_snapshot_id);
    }
  }

  function renderInspector(productItem) {
    var container = document.getElementById("inspector-content");
    var tierList = document.getElementById("inspector-tiers");
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    while (tierList.firstChild) {
      tierList.removeChild(tierList.firstChild);
    }

    if (!productItem) {
      var emptyMsg = document.createElement("p");
      emptyMsg.className = "empty-state";
      emptyMsg.textContent =
        "یک محصول را از جدول انتخاب کنید تا جزئیات قیمت و آپشن‌ها نمایش داده شود.";
      container.appendChild(emptyMsg);
      return;
    }

    var rows = [
      { key: "نام محصول", val: productItem.name },
      { key: "کد کالا (SKU)", val: productItem.sku || "—" },
      { key: "اسلاگ (Slug)", val: productItem.slug },
      { key: "دسته‌بندی", val: productItem.category || "—" },
      {
        key: "قیمت مرجع قبلی",
        val: formatToman(productItem.previous_price_toman) + " تومان"
      },
      {
        key: "قیمت فعلی",
        val: formatToman(productItem.current_price_toman) + " تومان"
      },
      {
        key: "تغییر خالص",
        val:
          formatSignedToman(productItem.delta_toman) +
          " تومان (" +
          formatPercentage(productItem.delta_percent) +
          ")"
      },
      {
        key: "وضعیت موجودی",
        val: productItem.current_in_stock ? "موجود در انبار" : "ناموجود"
      }
    ];

    var fragment = document.createDocumentFragment();
    rows.forEach(function (pair) {
      var rowDiv = document.createElement("div");
      rowDiv.className = "detail-row";

      var keySpan = document.createElement("span");
      keySpan.className = "detail-key";
      keySpan.textContent = pair.key;

      var valSpan = document.createElement("span");
      valSpan.className = "detail-val";
      valSpan.textContent = pair.val;

      rowDiv.appendChild(keySpan);
      rowDiv.appendChild(valSpan);
      fragment.appendChild(rowDiv);
    });

    var linkRow = document.createElement("div");
    linkRow.className = "detail-row";
    var linkKey = document.createElement("span");
    linkKey.className = "detail-key";
    linkKey.textContent = "صفحه محصول";
    var linkAnchor = document.createElement("a");
    linkAnchor.href = productItem.permalink;
    linkAnchor.target = "_blank";
    linkAnchor.rel = "noopener noreferrer";
    linkAnchor.textContent = "مشاهده در giyahkala.com ↗";
    linkAnchor.style.color = "var(--accent-primary)";
    linkAnchor.style.fontWeight = "600";
    linkRow.appendChild(linkKey);
    linkRow.appendChild(linkAnchor);
    fragment.appendChild(linkRow);

    container.appendChild(fragment);

    var tiers = productItem.option_tiers || [];
    if (tiers.length === 0) {
      var noTier = document.createElement("li");
      noTier.className = "tier-item";
      noTier.textContent = "بدون آپشن فرعی (قیمت تک‌سطحی استاندارد).";
      tierList.appendChild(noTier);
      return;
    }

    var tierFrag = document.createDocumentFragment();
    tiers.forEach(function (tier) {
      var li = document.createElement("li");
      li.className = "tier-item";

      var labelSpan = document.createElement("span");
      var groupLabel = (tier.group_name || "")
        .replace(/Variant Tier/g, "سطح آپشن")
        .replace(/Option Tier/g, "سطح آپشن");
      labelSpan.textContent =
        (groupLabel ? groupLabel + " — " : "") + tier.option_label;

      var priceSpan = document.createElement("span");
      priceSpan.className = "tier-price";
      priceSpan.textContent = formatToman(tier.price_toman) + " تومان";

      li.appendChild(labelSpan);
      li.appendChild(priceSpan);
      tierFrag.appendChild(li);
    });
    tierList.appendChild(tierFrag);
  }

  function renderDiffTable() {
    var tbody = document.getElementById("diff-table-body");
    while (tbody.firstChild) {
      tbody.removeChild(tbody.firstChild);
    }

    if (!appState.diffReport || !appState.diffReport.items) {
      var emptyRow = document.createElement("tr");
      var emptyCell = document.createElement("td");
      emptyCell.colSpan = 8;
      emptyCell.className = "empty-state";
      emptyCell.textContent = "هیچ اسنپ‌شاتی برای نمایش وجود ندارد.";
      emptyRow.appendChild(emptyCell);
      tbody.appendChild(emptyRow);
      return;
    }

    var filtered = filterDiffItems(appState.diffReport.items);
    if (filtered.length === 0) {
      var noneRow = document.createElement("tr");
      var noneCell = document.createElement("td");
      noneCell.colSpan = 8;
      noneCell.className = "empty-state";
      noneCell.textContent =
        "هیچ کالایی با فیلتر انتخاب‌شده مطابقت ندارد. تب «همه کالاها» را بررسی کنید.";
      noneRow.appendChild(noneCell);
      tbody.appendChild(noneRow);
      renderInspector(null);
      return;
    }

    if (
      !appState.selectedProductId ||
      !filtered.some(function (i) {
        return i.product_id === appState.selectedProductId;
      })
    ) {
      appState.selectedProductId = filtered[0].product_id;
    }

    var fragment = document.createDocumentFragment();
    filtered.forEach(function (item) {
      var tr = document.createElement("tr");
      tr.dataset.productId = String(item.product_id);
      if (item.product_id === appState.selectedProductId) {
        tr.className = "row-selected";
      }

      tr.addEventListener("click", function () {
        appState.selectedProductId = item.product_id;
        renderDiffTable();
      });

      // 1. Product Name & SKU
      var tdName = document.createElement("td");
      tdName.className = "cell-product";
      tdName.setAttribute("data-label", "محصول");
      var titleWrap = document.createElement("div");
      titleWrap.className = "product-title-cell";
      var nameSpan = document.createElement("span");
      nameSpan.className = "product-name-text";
      nameSpan.textContent = item.name;
      var metaSub = document.createElement("span");
      metaSub.className = "product-meta-sub";
      metaSub.textContent = "SKU: " + (item.sku || "—") + " · /" + item.slug;
      titleWrap.appendChild(nameSpan);
      titleWrap.appendChild(metaSub);
      tdName.appendChild(titleWrap);

      // 2. Category
      var tdCat = document.createElement("td");
      tdCat.className = "cell-category";
      tdCat.setAttribute("data-label", "دسته‌بندی");
      tdCat.textContent = item.category || "—";

      // 3. Status Badge
      var tdStatus = document.createElement("td");
      tdStatus.className = "cell-status";
      tdStatus.setAttribute("data-label", "وضعیت");
      var pill = document.createElement("span");
      var statusMeta = getStatusMeta(item.change_type);
      pill.className = "status-pill " + statusMeta.cssClass;
      pill.textContent = statusMeta.label;
      tdStatus.appendChild(pill);

      // 4. Baseline Price
      var tdPrev = document.createElement("td");
      tdPrev.className = "num-col cell-prev";
      tdPrev.setAttribute("data-label", "قیمت قبلی (تومان)");
      tdPrev.textContent = formatToman(item.previous_price_toman);

      // 5. Current Price
      var tdCurr = document.createElement("td");
      tdCurr.className = "num-col cell-curr";
      tdCurr.setAttribute("data-label", "قیمت فعلی (تومان)");
      tdCurr.textContent = formatToman(item.current_price_toman);

      // 6. Delta (IRT)
      var tdDelta = document.createElement("td");
      tdDelta.className = "num-col cell-delta";
      tdDelta.setAttribute("data-label", "مقدار تغییر (تومان)");
      if (item.delta_toman > 0) {
        tdDelta.classList.add("delta-positive");
      } else if (item.delta_toman < 0) {
        tdDelta.classList.add("delta-negative");
      } else {
        tdDelta.classList.add("delta-zero");
      }
      tdDelta.textContent = formatSignedToman(item.delta_toman);

      // 7. Delta (%)
      var tdPct = document.createElement("td");
      tdPct.className = "num-col cell-pct";
      tdPct.setAttribute("data-label", "درصد تغییر");
      if (item.delta_toman > 0) {
        tdPct.classList.add("delta-positive");
      } else if (item.delta_toman < 0) {
        tdPct.classList.add("delta-negative");
      } else {
        tdPct.classList.add("delta-zero");
      }
      tdPct.textContent = formatPercentage(item.delta_percent);

      // 8. Option / Stock Notes
      var tdNotes = document.createElement("td");
      tdNotes.className = "cell-notes";
      tdNotes.setAttribute("data-label", "جزئیات آپشن و موجودی");
      var notesParts = [];
      if (item.option_change_summary) {
        notesParts.push(formatOptionSummaryPersian(item.option_change_summary));
      }
      if (
        item.previous_in_stock !== null &&
        item.previous_in_stock !== item.current_in_stock
      ) {
        notesParts.push(
          item.current_in_stock ? "موجود شد" : "ناموجود شد"
        );
      } else if (!item.current_in_stock) {
        notesParts.push("ناموجود");
      }
      tdNotes.textContent =
        notesParts.length > 0 ? notesParts.join(" | ") : "پایدار";

      tr.appendChild(tdName);
      tr.appendChild(tdCat);
      tr.appendChild(tdStatus);
      tr.appendChild(tdPrev);
      tr.appendChild(tdCurr);
      tr.appendChild(tdDelta);
      tr.appendChild(tdPct);
      tr.appendChild(tdNotes);
      fragment.appendChild(tr);
    });

    tbody.appendChild(fragment);

    var selectedObj = filtered.find(function (i) {
      return i.product_id === appState.selectedProductId;
    });
    renderInspector(selectedObj || filtered[0]);
  }

  function renderSnapshotsDropdown() {
    var selectEl = document.getElementById("select-baseline-snapshot");
    while (selectEl.firstChild) {
      selectEl.removeChild(selectEl.firstChild);
    }

    appState.snapshots.forEach(function (snap) {
      var opt = document.createElement("option");
      opt.value = String(snap.snapshot_id);
      var baseTag = snap.is_baseline ? " [مرجع فعال]" : "";
      opt.textContent =
        "#" +
        String(snap.snapshot_id) +
        " · " +
        snap.created_at_iso +
        baseTag;
      if (
        appState.diffReport &&
        snap.snapshot_id === appState.diffReport.baseline_snapshot_id
      ) {
        opt.selected = true;
      }
      selectEl.appendChild(opt);
    });
  }

  function renderWatchlist() {
    var listEl = document.getElementById("watchlist-container");
    while (listEl.firstChild) {
      listEl.removeChild(listEl.firstChild);
    }

    if (appState.watchlist.length === 0) {
      var emptyLi = document.createElement("li");
      emptyLi.className = "watchlist-row";
      emptyLi.textContent = "هنوز محصولی در دیده‌بان ثبت نشده است.";
      listEl.appendChild(emptyLi);
      return;
    }

    var frag = document.createDocumentFragment();
    appState.watchlist.forEach(function (entry) {
      var li = document.createElement("li");
      li.className = "watchlist-row";

      var slugSpan = document.createElement("span");
      slugSpan.className = "watchlist-slug";
      slugSpan.textContent = entry.slug;

      var removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "btn-icon-remove";
      removeBtn.textContent = "حذف";
      removeBtn.setAttribute("aria-label", "حذف " + entry.slug);
      removeBtn.addEventListener("click", function () {
        removeWatchlistSlug(entry.slug);
      });

      li.appendChild(slugSpan);
      li.appendChild(removeBtn);
      frag.appendChild(li);
    });
    listEl.appendChild(frag);
  }

  function loadInitialDashboard() {
    Promise.all([
      fetch("/api/diff?changed_only=false").then(function (r) {
        return r.json();
      }),
      fetch("/api/snapshots").then(function (r) {
        return r.json();
      }),
      fetch("/api/watchlist").then(function (r) {
        return r.json();
      })
    ])
      .then(function (results) {
        appState.diffReport = results[0];
        appState.snapshots = results[1].snapshots || [];
        appState.watchlist = results[2].items || [];

        updateSummaryMetrics(appState.diffReport);
        renderSnapshotsDropdown();
        renderWatchlist();
        renderDiffTable();
      })
      .catch(function (err) {
        setStatusBanner(
          "خطا در بارگذاری داده‌های مقایسه: " + String(err),
          true
        );
      });
  }

  function runOnDemandScan() {
    if (appState.isScanning) {
      return;
    }
    appState.isScanning = true;
    var scanBtn = document.getElementById("btn-run-scan");
    var scanLabel = document.getElementById("btn-run-scan-label");
    scanBtn.disabled = true;
    scanLabel.textContent = "در حال اسکن...";

    var mode = document.getElementById("select-scan-mode").value;
    var categorySlug = document
      .getElementById("input-category-slug")
      .value.trim();
    var enrichHtml = document.getElementById("check-enrich-html").checked;
    var watchlistOnly = document.getElementById("check-watchlist-only").checked;

    setStatusBanner(
      "در حال اجرای اسکن قیمت‌ها (" + formatSourceModePersian(mode) + ")...",
      false
    );

    fetch("/api/scan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        mode: mode,
        max_pages: 2,
        category_slug: categorySlug,
        enrich_html_options: enrichHtml,
        watchlist_only: watchlistOnly
      })
    })
      .then(function (response) {
        if (!response.ok) {
          throw new Error("HTTP " + String(response.status));
        }
        return response.json();
      })
      .then(function (report) {
        appState.diffReport = report;
        updateSummaryMetrics(report);
        renderDiffTable();
        var summary = report.summary || {};
        setStatusBanner(
          "اسکن با موفقیت انجام شد: " +
            String(summary.total_changed || 0) +
            " محصول تغییریافته از مجموع " +
            String(summary.total_compared || 0) +
            " محصول پایش‌شده.",
          false
        );
        return fetch("/api/snapshots").then(function (r) {
          return r.json();
        });
      })
      .then(function (snapData) {
        if (snapData && snapData.snapshots) {
          appState.snapshots = snapData.snapshots;
          renderSnapshotsDropdown();
        }
      })
      .catch(function (err) {
        setStatusBanner("خطا در اجرای اسکن: " + String(err), true);
      })
      .finally(function () {
        appState.isScanning = false;
        scanBtn.disabled = false;
        scanLabel.textContent = "اسکن لحظه‌ای قیمت‌ها";
      });
  }

  function syncCurrentAsBaseline() {
    if (!appState.diffReport) {
      return;
    }
    var currentId = appState.diffReport.current_snapshot_id;
    fetch("/api/baseline/" + String(currentId), { method: "POST" })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (data.diff) {
          appState.diffReport = data.diff;
          updateSummaryMetrics(appState.diffReport);
          renderDiffTable();
        }
        setStatusBanner(
          "اسنپ‌شات مرجع به اسکن شماره #" +
            String(currentId) +
            " تغییر یافت. اسکن‌های بعدی با این مرجع مقایسه می‌شوند.",
          false
        );
        return fetch("/api/snapshots").then(function (r) {
          return r.json();
        });
      })
      .then(function (snapData) {
        if (snapData && snapData.snapshots) {
          appState.snapshots = snapData.snapshots;
          renderSnapshotsDropdown();
        }
      })
      .catch(function (err) {
        setStatusBanner("خطا در ثبت مرجع جدید: " + String(err), true);
      });
  }

  function removeWatchlistSlug(slug) {
    fetch("/api/watchlist/" + encodeURIComponent(slug), { method: "DELETE" })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        appState.watchlist = data.items || [];
        renderWatchlist();
      })
      .catch(function (err) {
        setStatusBanner("خطا در حذف از دیده‌بان: " + String(err), true);
      });
  }

  function bindEventListeners() {
    document
      .getElementById("btn-run-scan")
      .addEventListener("click", runOnDemandScan);

    document
      .getElementById("btn-sync-baseline")
      .addEventListener("click", syncCurrentAsBaseline);

    var filterTabs = document.querySelectorAll(".filter-tab");
    filterTabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        filterTabs.forEach(function (t) {
          t.setAttribute("aria-selected", "false");
        });
        tab.setAttribute("aria-selected", "true");
        appState.activeFilter = tab.dataset.filter || "changed_only";
        if (appState.diffReport) {
          updateSummaryMetrics(appState.diffReport);
        }
        renderDiffTable();
      });
    });

    var searchInput = document.getElementById("input-search-filter");
    var searchFrame = null;
    searchInput.addEventListener("input", function () {
      if (searchFrame) {
        cancelAnimationFrame(searchFrame);
      }
      searchFrame = requestAnimationFrame(function () {
        appState.searchQuery = searchInput.value;
        renderDiffTable();
      });
    });

    var baselineSelect = document.getElementById("select-baseline-snapshot");
    baselineSelect.addEventListener("change", function () {
      var chosenBaselineId = baselineSelect.value;
      if (!chosenBaselineId || !appState.diffReport) {
        return;
      }
      var currentId = appState.diffReport.current_snapshot_id;
      fetch(
        "/api/diff?changed_only=false&baseline_id=" +
          encodeURIComponent(chosenBaselineId) +
          "&current_id=" +
          encodeURIComponent(String(currentId))
      )
        .then(function (r) {
          return r.json();
        })
        .then(function (report) {
          appState.diffReport = report;
          updateSummaryMetrics(report);
          renderDiffTable();
        })
        .catch(function (err) {
          setStatusBanner("خطا در تغییر اسنپ‌شات مرجع: " + String(err), true);
        });
    });

    var watchlistForm = document.getElementById("form-add-watchlist");
    watchlistForm.addEventListener("submit", function (event) {
      event.preventDefault();
      var input = document.getElementById("input-watchlist-slug");
      var rawValue = input.value.trim();
      if (!rawValue) {
        return;
      }
      fetch("/api/watchlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug_or_url: rawValue, label: "" })
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (data) {
          input.value = "";
          appState.watchlist = data.items || [];
          renderWatchlist();
          setStatusBanner("محصول به لیست دیده‌بان اضافه شد.", false);
        })
        .catch(function (err) {
          setStatusBanner("خطا در افزودن به دیده‌بان: " + String(err), true);
        });
    });

    var copyBtn = document.getElementById("btn-copy-product-summary");
    copyBtn.addEventListener("click", function () {
      if (!appState.diffReport || !appState.diffReport.items) {
        return;
      }
      var item = appState.diffReport.items.find(function (i) {
        return i.product_id === appState.selectedProductId;
      });
      if (!item) {
        return;
      }
      var summaryText =
        item.name +
        " (SKU: " +
        item.sku +
        ") | قیمت قبلی: " +
        formatToman(item.previous_price_toman) +
        " تومان -> قیمت فعلی: " +
        formatToman(item.current_price_toman) +
        " تومان (" +
        formatSignedToman(item.delta_toman) +
        " تومان)";
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard
          .writeText(summaryText)
          .then(function () {
            var labelEl = document.getElementById("btn-copy-label");
            labelEl.textContent = "کپی شد";
            setTimeout(function () {
              labelEl.textContent = "کپی خلاصه";
            }, 1400);
          })
          .catch(function () {});
      }
    });

    // Keyboard shortcuts (Linear precision interaction)
    document.addEventListener("keydown", function (event) {
      var activeTag = document.activeElement
        ? document.activeElement.tagName
        : "";
      if (
        activeTag === "INPUT" ||
        activeTag === "TEXTAREA" ||
        activeTag === "SELECT"
      ) {
        return;
      }
      if (event.key === "/") {
        event.preventDefault();
        searchInput.focus();
      } else if (event.key === "s" || event.key === "S") {
        event.preventDefault();
        runOnDemandScan();
      } else if (event.key === "e" || event.key === "E") {
        event.preventDefault();
        var exportLink = document.getElementById("btn-export-csv");
        if (exportLink) {
          exportLink.click();
        }
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    bindEventListeners();
    loadInitialDashboard();
  });
})();
