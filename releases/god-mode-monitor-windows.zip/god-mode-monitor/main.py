"""Entry point for God Mode Monitor: validates config, starts engines, serves FastAPI."""

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sys
from typing import Any, AsyncIterator
import webbrowser
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import fastapi
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
import psutil
import uvicorn
from api.routes import router
from api.schemas import SettingsConfig
from api.websocket import MonitorHub
from constants import (
    DASHBOARD_DIR,
    DB_FILE_PATH,
    LOG_BACKUP_COUNT,
    LOG_FILE_PATH,
    LOG_MAX_BYTES,
    LOGS_DIR,
    SETTINGS_PATH,
)
from engine.event_bus import EventBus
from engine.file_guard import FileGuard
from engine.http_rfc_auditor import HttpRfcAuditor
from engine.ip_lookup import IPLookup
from engine.network_sentinel import NetworkSentinel
from engine.os_adapter import is_Running_as_admin
from engine.persistence_guard import PersistenceGuard
from engine.process_watcher import ProcessWatcher
from engine.quarantine_vault import QuarantineVault
from engine.rfc_firewall import attach_rfc_security_middleware
from storage.db import Database
from storage.report_generator import ReportGenerator


def configure_logging() -> logging.Logger:
    """Configure rotating 10MB file logging and console logging."""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("god_mode")
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        fh = RotatingFileHandler(LOG_FILE_PATH, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


def load_and_validate_settings(settings_file: Path = SETTINGS_PATH) -> SettingsConfig:
    """Validate settings.json against Pydantic schema or raise descriptive error."""
    if not settings_file.exists():
        default_cfg = SettingsConfig.default_settings()
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        settings_file.write_text(json.dumps(default_cfg.model_dump(), indent=2), encoding="utf-8")
        return default_cfg
    raw_data = json.loads(settings_file.read_text(encoding="utf-8"))
    return SettingsConfig.model_validate(raw_data)


def print_startup_banners() -> None:
    """Print runtime package versions and Administrator privilege check."""
    py_ver = sys.version.split()[0]
    print(f"Runtime Versions -> Python: {py_ver} | psutil: {psutil.__version__} | FastAPI: {fastapi.__version__}")
    if not is_Running_as_admin():
        print("WARNING: some features require elevated privileges")
        print("Run as: Right-click -> Run as Administrator")


def _build_monitor_state(db_path: str, settings: SettingsConfig) -> dict[str, Any]:
    """Wire together Database, EventBus, Engines, QuarantineVault, ReportGenerator, and MonitorHub."""
    db = Database(db_path)
    bus = EventBus()
    ip_lookup = IPLookup(db)
    state: dict[str, Any] = {
        "settings": settings, "db": db, "event_bus": bus, "ip_lookup": ip_lookup,
        "process_watcher": ProcessWatcher(bus, settings),
        "network_sentinel": NetworkSentinel(bus, settings, ip_lookup),
        "file_guard": FileGuard(bus, settings, db),
        "persistence_guard": PersistenceGuard(bus),
        "quarantine_vault": QuarantineVault(db),
        "http_rfc_auditor": HttpRfcAuditor(),
        "rfc_firewall_log": [],
        "reports": ReportGenerator(db), "tasks": [], "scheduler": None,
    }
    state["hub"] = MonitorHub(state)
    return state


async def _start_background_services(state: dict[str, Any]) -> None:
    """Start named asyncio engine tasks and midnight APScheduler job."""
    await asyncio.gather(state["file_guard"].initialize_baselines(), state["persistence_guard"].initialize_baseline())
    await asyncio.gather(state["process_watcher"].scan_once(), state["network_sentinel"].scan_once(), state["persistence_guard"].scan_once())
    await state["reports"].ensure_recent_reports()
    state["tasks"] = [
        asyncio.create_task(state["process_watcher"].run(), name="engine_process_watcher"),
        asyncio.create_task(state["network_sentinel"].run(), name="engine_network_sentinel"),
        asyncio.create_task(state["file_guard"].run(), name="engine_file_guard"),
        asyncio.create_task(state["persistence_guard"].run(), name="engine_persistence_guard"),
        asyncio.create_task(state["hub"].run_broadcaster(), name="ws_state_broadcaster"),
    ]
    scheduler = AsyncIOScheduler()
    scheduler.add_job(lambda: asyncio.create_task(state["reports"].generate_for_date(datetime.now().date().isoformat())), trigger="cron", hour=0, minute=0, id="daily_midnight_report")
    scheduler.start()
    state["scheduler"] = scheduler


async def _stop_background_services(state: dict[str, Any]) -> None:
    """Cancel all named engine tasks, stop scheduler, and close SQLite cleanly."""
    if state.get("scheduler"):
        state["scheduler"].shutdown(wait=False)
    for task in state.get("tasks", []):
        task.cancel()
    if state.get("tasks"):
        await asyncio.gather(*state["tasks"], return_exceptions=True)
    await state["db"].close()
    print("God Mode Monitor stopped. All data saved.")


def _make_lifespan(state: dict[str, Any], start_background: bool) -> Any:
    """Build the FastAPI lifespan context manager for startup and shutdown."""
    @asynccontextmanager
    async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
        await state["db"].initialize()
        if start_background:
            await _start_background_services(state)
        else:
            await state["file_guard"].initialize_baselines()
            await state["process_watcher"].scan_once()
        yield
        await _stop_background_services(state)

    return lifespan


def create_app(db_path: str = str(DB_FILE_PATH), start_background: bool = True) -> FastAPI:
    """Create and configure the FastAPI application instance."""
    configure_logging()
    settings = load_and_validate_settings()
    state = _build_monitor_state(db_path, settings)
    app = FastAPI(title="God Mode Monitor", version="1.0.0", lifespan=_make_lifespan(state, start_background))
    app.state.monitor = state
    attach_rfc_security_middleware(app)
    app.include_router(router)
    app.mount("/css", StaticFiles(directory=str(DASHBOARD_DIR / "css")), name="css")
    app.mount("/js", StaticFiles(directory=str(DASHBOARD_DIR / "js")), name="js")
    return app


def handle_first_run() -> int:
    """Configure initial watched_paths interactively or with safe defaults."""
    cfg = load_and_validate_settings()
    try:
        raw = input("Enter comma-separated folders to watch [default: watched_vault]: ").strip()
    except EOFError:
        raw = ""
    if raw:
        cfg.watched_paths = [p.strip() for p in raw.split(",") if p.strip()]
    SETTINGS_PATH.write_text(json.dumps(cfg.model_dump(), indent=2), encoding="utf-8")
    print(f"Saved watched_paths={cfg.watched_paths} to {SETTINGS_PATH}")
    return 0


def main() -> int:
    """Validate settings, launch browser if enabled, and start Uvicorn server."""
    configure_logging()
    if "--first-run" in sys.argv:
        return handle_first_run()
    try:
        settings = load_and_validate_settings()
    except ValidationError as exc:
        for err in exc.errors():
            print(f"INVALID SETTINGS FIELD [{'.'.join(str(x) for x in err.get('loc', []))}]: {err.get('msg')}", file=sys.stderr)
        return 1
    print_startup_banners()
    url = f"http://localhost:{settings.port}"
    if settings.auto_open_browser:
        webbrowser.open(url)
    print(f"✅ God Mode Monitor running at {url}\nPress Ctrl+C to stop.")
    uvicorn.run(create_app(start_background=True), host=settings.host, port=settings.port, log_level="warning")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
