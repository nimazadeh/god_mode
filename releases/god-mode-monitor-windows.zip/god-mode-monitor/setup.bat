@echo off
setlocal enabledelayedexpansion
title God Mode Monitor - One-Click Setup

echo [1/9] Checking Python installation...
where python >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 1 failed: Python is not installed or not in PATH.
    echo Download Python 3.10+ from: https://www.python.org/downloads/
    exit /b 1
)

echo [2/9] Verifying Python version ^>= 3.10...
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)"
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 2 failed: Python 3.10 or newer is required.
    exit /b 1
)

echo [3/9] Creating virtual environment (venv)...
python -m venv venv
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 3 failed: Could not create virtual environment.
    exit /b 1
)

echo [4/9] Activating virtual environment...
call venv\Scripts\activate.bat
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 4 failed: Could not activate venv.
    exit /b 1
)

echo [5/9] Upgrading pip...
python -m pip install --upgrade pip
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 5 failed: pip upgrade failed.
    exit /b 1
)

echo [6/9] Installing latest stable dependencies from requirements.txt...
pip install --upgrade -r requirements.txt
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 6 failed: Dependency installation failed.
    exit /b 1
)

echo [7/9] Downloading local Chart.js bundle to dashboard\js\vendor\chart.min.js...
python -c "import pathlib, urllib.request; pathlib.Path('dashboard/js/vendor').mkdir(parents=True, exist_ok=True); urllib.request.urlretrieve('https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js', 'dashboard/js/vendor/chart.min.js')"
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 7 failed: Could not download Chart.js.
    exit /b 1
)

echo [8/9] Downloading local Lucide bundle to dashboard\js\vendor\lucide.min.js...
python -c "import pathlib, urllib.request; pathlib.Path('dashboard/js/vendor').mkdir(parents=True, exist_ok=True); urllib.request.urlretrieve('https://cdn.jsdelivr.net/npm/lucide@0.479.0/dist/umd/lucide.min.js', 'dashboard/js/vendor/lucide.min.js')"
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 8 failed: Could not download Lucide icons.
    exit /b 1
)

echo [9/9] Running first-time configuration...
python main.py --first-run
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Step 9 failed: First-run configuration failed.
    exit /b 1
)

echo.
echo ✅ Setup complete!
echo Run: venv\Scripts\python main.py
echo Then open: http://localhost:8080
exit /b 0
