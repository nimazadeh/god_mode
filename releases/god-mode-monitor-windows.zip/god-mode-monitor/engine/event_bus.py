"""Asynchronous event bus connecting monitoring engines to the broadcaster."""

import asyncio
from typing import Any


class EventBus:
    """AsyncIO queue wrapper for non-blocking engine telemetry delivery."""

    def __init__(self) -> None:
        self._queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

    async def publish(self, event: dict[str, Any]) -> None:
        """Enqueue a telemetry event asynchronously."""
        await self._queue.put(event)

    def publish_nowait(self, event: dict[str, Any]) -> None:
        """Enqueue an event immediately without awaiting."""
        self._queue.put_nowait(event)

    async def consume(self) -> dict[str, Any]:
        """Wait for and return the next telemetry event from the queue."""
        return await self._queue.get()

    def drain_pending(self) -> list[dict[str, Any]]:
        """Drain all currently queued events without blocking."""
        items: list[dict[str, Any]] = []
        while not self._queue.empty():
            items.append(self._queue.get_nowait())
        return items

    def size(self) -> int:
        """Return the current number of queued events."""
        return self._queue.qsize()
