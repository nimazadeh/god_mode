"""Process monitoring engine polling running host processes via psutil."""

import asyncio
from datetime import datetime
import logging
import time
from typing import Any
import psutil
from api.schemas import SettingsConfig
from constants import (
    BYTES_PER_MB,
    CPU_SPIKE_DURATION_SEC,
    CPU_SPIKE_PERCENT,
    ENGINE_POLL_INTERVAL_SEC,
)
from engine.event_bus import EventBus
from engine.os_adapter import compute_sha256, verify_authenticode_signature
from engine.threat_scorer import score_process_observation

logger = logging.getLogger("god_mode.process")


class ProcessWatcher:
    """Continuously inspects active processes and scores behavioral anomalies."""

    def __init__(self, event_bus: EventBus, settings: SettingsConfig) -> None:
        self.event_bus = event_bus
        self.settings = settings
        self.latest_processes: list[dict[str, Any]] = []
        self._high_cpu_since: dict[int, float] = {}
        self._emitted_keys: set[str] = set()
        self._hash_cache: dict[str, str] = {}

    def _get_cached_hash(self, exe_path: str) -> str:
        """Compute and memoize SHA-256 hash for an executable path."""
        if not exe_path or exe_path.startswith("[") or exe_path == "Unknown":
            return "KERNEL_OR_PROTECTED"
        if exe_path not in self._hash_cache:
            self._hash_cache[exe_path] = compute_sha256(exe_path)
        return self._hash_cache[exe_path]

    def _resolve_exe_path(self, info: dict[str, Any], rss_bytes: int) -> str:
        """Resolve executable path from exe, cmdline, or kernel thread classification."""
        if info.get("exe"):
            return str(info["exe"])
        cmdline = info.get("cmdline") or []
        if cmdline and cmdline[0]:
            return str(cmdline[0])
        return "[OS Kernel Thread]" if rss_bytes == 0 else "[System Protected]"

    def _extract_proc_info(self, proc: psutil.Process, r_ips: list[str]) -> dict[str, Any]:
        """Read safe process attributes from a psutil.Process handle."""
        info = proc.info
        rss_bytes = info.get("memory_info").rss if info.get("memory_info") else 0
        exe_path = self._resolve_exe_path(info, rss_bytes)
        ctime = info.get("create_time") or time.time()
        return {
            "pid": info["pid"],
            "name": info.get("name") or "System",
            "exe": exe_path,
            "create_time": datetime.fromtimestamp(ctime).isoformat(timespec="seconds"),
            "cpu_percent": round(float(info.get("cpu_percent") or 0.0), 1),
            "memory_mb": round(rss_bytes / BYTES_PER_MB, 1),
            "connections": r_ips,
            "status": info.get("status") or "running",
            "sha256": self._get_cached_hash(exe_path),
            "risk_level": "NORMAL",
        }

    def _check_sustained_cpu(self, pid: int, cpu_pct: float) -> bool:
        """Track how long a PID stays above CPU_SPIKE_PERCENT."""
        now = time.monotonic()
        if cpu_pct > CPU_SPIKE_PERCENT:
            start = self._high_cpu_since.setdefault(pid, now)
            return (now - start) >= CPU_SPIKE_DURATION_SEC
        self._high_cpu_since.pop(pid, None)
        return False

    async def _evaluate_process(self, item: dict[str, Any]) -> None:
        """Score a single process record and publish an alert if anomalous."""
        sustained = self._check_sustained_cpu(item["pid"], item["cpu_percent"])
        has_remote = len(item["connections"]) > 0
        is_signed = await verify_authenticode_signature(item["exe"]) if has_remote else True
        sev, alert_type, desc = score_process_observation(
            item, sustained, is_signed, has_remote, False
        )
        item["risk_level"] = "CRITICAL" if sev == "CRITICAL" else ("SUSPICIOUS" if sev in ("WARN", "HIGH") else "NORMAL")
        dedup_key = f"{item['pid']}:{alert_type}"
        if sev != "INFO" and dedup_key not in self._emitted_keys:
            self._emitted_keys.add(dedup_key)
            await self.event_bus.publish(self._build_event(item, sev, alert_type, desc))

    def _build_event(self, item: dict[str, Any], sev: str, a_type: str, desc: str) -> dict[str, Any]:
        """Construct a normalized process security event dictionary."""
        return {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "engine": "PROCESS",
            "severity": sev,
            "alert_type": a_type,
            "process_name": item["name"],
            "process_path": item["exe"],
            "pid": item["pid"],
            "exe_hash": item["sha256"],
            "remote_ip": item["connections"][0] if item["connections"] else None,
            "country": None,
            "file_path": None,
            "description": desc,
            "actions_available": ["kill", "allow", "ignore"],
        }

    def _map_pid_connections(self) -> dict[int, list[str]]:
        """Build a lookup table mapping PID to active remote IP addresses."""
        mapping: dict[int, list[str]] = {}
        try:
            for conn in psutil.net_connections(kind="inet"):
                if conn.pid and conn.raddr and conn.raddr.ip:
                    mapping.setdefault(conn.pid, []).append(conn.raddr.ip)
        except Exception:
            pass
        return mapping

    async def scan_once(self) -> list[dict[str, Any]]:
        """Perform a single scan of all running processes and return snapshots."""
        attrs = ["pid", "name", "exe", "cmdline", "create_time", "cpu_percent", "memory_info", "status"]
        conn_map = self._map_pid_connections()
        collected: list[dict[str, Any]] = []
        for proc in psutil.process_iter(attrs=attrs):
            try:
                item = self._extract_proc_info(proc, conn_map.get(proc.pid, []))
                await self._evaluate_process(item)
                collected.append(item)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        self.latest_processes = collected
        return collected

    async def run(self) -> None:
        """Continuously poll processes every ENGINE_POLL_INTERVAL_SEC seconds."""
        while True:
            try:
                await self.scan_once()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("ProcessWatcher scan cycle failed")
            await asyncio.sleep(ENGINE_POLL_INTERVAL_SEC)
