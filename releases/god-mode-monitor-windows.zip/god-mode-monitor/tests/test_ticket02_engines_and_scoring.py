"""TDD tests for Ticket 02: ThreatScorer precision, IPLookup cache/rate-limit, and FileGuard."""

from datetime import datetime
from pathlib import Path
import pytest
from api.schemas import SettingsConfig
from engine.event_bus import EventBus
from engine.file_guard import FileGuard
from engine.ip_lookup import IPLookup
from engine.threat_scorer import (
    score_file_mutation,
    score_network_connection,
    score_process_observation,
)
from storage.db import Database


def test_process_scorer_avoids_migration_false_positive_and_catches_real_threats():
    benign = {"name": "migration/0", "exe": "/sbin/migration", "cpu_percent": 0.1, "memory_mb": 10.0}
    sev, _, _ = score_process_observation(benign, False, True, False, False)
    assert sev == "INFO"

    mal_rat = {"name": "njrat.exe", "exe": "C:\\Users\\admin\\njrat.exe", "cpu_percent": 5.0, "memory_mb": 40.0}
    sev_rat, _, _ = score_process_observation(mal_rat, False, True, False, False)
    assert sev_rat == "CRITICAL"

    masquerade = {"name": "svchost.exe", "exe": "C:\\Users\\Public\\svchost.exe", "cpu_percent": 2.0, "memory_mb": 30.0}
    sev_masq, _, _ = score_process_observation(masquerade, False, True, False, False)
    assert sev_masq == "HIGH"


def test_network_scorer_ignores_loopback_and_flags_foreign_exfil():
    loopback_conn = {
        "process_name": "Unknown", "country_code": "LO", "country": "Local Network",
        "org": "Localhost / LAN", "isp": "Loopback", "is_hosting": False, "data_mb": 25.0,
    }
    sev_lo, _, _ = score_network_connection(loopback_conn, ["RU", "CN", "KP", "IR"])
    assert sev_lo == "INFO"

    critical_exfil = {
        "process_name": "svchost.exe", "country_code": "RU", "country": "Russia",
        "org": "Moscow Telecom", "isp": "Moscow Telecom", "is_hosting": False, "data_mb": 6.4,
    }
    sev_ru, _, _ = score_network_connection(critical_exfil, ["RU", "CN", "KP", "IR"])
    assert sev_ru == "CRITICAL"


@pytest.mark.asyncio
async def test_ip_lookup_sqlite_cache_and_rate_limit(tmp_path: Path):
    db = Database(str(tmp_path / "ip.db"))
    await db.initialize()
    await db.upsert_cached_ip({
        "ip": "185.199.108.153", "country": "Russia", "country_code": "RU",
        "org": "Selectel Hosting", "isp": "Selectel", "is_hosting": True,
        "fetched_at": datetime.now().isoformat(timespec="seconds"),
    })
    lookup = IPLookup(db)
    res = await lookup.lookup("185.199.108.153")
    assert res["cached"] is True
    assert res["country_code"] == "RU"
    await db.close()


@pytest.mark.asyncio
async def test_file_guard_deduplicates_baselines_and_detects_hash_change(tmp_path: Path):
    db = Database(str(tmp_path / "fg.db"))
    await db.initialize()
    vault = tmp_path / "vault"
    vault.mkdir()
    wallet = vault / "wallet.txt"
    wallet.write_text("seed-balance=100\n", encoding="utf-8")

    cfg = SettingsConfig.default_settings()
    cfg.watched_paths = [str(vault)]
    bus = EventBus()
    fg = FileGuard(bus, cfg, db)
    await fg.initialize_baselines()
    await fg.initialize_baselines()
    paths = [f["file_path"] for f in fg.latest_files]
    assert len(paths) == len(set(paths)), "Duplicate baseline entries found"

    wallet.write_text("seed-balance=0\n", encoding="utf-8")
    await fg.handle_fs_event("modified", str(wallet))
    updated = next(f for f in fg.latest_files if f["file_path"] == str(wallet.resolve()))
    assert updated["hash_status"] == "CHANGED"
    assert updated["old_hash"] != updated["new_hash"]

    sev_night, _, _ = score_file_mutation("modified", str(wallet), "00:00", "06:00", "02:30")
    assert sev_night == "CRITICAL"
    await db.close()
