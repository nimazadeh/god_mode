# GiyahKala Price Sentinel — Feature Catalog (v1.0.0)

## 1. Hybrid Zero-Key Extraction Engine (`sentinel/extractor.py`)
- **Public WooCommerce Store JSON Extraction**: Queries `https://giyahkala.com/wp-json/wc/store/v1/products` without requiring private administrative API keys, extracting canonical `product_id`, `sku`, `slug`, `name`, `category`, `permalink`, `is_in_stock`, and prices.
- **HTML DOM & Schema.org Option Tier Parser**: Inspects product HTML pages and `application/ld+json` blocks to capture weight tiers (10g to 1000kg) and active-ingredient purity surcharges (5% to 95%).
- **Canonical Currency Normalization**: Normalizes mixed Rial (`IRR`) and Toman (`IRT`) values into integer Toman at the ingestion boundary.

## 2. Deterministic Price & Option Diff Engine (`sentinel/diff_engine.py`)
- **Six-State Classification**: Classifies every monitored item as `price_increased`, `price_decreased`, `option_changed`, `stock_changed`, `new_product`, or `unchanged`.
- **Changed-Only Default Filtering**: Surfaces only products that changed relative to the baseline snapshot so affiliate resellers can update their stores immediately without noise.
- **Option Fingerprint Hashing**: Computes order-independent SHA-256 digests over selectable option tiers to detect subtle surcharge adjustments.

## 3. SQLite WAL Snapshot Repository (`sentinel/storage.py`)
- **Explicit Baseline Pointer**: Preserves the reference baseline snapshot across multiple checks until the reseller explicitly clicks **Sync Baseline**.
- **Custom Reseller Watchlist**: Supports monitoring specific `giyahkala.com` product URLs or slugs alongside full category scans.

## 4. Linear Light-Mode Web UI & Excel CSV Exporter (`web/` & `sentinel/exporter.py`)
- **Linear Light-Mode Design System**: Crisp `#F7F8F9` / `#FFFFFF` surfaces, `1px solid #EAECEF` borders, self-hosted `Inter`, `Geist`, and `JetBrains Mono` fonts with `font-variant-numeric: tabular-nums`.
- **Web Application Excellence**: Semantic HTML5 landmarks, WCAG AA/AAA verified contrast, keyboard shortcuts (`S` scan, `/` search, `E` export), and single-reflow `DocumentFragment` rendering.
- **Excel-Ready CSV Export**: Outputs RFC 4180 CSV with UTF-8 BOM for direct opening in Microsoft Excel.
