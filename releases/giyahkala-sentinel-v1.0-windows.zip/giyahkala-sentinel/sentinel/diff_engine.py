"""Pure comparison engine for detecting price, option, and stock changes.

Keeping diff calculation free of database and network I/O satisfies the Single
Responsibility Principle and allows deterministic testing across edge cases.
"""

from __future__ import annotations

from sentinel.models import (
    CatalogProduct,
    CatalogSnapshot,
    DiffReport,
    DiffSummary,
    OptionTier,
    PriceChangeType,
    PriceDelta,
)


def summarize_option_tier_changes(
    previous_tiers: list[OptionTier],
    current_tiers: list[OptionTier],
) -> str:
    """Build a human-readable summary of option-tier price additions or changes.

    Affiliate resellers need to know which specific weight or purity tier changed
    without opening two raw option arrays side by side.
    """
    previous_map = {
        f"{tier.group_name}: {tier.option_label}": tier.price_toman
        for tier in previous_tiers
    }
    current_map = {
        f"{tier.group_name}: {tier.option_label}": tier.price_toman
        for tier in current_tiers
    }

    change_descriptions: list[str] = []
    for key, current_price in current_map.items():
        if key not in previous_map:
            change_descriptions.append(f"Added {key} ({current_price:,} IRT)")
        else:
            previous_price = previous_map[key]
            if current_price != previous_price:
                change_descriptions.append(
                    f"{key}: {previous_price:,} -> {current_price:,} IRT"
                )

    for key in previous_map:
        if key not in current_map:
            change_descriptions.append(f"Removed {key}")

    return "; ".join(change_descriptions)


def compare_single_product(
    previous_product: CatalogProduct | None,
    current_product: CatalogProduct,
) -> PriceDelta:
    """Compare one current product record against its baseline counterpart."""
    current_price = current_product.displayed_price_toman

    if previous_product is None:
        return PriceDelta(
            product_id=current_product.product_id,
            sku=current_product.sku,
            slug=current_product.slug,
            name=current_product.name,
            category=current_product.category,
            permalink=current_product.permalink,
            previous_price_toman=None,
            current_price_toman=current_price,
            delta_toman=current_price,
            delta_percent=100.0,
            previous_in_stock=None,
            current_in_stock=current_product.is_in_stock,
            change_type=PriceChangeType.NEW_PRODUCT,
            option_change_summary="New catalog product discovered",
            option_tiers=current_product.option_tiers,
        )

    previous_price = previous_product.displayed_price_toman
    delta_toman = current_price - previous_price

    if previous_price > 0:
        delta_percent = round((delta_toman / previous_price) * 100.0, 2)
    elif current_price > 0:
        delta_percent = 100.0
    else:
        delta_percent = 0.0

    option_summary = summarize_option_tier_changes(
        previous_product.option_tiers,
        current_product.option_tiers,
    )
    options_differ = (
        previous_product.compute_option_fingerprint()
        != current_product.compute_option_fingerprint()
    )

    # When the baseline snapshot was captured without deep HTML option enrichment
    # (previous_product.option_tiers is empty) and the product price itself is
    # unchanged, avoid flagging a false-positive option change when HTML options
    # are inspected for the first time.
    if (
        options_differ
        and not previous_product.option_tiers
        and delta_toman == 0
    ):
        options_differ = False
        option_summary = ""

    stock_differs = previous_product.is_in_stock != current_product.is_in_stock

    if delta_toman > 0:
        change_type = PriceChangeType.PRICE_INCREASED
    elif delta_toman < 0:
        change_type = PriceChangeType.PRICE_DECREASED
    elif stock_differs:
        change_type = PriceChangeType.STOCK_CHANGED
        if not option_summary:
            stock_transition = (
                "In Stock -> Out of Stock"
                if not current_product.is_in_stock
                else "Out of Stock -> In Stock"
            )
            option_summary = f"Availability changed: {stock_transition}"
    elif options_differ:
        change_type = PriceChangeType.OPTION_CHANGED
    else:
        change_type = PriceChangeType.UNCHANGED

    return PriceDelta(
        product_id=current_product.product_id,
        sku=current_product.sku,
        slug=current_product.slug,
        name=current_product.name,
        category=current_product.category,
        permalink=current_product.permalink,
        previous_price_toman=previous_price,
        current_price_toman=current_price,
        delta_toman=delta_toman,
        delta_percent=delta_percent,
        previous_in_stock=previous_product.is_in_stock,
        current_in_stock=current_product.is_in_stock,
        change_type=change_type,
        option_change_summary=option_summary,
        option_tiers=current_product.option_tiers,
    )


def compute_catalog_diff(
    baseline_snapshot: CatalogSnapshot,
    current_snapshot: CatalogSnapshot,
    changed_only: bool = True,
) -> DiffReport:
    """Compare all products in current_snapshot against baseline_snapshot.

    Products are matched primarily by canonical product_id and secondarily by
    slug so that re-indexed WooCommerce items still pair with their history.
    """
    baseline_by_id: dict[int, CatalogProduct] = {
        product.product_id: product for product in baseline_snapshot.products
    }
    baseline_by_slug: dict[str, CatalogProduct] = {
        product.slug: product for product in baseline_snapshot.products
    }

    summary = DiffSummary(total_compared=len(current_snapshot.products))
    all_deltas: list[PriceDelta] = []

    for current_product in current_snapshot.products:
        matched_previous = baseline_by_id.get(current_product.product_id)
        if matched_previous is None:
            matched_previous = baseline_by_slug.get(current_product.slug)

        delta = compare_single_product(matched_previous, current_product)
        all_deltas.append(delta)

        if delta.change_type == PriceChangeType.PRICE_INCREASED:
            summary.price_increased_count += 1
            summary.total_changed += 1
        elif delta.change_type == PriceChangeType.PRICE_DECREASED:
            summary.price_decreased_count += 1
            summary.total_changed += 1
        elif delta.change_type == PriceChangeType.OPTION_CHANGED:
            summary.option_changed_count += 1
            summary.total_changed += 1
        elif delta.change_type == PriceChangeType.STOCK_CHANGED:
            summary.stock_changed_count += 1
            summary.total_changed += 1
        elif delta.change_type == PriceChangeType.NEW_PRODUCT:
            summary.new_product_count += 1
            summary.total_changed += 1
        else:
            summary.unchanged_count += 1

    priority_order = {
        PriceChangeType.PRICE_INCREASED: 0,
        PriceChangeType.PRICE_DECREASED: 1,
        PriceChangeType.STOCK_CHANGED: 2,
        PriceChangeType.OPTION_CHANGED: 3,
        PriceChangeType.NEW_PRODUCT: 4,
        PriceChangeType.UNCHANGED: 5,
    }
    all_deltas.sort(
        key=lambda item: (
            priority_order.get(item.change_type, 9),
            -abs(item.delta_toman),
            item.slug,
        )
    )

    visible_items = (
        [item for item in all_deltas if item.has_changed]
        if changed_only
        else all_deltas
    )

    return DiffReport(
        baseline_snapshot_id=baseline_snapshot.snapshot_id,
        baseline_created_at_iso=baseline_snapshot.created_at_iso,
        current_snapshot_id=current_snapshot.snapshot_id,
        current_created_at_iso=current_snapshot.created_at_iso,
        source_mode=current_snapshot.source_mode,
        summary=summary,
        items=visible_items,
    )
