"""Unit tests for the hybrid giyahkala.com product and option extractor."""

from __future__ import annotations

import httpx
import pytest

from sentinel.extractor import (
    GiyahKalaExtractor,
    extract_slug_from_url_or_slug,
    parse_html_product_options_and_price,
    parse_store_api_product,
)
from sentinel.models import normalize_price_to_toman


def test_normalize_price_to_toman_handles_irt_and_irr() -> None:
    """Verify Rial (IRR) values are divided by ten while Toman (IRT) values remain intact."""
    assert normalize_price_to_toman("2,360,000", "IRT") == 2360000
    assert normalize_price_to_toman("172500", "IRR") == 17250
    assert normalize_price_to_toman(504000, "IRT") == 504000
    assert normalize_price_to_toman("", "IRT") == 0


def test_extract_slug_from_url_or_slug() -> None:
    """Verify full permalinks and bare slugs resolve to canonical lowercase slugs."""
    full_url = "https://giyahkala.com/product/dry-sage-plant/"
    assert extract_slug_from_url_or_slug(full_url) == "dry-sage-plant"
    assert extract_slug_from_url_or_slug("  Polyphenols/ ") == "polyphenols"


def test_parse_store_api_product_normalizes_woocommerce_payload() -> None:
    """Verify WooCommerce Store v1 JSON payloads map cleanly to CatalogProduct."""
    sample_payload = {
        "id": 18527,
        "name": "Bulk Dried Sage Leaf",
        "slug": "dry-sage-plant",
        "sku": "100018527",
        "permalink": "https://giyahkala.com/product/dry-sage-plant/",
        "is_in_stock": True,
        "prices": {
            "price": "2360000",
            "regular_price": "2360000",
            "sale_price": "2360000",
            "currency_code": "IRT",
        },
        "categories": [{"id": 12565, "name": "Medicinal Plants"}],
    }
    product = parse_store_api_product(sample_payload)
    assert product.product_id == 18527
    assert product.sku == "100018527"
    assert product.slug == "dry-sage-plant"
    assert product.displayed_price_toman == 2360000
    assert product.category == "Medicinal Plants"
    assert product.is_in_stock is True


def test_parse_html_product_options_and_price_extracts_tiers_and_json_ld() -> None:
    """Verify HTML parser extracts extra product option tiers and final summary price."""
    sample_html = """
    <html>
      <head>
        <script type="application/ld+json">
          {"@type": "Product", "name": "Polyphenols", "offers": {"price": "252000", "priceCurrency": "IRR", "availability": "https://schema.org/InStock"}}
        </script>
      </head>
      <body>
        <div class="tmcp-field-wrap" data-option-group="Purity Grade">
          <label class="tm-label">Polyphenol 80%</label>
          <span class="price" data-price="25200">25,200</span>
        </div>
        <div class="tmcp-field-wrap" data-option-group="Sample Weight">
          <label class="tm-label">100g Bottle</label>
          <span class="price" data-price="478800">478,800</span>
        </div>
        <div class="tm-final-totals">
          <span class="amount">504,000</span>
        </div>
      </body>
    </html>
    """
    displayed_price, tiers, in_stock = parse_html_product_options_and_price(sample_html)
    assert displayed_price == 504000
    assert in_stock is True
    assert len(tiers) == 2
    assert tiers[0].group_name == "Purity Grade"
    assert tiers[0].price_toman == 25200
    assert tiers[1].option_label == "100g Bottle"
    assert tiers[1].price_toman == 478800


@pytest.mark.asyncio
async def test_extractor_fetches_store_json_and_enriches_html_options() -> None:
    """Verify GiyahKalaExtractor paginates Store JSON and enriches HTML options."""

    def mock_handler(request: httpx.Request) -> httpx.Response:
        if "/wp-json/wc/store/v1/products" in str(request.url):
            return httpx.Response(
                200,
                json=[
                    {
                        "id": 70731,
                        "name": "Green Tea Polyphenol",
                        "slug": "polyphenols",
                        "sku": "100070731",
                        "permalink": "https://giyahkala.com/product/polyphenols/",
                        "is_in_stock": True,
                        "prices": {
                            "price": "25200",
                            "regular_price": "25200",
                            "sale_price": "25200",
                            "currency_code": "IRT",
                        },
                        "categories": [{"name": "Active Ingredients"}],
                    }
                ],
            )
        if "/product/polyphenols/" in str(request.url):
            return httpx.Response(
                200,
                text="""
                <div class="tmcp-field-wrap" data-option-group="Weight">
                  <label class="tm-label">100g Sample</label>
                  <span class="price" data-price="478800">478,800</span>
                </div>
                <p class="price"><span class="amount">504,000</span></p>
                """,
            )
        return httpx.Response(404)

    transport = httpx.MockTransport(mock_handler)
    async with httpx.AsyncClient(transport=transport) as client:
        extractor = GiyahKalaExtractor(http_client=client)
        products = await extractor.fetch_live_catalog(
            max_pages=1,
            per_page=10,
            enrich_html_options=True,
        )

    assert len(products) == 1
    assert products[0].slug == "polyphenols"
    assert products[0].displayed_price_toman == 504000
    assert len(products[0].option_tiers) == 1
    assert products[0].option_tiers[0].price_toman == 478800


def test_parse_html_select_dropdown_ignores_zero_surcharges_and_never_concatenates_options() -> None:
    """Verify <select> dropdowns inside <label> do not concatenate 100 options or emit 0-price tiers."""
    arnica_style_html = """
    <html>
      <body>
        <ul class="tc-extra-product-options">
          <li class="cpf-section"><h4 class="cpf-section-header">Select Grade</h4></li>
          <li class="tmcp-field-wrap">
            <div class="tmcp-field-wrap">
              <label class="tm-epo-field-label fullwidth-select">
                <select class="tmcp-field">
                  <option value="grade-a" selected="selected">Grade A</option>
                  <option value="grade-a-plus">Grade A+</option>
                  <option value="grade-a-plusplus">Grade A++</option>
                </select>
              </label>
              <span class="price tc-price"><span class="amount">10,200,000</span></span>
            </div>
          </li>
          <li class="cpf-section"><h4 class="cpf-section-header">Volume (Liters)</h4></li>
          <li class="tmcp-field-wrap">
            <div class="tmcp-field-wrap">
              <label class="tm-epo-field-label fullwidth-select">
                <select class="tmcp-field">
                  <option value="100cc">Sample 100cc</option>
                  <option value="250cc">Sample 250cc</option>
                  <option value="1l">1 Liter</option>
                  <option value="2l">2 Liters</option>
                  <option value="100l">100 Liters</option>
                </select>
              </label>
              <span class="price tc-price"><span class="amount">0</span></span>
            </div>
          </li>
        </ul>
        <p class="price"><span class="amount">10,200,000</span></p>
      </body>
    </html>
    """
    displayed_price, tiers, in_stock = parse_html_product_options_and_price(
        arnica_style_html
    )
    assert displayed_price == 10200000
    assert in_stock is True
    assert len(tiers) == 1
    assert tiers[0].group_name == "Select Grade"
    assert tiers[0].option_label == "Grade A"
    assert tiers[0].price_toman == 10200000


def test_parse_real_giyahkala_tm_epo_html_with_data_rules_and_multi_selects() -> None:
    """Verify TM Extra Product Options data-rules JSON and multi-option selects are parsed cleanly."""
    from sentinel.models import CatalogProduct

    fallback = CatalogProduct(
        product_id=3761,
        sku="10003761",
        slug="arnica-extract",
        name="عصاره آرنیکا مایع",
        category="عصاره مایع",
        permalink="https://giyahkala.com/product/arnica-extract/",
        base_price_toman=10200000,
        regular_price_toman=10200000,
        displayed_price_toman=10200000,
        is_in_stock=True,
    )
    real_giyahkala_html = """
    <div class="tc-extra-product-options tm-extra-product-options">
      <ul class="tmcp-ul-wrap">
        <li class="tmcp-field-wrap">
          <div class="tm-epo-field-label">نوع عصاره</div>
          <div class="tmcp-field-wrap-inner">
            <label class="fullwidth-select">
              <select class="tmcp-field">
                <option value="0" data-text="هیدروالکلی (خوراکی)" data-rules='["0"]' data-price="">هیدروالکلی (خوراکی)</option>
                <option value="1" data-text="هیدروگلایکولی (موضعی)" data-rules='["0"]' data-price="">هیدروگلایکولی (موضعی)</option>
                <option value="2" data-text="هیدروگلیسیرینی (موضعی)" data-rules='["0"]' data-price="">هیدروگلیسیرینی (موضعی)</option>
              </select>
            </label>
            <span class="price tc-price"><span class="amount">0 تومان</span></span>
          </div>
        </li>
        <li class="tmcp-field-wrap">
          <div class="tm-epo-field-label">انتخاب گرید</div>
          <div class="tmcp-field-wrap-inner">
            <label class="fullwidth-select">
              <select class="tmcp-field">
                <option value="0" data-text="گرید A" data-rules='["10200000"]' data-price="">گرید A</option>
                <option value="1" data-text="گرید +A" data-rules='["11400000"]' data-price="">گرید +A</option>
                <option value="2" data-text="گرید ++A" data-rules='["12800000"]' data-price="">گرید ++A</option>
              </select>
            </label>
            <span class="price tc-price"><span class="amount">0 تومان</span></span>
          </div>
        </li>
        <li class="tmcp-field-wrap">
          <div class="tm-epo-field-label">مقدار (لیتر)</div>
          <div class="tmcp-field-wrap-inner">
            <label class="fullwidth-select">
              <select class="tmcp-field">
                <option value="0" data-text="خرید نمونه (100 سی سی)" data-rules='["0"]' data-price="">خرید نمونه (100 سی سی)</option>
                <option value="1" data-text="1 لیتر" data-rules='["0"]' data-price="">1 لیتر</option>
                <option value="2" data-text="2 لیتر" data-rules='["0"]' data-price="">2 لیتر</option>
                <option value="99" data-text="100 لیتر" data-rules='["0"]' data-price="">100 لیتر</option>
              </select>
            </label>
            <span class="price tc-price"><span class="amount">0 تومان</span></span>
          </div>
        </li>
      </ul>
    </div>
    """
    displayed_price, tiers, in_stock = parse_html_product_options_and_price(
        real_giyahkala_html,
        fallback_product=fallback,
    )
    assert displayed_price == 10200000
    assert in_stock is True
    assert len(tiers) >= 3
    group_names = [t.group_name for t in tiers]
    assert "نوع عصاره" in group_names
    assert "انتخاب گرید" in group_names
    assert "مقدار (لیتر)" in group_names
    grade_tiers = [t for t in tiers if t.group_name == "انتخاب گرید"]
    assert any(t.option_label == "گرید A" and t.price_toman == 10200000 for t in grade_tiers)
    assert any(t.option_label == "گرید +A" and t.price_toman == 11400000 for t in grade_tiers)
    # Ensure no option label ever concatenates all 100 items
    assert all(len(t.option_label) <= 80 for t in tiers)


