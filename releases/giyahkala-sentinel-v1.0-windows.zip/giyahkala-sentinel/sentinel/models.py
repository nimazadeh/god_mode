"""Domain models and normalization utilities for GiyahKala Price Sentinel.

All price values are normalized to integer Toman (IRT) at the domain boundary
so downstream diff calculations never suffer from floating-point rounding or
mixed Rial/Toman currency discrepancies.
"""

from __future__ import annotations

import hashlib
from enum import StrEnum
from pydantic import BaseModel, ConfigDict, Field


class PriceChangeType(StrEnum):
    """Classification of how a product changed relative to the baseline snapshot."""

    PRICE_INCREASED = "price_increased"
    PRICE_DECREASED = "price_decreased"
    OPTION_CHANGED = "option_changed"
    STOCK_CHANGED = "stock_changed"
    NEW_PRODUCT = "new_product"
    UNCHANGED = "unchanged"


def normalize_price_to_toman(raw_amount: int | float | str, currency_code: str = "IRT") -> int:
    """Convert raw numeric or formatted string prices into integer Toman (IRT).

    WooCommerce JSON-LD schema blocks occasionally emit prices in Rial (IRR)
    while the Store API and HTML DOM emit Toman (IRT). Dividing IRR values by
    ten at ingestion guarantees a single canonical currency unit across all layers.
    """
    if isinstance(raw_amount, (int, float)):
        numeric_value = int(round(raw_amount))
    else:
        cleaned_digits = "".join(
            character for character in str(raw_amount) if character.isdigit()
        )
        numeric_value = int(cleaned_digits) if cleaned_digits else 0

    normalized_currency = currency_code.strip().upper()
    if normalized_currency == "IRR" and numeric_value >= 10:
        return numeric_value // 10
    return max(0, numeric_value)


class OptionTier(BaseModel):
    """Selectable product option (weight, purity, or purchase tier) and its Toman price."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    group_name: str = Field(..., min_length=1)
    option_label: str = Field(..., min_length=1)
    price_toman: int = Field(..., ge=0)


class CatalogProduct(BaseModel):
    """Canonical representation of an observable product on giyahkala.com."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    product_id: int = Field(..., ge=1)
    sku: str = Field(default="")
    slug: str = Field(..., min_length=1)
    name: str = Field(..., min_length=1)
    category: str = Field(default="General")
    permalink: str = Field(..., min_length=1)
    base_price_toman: int = Field(..., ge=0)
    regular_price_toman: int = Field(..., ge=0)
    displayed_price_toman: int = Field(..., ge=0)
    is_in_stock: bool = Field(default=True)
    option_tiers: list[OptionTier] = Field(default_factory=list)

    def compute_option_fingerprint(self) -> str:
        """Compute a deterministic digest of all option tiers for rapid change detection.

        Sorting option tiers before hashing ensures that cosmetic reordering in the
        HTML DOM never triggers a false-positive option change alert.
        """
        if not self.option_tiers:
            return "no-options"
        canonical_entries = sorted(
            f"{tier.group_name}:{tier.option_label}={tier.price_toman}"
            for tier in self.option_tiers
        )
        joined_payload = "|".join(canonical_entries)
        return hashlib.sha256(joined_payload.encode("utf-8")).hexdigest()[:16]


class CatalogSnapshot(BaseModel):
    """Immutable point-in-time capture of catalog product prices."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    snapshot_id: int = Field(..., ge=1)
    created_at_iso: str = Field(..., min_length=1)
    source_mode: str = Field(default="live")
    note: str = Field(default="")
    is_baseline: bool = Field(default=False)
    product_count: int = Field(default=0, ge=0)
    products: list[CatalogProduct] = Field(default_factory=list)


class PriceDelta(BaseModel):
    """Comparison outcome for a single product between baseline and current snapshots."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    product_id: int
    sku: str
    slug: str
    name: str
    category: str
    permalink: str
    previous_price_toman: int | None
    current_price_toman: int
    delta_toman: int
    delta_percent: float
    previous_in_stock: bool | None
    current_in_stock: bool
    change_type: PriceChangeType
    option_change_summary: str = Field(default="")
    option_tiers: list[OptionTier] = Field(default_factory=list)

    @property
    def has_changed(self) -> bool:
        """Return True when the product experienced any price, option, or stock change."""
        return self.change_type != PriceChangeType.UNCHANGED


class DiffSummary(BaseModel):
    """Aggregate statistics for a comparison report."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    total_compared: int = 0
    total_changed: int = 0
    price_increased_count: int = 0
    price_decreased_count: int = 0
    option_changed_count: int = 0
    stock_changed_count: int = 0
    new_product_count: int = 0
    unchanged_count: int = 0


class DiffReport(BaseModel):
    """Complete comparison output pairing a baseline snapshot with a target snapshot."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    baseline_snapshot_id: int
    baseline_created_at_iso: str
    current_snapshot_id: int
    current_created_at_iso: str
    source_mode: str
    summary: DiffSummary
    items: list[PriceDelta] = Field(default_factory=list)


class ScanRequest(BaseModel):
    """Parameters controlling an on-demand catalog scan."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    mode: str = Field(default="auto")
    category_slug: str = Field(default="")
    max_pages: int = Field(default=2, ge=1, le=50)
    per_page: int = Field(default=25, ge=1, le=100)
    enrich_html_options: bool = Field(default=False)
    watchlist_only: bool = Field(default=False)
    note: str = Field(default="")


class WatchlistItemCreate(BaseModel):
    """Payload for adding a specific product slug or URL to the monitored watchlist."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    slug_or_url: str = Field(..., min_length=2)
    label: str = Field(default="")
