"""FastAPI routes for the v3.0 HTTP RFC Sentinel Pack (RFC 9110/9111/9112/6585/9421/9530/9651)."""

from typing import Any
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from engine.rfc_firewall import emit_rfc_firewall_event, inspect_request_rfc_anomalies

rfc_router = APIRouter()


class RfcAuditRequest(BaseModel):
    """Input payload for auditing a target HTTP/HTTPS URL against IETF HTTPWG RFCs."""

    url: str = Field(min_length=3)


class RfcProbeSimulationRequest(BaseModel):
    """Input payload for running a safe HTTP RFC protocol attack simulation."""

    probe_type: str = Field(default="smuggling_rfc9112")


def _build_simulated_raw_request(probe_type: str) -> tuple[str, str, list[tuple[bytes, bytes]]]:
    """Construct synthetic method, path, and raw headers for a safe RFC firewall probe."""
    if probe_type == "trace_rfc9110":
        return "TRACE", "/api/stats", [(b"host", b"localhost:8080"), (b"user-agent", b"RFC9110-Probe/1.0")]
    if probe_type == "header_flood_rfc6585":
        return "GET", "/api/stats", [(b"host", b"localhost:8080"), (b"x-rfc6585-flood", b"X" * 5000)]
    return (
        "POST",
        "/api/stats",
        [(b"host", b"localhost:8080"), (b"content-length", b"15"), (b"transfer-encoding", b"chunked")],
    )


@rfc_router.get("/api/http-rfc")
async def get_http_rfc_overview(request: Request) -> dict[str, Any]:
    """Return HTTP RFC compliance audits, firewall violation log, and RFC 9421/9530 profile."""
    mon = request.app.state.monitor
    auditor = mon["http_rfc_auditor"]
    if not auditor.list_audits():
        await auditor.audit_url("http://localhost:8080/api/stats", app=request.app)
    return {
        "audits": auditor.list_audits(),
        "firewall_log": mon.get("rfc_firewall_log", [])[:25],
        "crypto_profile": {
            "digest_rfc": "RFC 9530 (Repr-Digest sha-256)",
            "signature_rfc": "RFC 9421 (HMAC-SHA256)",
            "structured_fields_rfc": "RFC 9651 (:base64: Byte Sequence)",
            "keyid": "god-mode-local",
        },
    }


@rfc_router.post("/api/http-rfc/audit")
async def audit_target_url(body: RfcAuditRequest, request: Request) -> dict[str, Any]:
    """Audit a target URL against RFC 9110, 9111, 6265, 7838, 9421, and 9530."""
    auditor = request.app.state.monitor["http_rfc_auditor"]
    return await auditor.audit_url(body.url, app=request.app)


@rfc_router.post("/api/http-rfc/simulate-probe")
async def simulate_rfc_probe(body: RfcProbeSimulationRequest, request: Request) -> dict[str, Any]:
    """Execute a safe self-test probe against the RFC 9112/9110/6585 protocol firewall."""
    method, path, raw_headers = _build_simulated_raw_request(body.probe_type)
    finding = inspect_request_rfc_anomalies(method, path, raw_headers)
    if finding is None:
        raise HTTPException(status_code=400, detail="Unknown probe_type")
    mon = request.app.state.monitor
    ev = await emit_rfc_firewall_event(mon, finding)
    for raw in mon["event_bus"].drain_pending():
        await mon["hub"].process_single_event(raw)
    return {
        "blocked": True,
        "rfc": finding["rfc"],
        "section": finding["section"],
        "status_code": finding["status_code"],
        "severity": finding["severity"],
        "title": finding["title"],
        "event": ev,
    }
