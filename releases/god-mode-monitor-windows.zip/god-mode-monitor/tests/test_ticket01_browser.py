"""Browser E2E test and screenshot capture for Ticket 01."""

from pathlib import Path
import pytest
from playwright.async_api import async_playwright

SCREENSHOT_DIR = Path("/home/user/screenshots")


@pytest.mark.asyncio
async def test_ticket01_browser_live_dashboard_shell():
    """Verify live WebSocket telemetry, Stat Cards, Process Table, and Chart.js."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        page.on("pageerror", lambda err: errors.append(str(err)))
        page.on("console", lambda msg: errors.append(msg.text) if msg.type == "error" else None)
        await page.goto("http://127.0.0.1:8080", wait_until="networkidle")
        await page.wait_for_function(
            "Number(document.getElementById('stat-processes')?.textContent || '0') > 0",
            timeout=8000,
        )
        conn_status = await page.locator("#conn-status").text_content()
        assert conn_status == "LIVE"
        proc_rows = await page.locator("#processes-tbody tr").count()
        assert proc_rows > 0
        await page.screenshot(path=str(SCREENSHOT_DIR / "ticket_01_live_shell.png"))
        await browser.close()
    assert errors == [], f"Browser console/page errors: {errors}"
