# God Mode Monitor

A real-time, localhost-only endpoint security monitoring dashboard and response engine powered by Python (FastAPI + AsyncIO) and a zero-dependency vanilla HTML/CSS/JS frontend over WebSocket.

## Language

### Core Domain

**Engine**:
One of the three asynchronous background collectors (`ProcessWatcher`, `NetworkSentinel`, `FileGuard`) that continuously inspect host activity and push raw findings onto the `EventBus`.
_Avoid_: Worker, service, daemon, thread

**EventBus**:
The shared `asyncio.Queue` pipeline connecting all three Engines to the `ThreatScorer`, SQLite persistence layer, and WebSocket broadcaster.
_Avoid_: Message broker, channel, pubsub

**SecurityEvent**:
A normalized record of a host observation (process anomaly, network connection, or file mutation) scored with a `Severity` and persisted in the `events` SQLite table.
_Avoid_: Log entry, incident, notification

**Alert**:
A real-time actionable representation of a `SecurityEvent` pushed over WebSocket to the dashboard Alert Feed, offering context-appropriate response actions (`kill_process`, `block_ip`, `allow`, `ignore`).
_Avoid_: Toast, popup, warning

**Severity**:
The four-tier threat classification assigned by `ThreatScorer`: `INFO`, `WARN`, `HIGH`, or `CRITICAL`.
_Avoid_: Priority, level, risk score

### Operation Modes

**OperationMode**:
The active security posture of the monitor, persisted in `settings.json` and switchable live from the header bar:
- `WATCH`: Passive monitoring and logging with visual alerts only; sound suppressed for `INFO` and no active response commands executed.
- `GUARD`: Default startup posture; enables audio alerts for `HIGH`/`CRITICAL` and allows user-confirmed process termination and allowlisting.
- `WAR`: Maximum posture; flashes the header in red, sounds the war alarm on activation, and enables user-confirmed Windows Firewall outbound IP blocking (`netsh advfirewall`).
_Avoid_: Profile, state, theme

### Protection & Suppression

**AllowlistRule**:
A strict three-tuple suppression rule (`process_path` + `exe_hash` + `alert_type`) with an optional `expires_at` timestamp, managed exclusively via the dashboard Allowlist Manager. If the executable's SHA-256 hash changes on disk, suppression is revoked and flagged as `NEEDS REVIEW`.
_Avoid_: Whitelist, ignore list, exception

**BaselineHash**:
The initial SHA-256 digest computed for every file under `watched_paths` at startup, used by `FileGuard` to verify whether a file is `UNCHANGED`, `CHANGED`, `DELETED`, or `UNKNOWN`.
_Avoid_: Checksum, fingerprint, snapshot

**FlaggedCountry**:
An ISO-3166 alpha-2 country code configured in `settings.json` (default: `RU`, `CN`, `KP`, `IR`) whose outbound network traffic triggers elevated `WARN` or `CRITICAL` scoring.
_Avoid_: Blocked country, blacklist country

**OSAdapter**:
The platform abstraction seam (`engine/os_adapter.py`) isolating host-specific operations (Authenticode signature verification via PowerShell, Windows Firewall `netsh` blocking, Administrator privilege check, Explorer folder launch, and Windows Startup registration) so Windows hosts execute native commands while non-Windows test environments execute safe deterministic equivalents.
_Avoid_: Platform helper, OS utils, wrapper

### Expansion Domain (v2.5 Security Pack)

**PersistenceGuard (`AutorunEntry`)**:
The fourth asynchronous monitoring Engine (`engine/persistence_guard.py`) that baselines and polls OS startup persistence locations (Windows Registry `Run`/`RunOnce` keys and Startup folder on `win32`; user autostart/cron directories on POSIX via `OSAdapter`) and emits `HIGH`/`CRITICAL` alerts whenever a new or modified persistence entry appears.
_Avoid_: Registry scanner, startup manager

**ListeningPort**:
A local socket bound in `LISTEN` state (`0.0.0.0`, `::`, or `127.0.0.1`) tracked alongside outbound connections, scored for high-risk backdoor/remote-admin ports (`4444`, `1337`, `3389`, `5900`, `6667`) or unexpected wildcard bindings.
_Avoid_: Open port, server port

**QuarantineVault (`QuarantineRecord`)**:
The reversible file containment subsystem (`engine/quarantine_vault.py` + `quarantine_items` SQLite table) allowing the operator in `GUARD` or `WAR` mode to disarm a suspicious binary or mutated file into an isolated vault (`quarantine/<id>.qvault`) and restore it to its original path on confirmation.
_Avoid_: Trash, delete bin, sandbox

### Expansion Domain (v3.0 HTTP RFC Sentinel Pack)

**HttpRfcAuditor (`RfcAuditReport`)**:
The HTTP specification compliance and security inspection engine (`engine/http_rfc_auditor.py`) that probes local listening HTTP services automatically and arbitrary user-submitted URLs on demand, evaluating responses against **RFC 9110** (Semantics, `Server` banner exposure, unsafe `TRACE`/`OPTIONS` methods), **RFC 9111** (Caching directives `Cache-Control: no-store`), **RFC 6265** (`Set-Cookie` `HttpOnly`/`Secure`/`SameSite` flags), **RFC 7838** (`Alt-Svc` HTTP/3 discovery), and **RFC 9421/9530** (cryptographic message integrity headers).
_Avoid_: Web scraper, URL ping, port checker

**RfcProtocolFirewall**:
The active ASGI protocol defense middleware (`engine/rfc_firewall.py`) protecting the monitor server against **RFC 9112** HTTP/1.1 framing attacks (conflicting `Content-Length` + `Transfer-Encoding` request smuggling attempts, obsolete line folding), **RFC 9110** hazardous reflection methods (`TRACE` Cross-Site Tracing and unauthorized `CONNECT` tunneling), and **RFC 6585** oversized header floods (`431 Request Header Fields Too Large`), emitting real-time `HIGH`/`CRITICAL` `SecurityEvent` alerts onto the `EventBus`.
_Avoid_: WAF, rate limiter

**RfcMessageSigner**:
The cryptographic response integrity module (`engine/rfc_Message_signer.py` / `engine/rfc_signer.py`) that attaches IETF-compliant **RFC 9530** `Repr-Digest: sha-256=:...:` byte-sequence digests (**RFC 9651** Structured Fields format) and **RFC 9421** `Signature-Input` + `Signature` (`hmac-sha256`) headers to API responses and exported security reports so tampering by local proxies or malware is immediately detectable.
_Avoid_: Checksum header, custom hash



