"""Asynchronous IP geolocation lookup service with SQLite cache and rate limiter."""

from collections import deque
from datetime import datetime
import ipaddress
import logging
import time
from typing import Any
import httpx
from constants import (
    IP_API_BASE_URL,
    IP_CACHE_TTL_SECONDS,
    IP_RATE_LIMIT_PER_MIN,
    RATE_LIMIT_WINDOW_SEC,
)
from storage.db import Database

logger = logging.getLogger("god_mode.ip_lookup")


class IPLookup:
    """Resolves remote IP metadata via ip-api.com with 1-hour SQLite caching."""

    def __init__(self, db: Database) -> None:
        self.db = db
        self._req_timestamps: deque[float] = deque()

    def _is_private_or_loopback(self, ip: str) -> bool:
        """Return True if IP is loopback, private, link-local, or invalid."""
        try:
            addr = ipaddress.ip_address(ip)
            return addr.is_private or addr.is_loopback or addr.is_link_local
        except ValueError:
            return True

    def _local_record(self, ip: str) -> dict[str, Any]:
        """Return a static metadata dictionary for loopback/LAN addresses."""
        return {
            "ip": ip, "country": "Local Network", "country_code": "LO",
            "org": "Localhost / LAN", "isp": "Loopback",
            "is_hosting": False, "cached": True,
        }

    def _is_cache_fresh(self, fetched_at_iso: str) -> bool:
        """Check whether a cached timestamp is younger than IP_CACHE_TTL_SECONDS."""
        try:
            age = (datetime.now() - datetime.fromisoformat(fetched_at_iso)).total_seconds()
            return age < IP_CACHE_TTL_SECONDS
        except Exception:
            return False

    def _can_make_request(self) -> bool:
        """Enforce max 45 requests per 60-second sliding window."""
        now = time.monotonic()
        while self._req_timestamps and (now - self._req_timestamps[0]) > RATE_LIMIT_WINDOW_SEC:
            self._req_timestamps.popleft()
        if len(self._req_timestamps) >= IP_RATE_LIMIT_PER_MIN:
            return False
        self._req_timestamps.append(now)
        return True

    async def _fetch_remote(self, ip: str) -> dict[str, Any]:
        """Query ip-api.com for country, org, ISP, and hosting flags."""
        fields = "status,country,countryCode,org,isp,hosting"
        url = f"{IP_API_BASE_URL}{ip}?fields={fields}"
        async with httpx.AsyncClient(timeout=3.5) as client:
            resp = await client.get(url)
            data = resp.json()
        if data.get("status") != "success":
            raise ValueError(f"ip-api lookup unsuccessful for {ip}")
        return {
            "ip": ip, "country": data.get("country") or "Unknown",
            "country_code": data.get("countryCode") or "UN",
            "org": data.get("org") or "Unknown", "isp": data.get("isp") or "Unknown",
            "is_hosting": bool(data.get("hosting", False)),
            "fetched_at": datetime.now().isoformat(timespec="seconds"),
        }

    async def lookup(self, ip: str) -> dict[str, Any]:
        """Resolve an IP address using SQLite cache first, then rate-limited API."""
        if self._is_private_or_loopback(ip):
            return self._local_record(ip)
        cached = await self.db.get_cached_ip(ip)
        if cached and self._is_cache_fresh(cached["fetched_at"]):
            return {**cached, "cached": True}
        if not self._can_make_request():
            return {**(cached or self._fallback_record(ip)), "cached": True}
        try:
            fresh = await self._fetch_remote(ip)
            await self.db.upsert_cached_ip(fresh)
            return {**fresh, "cached": False}
        except Exception:
            logger.exception("IP lookup failed for %s", ip)
            return {**(cached or self._fallback_record(ip)), "cached": True}

    def _fallback_record(self, ip: str) -> dict[str, Any]:
        """Return safe unknown metadata when remote API is unreachable."""
        return {
            "ip": ip, "country": "Unknown", "country_code": "UN",
            "org": "Unknown", "isp": "Unknown", "is_hosting": False,
            "fetched_at": datetime.now().isoformat(timespec="seconds"),
        }
