"""TDD tests for v2.5 Security Pack: PersistenceGuard, ListeningPorts, and QuarantineVault."""

from pathlib import Path
import pytest
from engine.event_bus import EventBus
from engine.persistence_guard import PersistenceGuard, score_listening_port
from engine.quarantine_vault import QuarantineVault
from storage.db import Database


@pytest.mark.asyncio
async def test_persistence_guard_detects_new_autorun_and_scores_listening_ports(tmp_path: Path):
    autorun_dir = tmp_path / "autoruns"
    autorun_dir.mkdir(parents=True, exist_ok=True)
    (autorun_dir / "legit_startup.cmd").write_text("echo normal\n", encoding="utf-8")

    bus = EventBus()
    guard = PersistenceGuard(bus, autorun_dir=autorun_dir)
    await guard.initialize_baseline()
    initial = await guard.scan_once()
    assert len(initial["autoruns"]) >= 1
    assert bus.size() == 0

    # Add a suspicious startup script after baseline
    (autorun_dir / "backdoor_updater.bat").write_text("powershell -enc AAAA\n", encoding="utf-8")
    updated = await guard.scan_once()
    assert len(updated["autoruns"]) >= 2
    assert bus.size() > 0
    ev = await bus.consume()
    assert ev["engine"] == "PERSISTENCE"
    assert ev["severity"] in ("HIGH", "CRITICAL")
    assert "backdoor_updater.bat" in ev["description"]

    # Score listening ports
    sev_bad, _, _ = score_listening_port({"port": 4444, "bind_ip": "0.0.0.0", "process_name": "nc.exe"})
    assert sev_bad == "CRITICAL"
    sev_ok, _, _ = score_listening_port({"port": 8080, "bind_ip": "127.0.0.1", "process_name": "python3"})
    assert sev_ok == "INFO"


@pytest.mark.asyncio
async def test_quarantine_vault_disarms_and_restores_file_and_blocks_system_paths(tmp_path: Path):
    db = Database(str(tmp_path / "qvault.db"))
    await db.initialize()
    try:
        vault = QuarantineVault(db, vault_dir=tmp_path / "quarantine")
        # Refuse protected OS path
        ok_sys, msg_sys, _ = await vault.quarantine_file("/usr/bin/env", reason="Test protected")
        assert ok_sys is False
        assert "protected" in msg_sys.lower()

        # Quarantine a real suspicious file
        suspect = tmp_path / "dropper.exe"
        suspect.write_bytes(b"MZ_FAKE_PAYLOAD_2026")
        ok, msg, record = await vault.quarantine_file(str(suspect), reason="Suspicious dropper")
        assert ok is True
        assert not suspect.exists()
        assert record is not None and Path(record["vault_path"]).exists()

        items = await vault.list_items()
        assert len(items) == 1 and items[0]["status"] == "QUARANTINED"

        # Restore file back to original location
        ok_res, _ = await vault.restore_file(items[0]["id"])
        assert ok_res is True
        assert suspect.exists() and suspect.read_bytes() == b"MZ_FAKE_PAYLOAD_2026"
    finally:
        await db.close()
