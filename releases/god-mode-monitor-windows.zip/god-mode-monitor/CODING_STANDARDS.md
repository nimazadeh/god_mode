# CODING_STANDARDS.md — God Mode Monitor

Read during `/code-review` (`skills/engineering/code-review/SKILL.md`). Mechanical rules (line caps, color token isolation, banned DOM APIs, Windows `.bat` syntax, selector qualification, and zero non-English source characters) are enforced deterministically in `tests/test_ticket04_reports_and_compliance.py`; do not re-report what `pytest` already gates.

## Judgment Calls & Architectural Invariants

1. **Deep Modules over Pass-Through Layers (`ADR-0001`, `ADR-0003`)**
   - Every engine (`ProcessWatcher`, `NetworkSentinel`, `FileGuard`) owns its polling/observer lifecycle and normalizes telemetry into a canonical event dictionary before publishing to `EventBus`.
   - OS-specific behavior (`win32` vs POSIX) lives exclusively behind `engine/os_adapter.py`. Callers never branch on `sys.platform`.

2. **Graceful Privilege Degradation (`psutil.AccessDenied`)**
   - Separate process name resolution (`proc.name()`) from executable path/hash inspection (`proc.exe()`). An `AccessDenied` on `proc.exe()` must preserve the resolved process name rather than collapsing the entire record to `"Unknown"`.

3. **Operate-Mode UI Discipline (`DESIGN.md`)**
   - Reserve high-saturation crimson borders and pulsing animations for active threat states (`WARN`, `HIGH`, `CRITICAL`, `WAR ACTIVE`). Structural containers use 1px neutral borders (`--border-default`) with subtle top accents (`--border-accent`).
   - Every interactive control that shares a visual class (e.g., `.mode-btn`) must bind event listeners through a semantic data attribute selector (`.mode-btn[data-mode]` vs `.wb-tab-btn[data-tab]`).
