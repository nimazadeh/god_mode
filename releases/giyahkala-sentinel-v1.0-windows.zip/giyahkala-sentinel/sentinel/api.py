"""FastAPI HTTP routes and static web asset server for GiyahKala Price Sentinel."""

from __future__ import annotations

from pathlib import Path
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from sentinel.constants import APP_TITLE, SENTINEL_VERSION
from sentinel.models import ScanRequest, WatchlistItemCreate
from sentinel.service import PriceSentinelService


def create_app(
    database_path: str | Path | None = None,
    service: PriceSentinelService | None = None,
) -> FastAPI:
    """Create and configure the FastAPI application instance."""
    project_root = Path(__file__).resolve().parent.parent
    resolved_db_path = (
        Path(database_path)
        if database_path is not None
        else project_root / "data" / "sentinel.db"
    )
    active_service = service or PriceSentinelService(
        database_path=resolved_db_path,
        seed_initial_data=True,
    )

    app = FastAPI(
        title=APP_TITLE,
        version=SENTINEL_VERSION,
        docs_url="/api/docs",
        redoc_url=None,
    )
    app.add_middleware(GZipMiddleware, minimum_size=500)
    app.state.sentinel_service = active_service

    @app.get("/api/health")
    async def get_health() -> dict:
        """Return service health and version metadata."""
        return active_service.get_health_status(version=SENTINEL_VERSION)

    @app.get("/api/diff")
    async def get_diff_report(
        changed_only: bool = Query(default=False),
        baseline_id: int | None = Query(default=None),
        current_id: int | None = Query(default=None),
    ) -> dict:
        """Return the comparison report between baseline and current snapshots."""
        try:
            report = active_service.get_current_diff_report(
                changed_only=changed_only,
                baseline_id=baseline_id,
                current_id=current_id,
            )
            return report.model_dump()
        except ValueError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error

    @app.post("/api/scan")
    async def trigger_on_demand_scan(request: ScanRequest) -> dict:
        """Run an on-demand price scan and return the resulting diff report."""
        try:
            report = await active_service.execute_on_demand_scan(request)
            return report.model_dump()
        except Exception as error:
            raise HTTPException(status_code=502, detail=str(error)) from error

    @app.get("/api/snapshots")
    async def list_snapshots() -> dict:
        """List all saved catalog snapshots."""
        return {"snapshots": active_service.list_snapshots()}

    @app.post("/api/baseline/{snapshot_id}")
    async def update_baseline(snapshot_id: int) -> dict:
        """Promote a snapshot to be the active baseline reference."""
        try:
            updated = active_service.sync_baseline_to_snapshot(snapshot_id)
            report = active_service.get_current_diff_report(changed_only=False)
            return {
                "baseline_snapshot_id": updated.snapshot_id,
                "baseline_created_at_iso": updated.created_at_iso,
                "diff": report.model_dump(),
            }
        except ValueError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error

    @app.get("/api/watchlist")
    async def get_watchlist() -> dict:
        """Return all monitored watchlist slugs."""
        return {"items": active_service.list_watchlist()}

    @app.post("/api/watchlist")
    async def add_to_watchlist(payload: WatchlistItemCreate) -> dict:
        """Add a product URL or slug to the monitored watchlist."""
        return active_service.add_watchlist_item(
            slug_or_url=payload.slug_or_url,
            label=payload.label,
        )

    @app.delete("/api/watchlist/{slug}")
    async def delete_from_watchlist(slug: str) -> dict:
        """Remove a product slug from the watchlist."""
        return active_service.remove_watchlist_item(slug)

    @app.get("/api/export.csv")
    async def download_diff_csv(
        changed_only: bool = Query(default=True),
        baseline_id: int | None = Query(default=None),
        current_id: int | None = Query(default=None),
    ) -> PlainTextResponse:
        """Export the price change report as an Excel-compatible CSV download."""
        try:
            csv_text = active_service.export_current_diff_csv(
                changed_only=changed_only,
                baseline_id=baseline_id,
                current_id=current_id,
            )
        except ValueError as error:
            raise HTTPException(status_code=404, detail=str(error)) from error
        headers = {
            "Content-Disposition": (
                'attachment; filename="giyahkala-price-changes.csv"'
            )
        }
        return PlainTextResponse(
            content=csv_text,
            media_type="text/csv; charset=utf-8",
            headers=headers,
        )

    web_dir = project_root / "web"
    if web_dir.exists():
        app.mount(
            "/assets",
            StaticFiles(directory=str(web_dir)),
            name="web_assets",
        )

        @app.get("/")
        async def serve_dashboard() -> FileResponse:
            """Serve the Linear Light-Mode web application shell."""
            return FileResponse(str(web_dir / "index.html"))

    return app
