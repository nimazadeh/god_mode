/* WebSocket command transmitter and toast notification controller */
window.GodCommands = {
  wsGetter: null,

  bindSocket(getterFn) {
    this.wsGetter = getterFn;
  },

  sendRaw(payload) {
    try {
      const ws = this.wsGetter ? this.wsGetter() : null;
      if (!ws || ws.readyState !== WebSocket.OPEN) {
        this.showToast("WebSocket disconnected; command not sent");
        return;
      }
      ws.send(JSON.stringify(payload));
    } catch (err) {
      console.error("Failed to send WebSocket command:", err);
    }
  },

  requestAction(action, alertObj) {
    const mode = window.GodApp ? window.GodApp.state.mode : "GUARD";
    if (mode === "WATCH" && ["kill_process", "block_ip", "quarantine_file"].includes(action)) {
      this.showToast("Action blocked: switch to GUARD or WAR mode first");
      return;
    }
    if (action === "block_ip" && mode !== "WAR") {
      this.showToast("Firewall blocking requires WAR MODE");
      return;
    }
    const target = action === "kill_process"
      ? String(alertObj.pid || "")
      : String(alertObj.file_path || alertObj.remote_ip || alertObj.process_path || "");
    if (["kill_process", "block_ip", "quarantine_file", "allow"].includes(action)) {
      window.GodModals.confirmAction(
        `Confirm ${action.toUpperCase()} on target "${target || alertObj.process}"?`,
        () => this.dispatchConfirmed(action, target, alertObj)
      );
      return;
    }
    this.dispatchConfirmed(action, target, alertObj);
  },

  dispatchConfirmed(action, target, alertObj) {
    this.sendRaw({
      type: "command",
      action,
      target,
      alert_id: alertObj ? alertObj.id : null,
      confirmed: true,
      process_path: alertObj ? alertObj.process_path : null,
      alert_type: alertObj ? alertObj.alert_type : "MANUAL_ALLOW",
      note: "Confirmed in dashboard",
    });
  },

  setMode(newMode) {
    this.sendRaw({ type: "command", action: "set_mode", target: newMode, confirmed: true });
    if (newMode === "WAR" && window.GodSound) window.GodSound.play("WAR_MODE");
  },

  showToast(text) {
    const box = document.getElementById("toast-container");
    if (!box) return;
    const item = document.createElement("div");
    item.className = "toast toast-enter";
    item.textContent = text;
    box.appendChild(item);
    setTimeout(() => item.remove(), 4000);
  },
};
