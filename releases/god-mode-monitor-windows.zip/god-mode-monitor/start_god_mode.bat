@echo off
setlocal enabledelayedexpansion
title God Mode Monitor v2.1 - One-Click Launcher
cd /d "%~dp0"

echo Checking for any stale God Mode Monitor instance on port 8080...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8080" ^| findstr "LISTENING"') do taskkill /F /PID %%a >nul 2>&1

if not exist "venv\Scripts\python.exe" (
    echo First time launch detected. Running setup.bat automatically...
    call setup.bat
    if %ERRORLEVEL% neq 0 (
        echo [ERROR] Setup failed. Please review the error message above.
        pause
        exit /b 1
    )
)

echo Starting God Mode Monitor v2.1 on http://localhost:8080 ...
start "" "http://localhost:8080/?v=2.1"
venv\Scripts\python.exe main.py
pause
