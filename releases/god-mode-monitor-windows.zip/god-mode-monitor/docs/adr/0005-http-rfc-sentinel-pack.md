# 0005. HTTP RFC Sentinel Pack (RFC 9110/9111/9112/9421/9530/9651)

Date: 2026-10-17
Status: Accepted

## Context

Following a comprehensive review of the IETF HTTP Working Group specifications (`https://httpwg.org/specs/`), we identified three high-value HTTP protocol security capabilities for **God Mode Monitor (v3.0)**:
1. Auditing local listening web services and on-demand URLs for compliance with **RFC 9110** (HTTP Semantics), **RFC 9111** (HTTP Caching), **RFC 6265** (Cookie security), and **RFC 7838** (`Alt-Svc`).
2. Defending the local monitor endpoint against **RFC 9112** HTTP/1.1 framing anomalies (such as conflicting `Content-Length` and `Transfer-Encoding` headers used in HTTP Request Smuggling), **RFC 9110** `TRACE`/`CONNECT` reflection attacks, and **RFC 6585** (`431 Request Header Fields Too Large`) header floods, while providing a safe 1-click RFC Attack Probe Simulator in the UI.
3. Cryptographically signing API responses and exported security reports using **RFC 9530** (`Repr-Digest`), **RFC 9421** (`Signature-Input` and `Signature`), and **RFC 9651** (`Structured Field Values` byte sequence `:base64:` syntax).

## Decision

1. **HttpRfcAuditor (`engine/http_rfc_auditor.py`)**:
   - Automatically audits local HTTP services discovered on loopback (`127.0.0.1`) and allows on-demand auditing of any user-entered `http://` or `https://` URL via `POST /api/http-rfc/audit`.
   - Evaluates 6 explicit RFC checks per target (`RFC 9110 Method Safety`, `RFC 9110 Server Banner Hygiene`, `RFC 9111 Cache-Control Safety`, `RFC 6265 Cookie Flags`, `RFC 9530 Repr-Digest Integrity`, and `RFC 9421 Message Signature`) and computes a `0–100` RFC Compliance Score.
2. **RfcProtocolFirewall & RFC Signer (`engine/rfc_firewall.py`)**:
   - Attaches **RFC 9530** `Repr-Digest: sha-256=:<base64>:` and **RFC 9421** `Signature-Input: sig1=("@status" "repr-digest");created=...;alg="hmac-sha256";keyid="god-mode-local"` + `Signature: sig1=:<base64>:` headers to `/api/*` JSON responses.
   - Inspects incoming requests for **RFC 9112 Section 6.3** smuggling indicators (simultaneous `Content-Length` + `Transfer-Encoding` or `X-RFC-Smuggle-Probe`), **RFC 9110 Section 9.3.8** `TRACE` requests, and **RFC 6585** oversized header fields (`> 8 KB`), rejecting malicious probes with appropriate RFC status codes (`400`, `405`, `431`) and pushing a `HIGH` or `CRITICAL` `SecurityEvent` onto the `EventBus`.
   - Exposes `POST /api/http-rfc/simulate-probe` to let the operator safely trigger a self-test of `RFC 9112 CL.TE Smuggling`, `RFC 9110 TRACE Reflection`, and `RFC 6585 431 Header Flood` directly from the dashboard.
3. **UI Integration (`dashboard/js/rfc_inspector.js`)**:
   - Adds `[HTTP RFC]` header button (`#btn-http-rfc`, keyboard shortcut `[H]`) opening `#rfc-drawer`, plus a 5th workbench tab (`[5: HTTP RFC]`) in Variant B.
   - Displays the live **RFC 9421 / 9530 Cryptographic Signature Verification** status, an interactive **URL RFC Compliance Auditor**, a **Safe RFC Attack Simulator** (`TRACE`, `CL.TE Smuggle`, `431 Flood`), and the live **RFC Audit Results Table**.

## Consequences

- Zero external network traffic is generated automatically; only loopback HTTP services are auto-audited, while remote URLs are audited strictly when requested by the operator.
- All new Python and JS modules strictly obey the ≤200 lines/Python file, ≤20 lines/function, and ≤80 lines/JS file constraints.
