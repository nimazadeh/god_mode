"""TDD tests for Ticket 03: OperationModes, confirmed commands, and 3-tuple Allowlist."""

from pathlib import Path
import subprocess
import sys
import pytest
from api.schemas import SettingsConfig
from api.websocket import MonitorHub
from engine.event_bus import EventBus
from engine.file_guard import FileGuard
from engine.ip_lookup import IPLookup
from engine.network_sentinel import NetworkSentinel
from engine.os_adapter import compute_sha256
from engine.process_watcher import ProcessWatcher
from storage.db import Database
from storage.report_generator import ReportGenerator


async def _make_hub(tmp_path: Path) -> tuple[MonitorHub, Database]:
    db = Database(str(tmp_path / "t03.db"))
    await db.initialize()
    cfg = SettingsConfig.default_settings()
    bus = EventBus()
    state = {
        "settings": cfg,
        "db": db,
        "event_bus": bus,
        "process_watcher": ProcessWatcher(bus, cfg),
        "network_sentinel": NetworkSentinel(bus, cfg, IPLookup(db)),
        "file_guard": FileGuard(bus, cfg, db),
        "reports": ReportGenerator(db, tmp_path / "reports"),
    }
    hub = MonitorHub(state)
    state["hub"] = hub
    return hub, db


@pytest.mark.asyncio
async def test_mode_gating_and_user_confirmation_enforcement(tmp_path: Path):
    hub, db = await _make_hub(tmp_path)
    try:
        unconfirmed = await hub.handle_command(
            {"type": "command", "action": "block_ip", "target": "185.220.101.1", "confirmed": False}
        )
        assert unconfirmed["success"] is False

        await hub.handle_command({"type": "command", "action": "set_mode", "target": "WATCH", "confirmed": True})
        watch_kill = await hub.handle_command(
            {"type": "command", "action": "kill_process", "target": "999999", "confirmed": True}
        )
        assert watch_kill["success"] is False

        await hub.handle_command({"type": "command", "action": "set_mode", "target": "GUARD", "confirmed": True})
        guard_block = await hub.handle_command(
            {"type": "command", "action": "block_ip", "target": "185.220.101.1", "confirmed": True}
        )
        assert guard_block["success"] is False

        dummy = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(30)"])
        guard_kill = await hub.handle_command(
            {"type": "command", "action": "kill_process", "target": str(dummy.pid), "confirmed": True}
        )
        assert guard_kill["success"] is True
        dummy.wait(timeout=5)

        await hub.handle_command({"type": "command", "action": "set_mode", "target": "WAR", "confirmed": True})
        war_block = await hub.handle_command(
            {"type": "command", "action": "block_ip", "target": "185.220.101.1", "confirmed": True}
        )
        assert war_block["success"] is True
        assert "185.220.101.1" in hub.state["network_sentinel"].blocked_ips
    finally:
        await db.close()


@pytest.mark.asyncio
async def test_allowlist_three_tuple_suppression_hash_mismatch_and_expiry_removal(tmp_path: Path):
    hub, db = await _make_hub(tmp_path)
    try:
        fake_bin = tmp_path / "agent_tool.bin"
        fake_bin.write_text("v1-binary-payload", encoding="utf-8")
        v1_hash = compute_sha256(str(fake_bin))

        await db.add_allowlist_rule({
            "process_path": str(fake_bin),
            "exe_hash": v1_hash,
            "alert_type": "PROC_TEMP_EXEC",
            "added_at": "2026-10-16T10:00:00",
            "expires_at": None,
            "note": "Trusted build tool",
        })
        expired_id = await db.add_allowlist_rule({
            "process_path": "/tmp/old_tool",
            "exe_hash": "deadbeef",
            "alert_type": "PROC_TEMP_EXEC",
            "added_at": "2020-01-01T00:00:00",
            "expires_at": "2020-01-02T00:00:00",
            "note": "Expired rule",
        })

        await hub.process_single_event({
            "timestamp": "2026-10-16T12:00:00",
            "engine": "PROCESS",
            "severity": "WARN",
            "alert_type": "PROC_TEMP_EXEC",
            "process_name": "agent_tool.bin",
            "process_path": str(fake_bin),
            "exe_hash": v1_hash,
            "description": "Executing from temp",
        })
        assert len(hub.alerts) == 0, "Matching 3-tuple rule should suppress alert"

        remaining_ids = [r["id"] for r in await db.list_allowlist_rules()]
        assert expired_id not in remaining_ids, "Expired rule should be auto-removed"

        fake_bin.write_text("v2-modified-binary-payload", encoding="utf-8")
        v2_hash = compute_sha256(str(fake_bin))
        await hub.process_single_event({
            "timestamp": "2026-10-16T12:05:00",
            "engine": "PROCESS",
            "severity": "WARN",
            "alert_type": "PROC_TEMP_EXEC",
            "process_name": "agent_tool.bin",
            "process_path": str(fake_bin),
            "exe_hash": v2_hash,
            "description": "Executing from temp",
        })
        assert len(hub.alerts) == 1
        assert hub.alerts[0]["needs_review"] is True
        assert "NEEDS REVIEW" in hub.alerts[0]["description"]
    finally:
        await db.close()
