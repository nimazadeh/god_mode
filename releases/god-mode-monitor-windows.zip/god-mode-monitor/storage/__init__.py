"""SQLite storage layer for God Mode Monitor."""
