/* Process Detail Drawer, File Hash Diff Modal, Confirm Dialog, and Allowlist Panel */
window.GodModals = {
  confirmCallback: null,

  showProcessDetail(proc, allEvents) {
    const drawer = document.getElementById("process-drawer");
    const body = document.getElementById("process-drawer-body");
    if (!drawer || !body) return;
    body.textContent = "";
    const fields = [
      ["Process Name", proc.name], ["PID", proc.pid], ["Full Path", proc.exe],
      ["Start Time", proc.create_time], ["CPU / RAM", `${proc.cpu_percent}% / ${proc.memory_mb} MB`],
      ["SHA-256 Hash", proc.sha256], ["Connections", (proc.connections || []).join(", ") || "None"],
      ["Risk Status", proc.risk_level],
    ];
    fields.forEach(([k, v]) => window.GodPanels.appendRow(body, `${k}: ${v}`));
    (allEvents || []).filter((e) => e.process === proc.name || e.pid === proc.pid).slice(0, 6).forEach((ev) => {
      window.GodPanels.appendRow(body, `[${ev.severity}] ${ev.timestamp} - ${ev.description}`);
    });
    window.GodInspector?.inspectItem(proc.name, fields, null);
    drawer.classList.remove("hidden");
  },

  showFileDiff(fileObj) {
    const modal = document.getElementById("diff-modal");
    const content = document.getElementById("diff-modal-body");
    if (!modal || !content) return;
    content.textContent = `Path: ${fileObj.file_path} | Event: ${fileObj.event_type} | Actor: ${fileObj.by_process} | Baseline SHA-256: ${fileObj.old_hash} | Current SHA-256: ${fileObj.new_hash}`;
    const pairs = [["Event", fileObj.event_type], ["By", fileObj.by_process], ["Status", fileObj.hash_status], ["Baseline SHA-256", fileObj.old_hash], ["Current SHA-256", fileObj.new_hash]];
    window.GodInspector?.inspectItem(fileObj.file_path, pairs, null);
    modal.classList.remove("hidden");
  },

  confirmAction(promptText, onConfirm) {
    const modal = document.getElementById("confirm-modal");
    const label = document.getElementById("confirm-modal-text");
    if (!modal || !label) return;
    label.textContent = promptText;
    this.confirmCallback = onConfirm;
    modal.classList.remove("hidden");
  },

  async toggleAllowlistDrawer(forceOpen) {
    const drawer = document.getElementById("allowlist-drawer");
    if (!drawer) return;
    const willOpen = forceOpen !== undefined ? forceOpen : drawer.classList.contains("hidden");
    drawer.classList.toggle("hidden", !willOpen);
    if (willOpen) await this.refreshAllowlistTable();
  },

  async refreshAllowlistTable() {
    try {
      const rules = await (await fetch("/api/allowlist")).json();
      const tbody = document.getElementById("allowlist-tbody");
      if (!tbody) return;
      tbody.textContent = "";
      rules.forEach((r) => {
        const tr = document.createElement("tr");
        [r.process_path, r.alert_type, (r.added_at || "").slice(0, 16), r.expires_at || "Never", r.status || "ACTIVE"].forEach((v) => window.GodPanels.appendCell(tr, v));
        const actTd = document.createElement("td");
        const delBtn = document.createElement("button");
        delBtn.className = "action-btn";
        delBtn.textContent = "Delete";
        delBtn.addEventListener("click", () => this.confirmAction(`Delete rule #${r.id}?`, () => this.deleteRule(r.id)));
        actTd.appendChild(delBtn);
        tr.appendChild(actTd);
        tbody.appendChild(tr);
      });
    } catch (err) {
      console.error("Failed to load allowlist:", err);
    }
  },

  async deleteRule(ruleId) {
    await fetch(`/api/allowlist/${ruleId}`, { method: "DELETE" });
    await this.refreshAllowlistTable();
    window.GodCommands.showToast(`Deleted allowlist rule #${ruleId}`);
  },
};
