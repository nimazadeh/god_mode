/* Programmatic Web Audio API sound synthesizer with Quiet Hours & Mute support */
const SOUND_MAP = {
  WARN: { freq: 800, dur: 0.2, vol: 0.3, count: 2, gap: 100 },
  HIGH: { freq: 1000, dur: 0.4, vol: 0.5, count: 2, gap: 150 },
  CRITICAL: { freq: 1200, dur: 0.6, vol: 0.7, count: 4, gap: 80 },
  WAR_MODE: { freq: 400, dur: 1.0, vol: 0.8, count: 1, gap: 0 },
  FILE_MOD: { freq: 600, dur: 0.3, vol: 0.4, count: 2, gap: 120 },
  BLOCK_OK: { freq: 300, dur: 0.5, vol: 0.4, count: 1, gap: 0 },
};

function createBeep(frequency, duration, volume) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const oscillator = ctx.createOscillator();
    const gainNode = ctx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(ctx.destination);
    oscillator.frequency.value = frequency;
    oscillator.type = "sine";
    gainNode.gain.setValueAtTime(volume, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + duration);
    setTimeout(() => ctx.close().catch((e) => console.error("Audio close:", e)), (duration + 0.2) * 1000);
  } catch (err) {
    console.error("Web Audio API error:", err);
  }
}

function isWithinQuietHours(quietCfg) {
  if (!quietCfg || !quietCfg.start || !quietCfg.end) return false;
  const now = new Date();
  const hhmm = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  if (quietCfg.start <= quietCfg.end) {
    return hhmm >= quietCfg.start && hhmm <= quietCfg.end;
  }
  return hhmm >= quietCfg.start || hhmm <= quietCfg.end;
}

window.GodSound = {
  muted: localStorage.getItem("god_mode_muted") === "true",
  quietHours: { start: "23:00", end: "07:00" },

  init(buttonEl) {
    this.updateButton(buttonEl);
    buttonEl.addEventListener("click", () => this.toggleMute(buttonEl));
  },

  toggleMute(buttonEl) {
    this.muted = !this.muted;
    localStorage.setItem("god_mode_muted", String(this.muted));
    this.updateButton(buttonEl);
  },

  updateButton(buttonEl) {
    if (!buttonEl) return;
    buttonEl.textContent = this.muted ? "🔇" : "🔊";
    buttonEl.title = this.muted ? "Sound Muted (S)" : "Sound Active (S)";
  },

  play(soundKey) {
    if (this.muted || isWithinQuietHours(this.quietHours)) return;
    const spec = SOUND_MAP[soundKey];
    if (!spec) return;
    for (let i = 0; i < spec.count; i += 1) {
      const delayMs = i * (spec.dur * 1000 + spec.gap);
      setTimeout(() => createBeep(spec.freq, spec.dur, spec.vol), delayMs);
    }
  },
};
