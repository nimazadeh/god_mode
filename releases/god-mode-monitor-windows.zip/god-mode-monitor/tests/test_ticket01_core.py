import asyncio
import json
from pathlib import Path
import pytest
from pydantic import ValidationError
from fastapi.testclient import TestClient


def test_settings_validation_fails_on_missing_field():
    from api.schemas import SettingsConfig

    with pytest.raises(ValidationError) as exc_info:
        SettingsConfig.model_validate({"port": 8080})
    assert "operation_mode" in str(exc_info.value)


@pytest.mark.asyncio
async def test_sqlite_schema_and_parameterized_event_storage(tmp_path: Path):
    from storage.db import Database

    db_file = tmp_path / "test_god_mode.db"
    db = Database(str(db_file))
    await db.initialize()
    event_id = await db.insert_event(
        {
            "timestamp": "2026-10-16T12:00:00",
            "engine": "PROCESS",
            "severity": "WARN",
            "process_name": "python.exe",
            "process_path": "/usr/bin/python3",
            "remote_ip": None,
            "country": None,
            "file_path": None,
            "description": "High memory usage observed",
            "action_taken": None,
            "confirmed_by": None,
        }
    )
    assert event_id > 0
    events = await db.get_recent_events(limit=10)
    assert len(events) == 1
    assert events[0]["process_name"] == "python.exe"
    await db.close()


@pytest.mark.asyncio
async def test_process_watcher_collects_live_processes():
    from api.schemas import SettingsConfig
    from engine.event_bus import EventBus
    from engine.process_watcher import ProcessWatcher

    bus = EventBus()
    settings = SettingsConfig.default_settings()
    watcher = ProcessWatcher(bus, settings)
    snapshot = await watcher.scan_once()
    assert len(snapshot) > 0
    first = snapshot[0]
    assert "pid" in first and "name" in first and "memory_mb" in first


def test_fastapi_routes_and_websocket_state_update(tmp_path: Path):
    from main import create_app

    app = create_app(db_path=str(tmp_path / "app.db"), start_background=False)
    with TestClient(app) as client:
        res = client.get("/api/stats")
        assert res.status_code == 200
        body = res.json()
        assert "process_count" in body
        with client.websocket_connect("/ws") as ws:
            msg = ws.receive_json()
            assert msg["type"] == "state_update"
            assert "stats" in msg and "processes" in msg
