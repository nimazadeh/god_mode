"""CSV export formatter for GiyahKala Price Sentinel diff reports.

Prepending a UTF-8 Byte Order Mark (BOM) ensures Microsoft Excel on Windows
opens exported price comparison sheets with clean column encoding automatically.
"""

from __future__ import annotations

import csv
import io

from sentinel.models import DiffReport


def export_diff_report_to_csv(
    report: DiffReport,
    include_utf8_bom: bool = True,
) -> str:
    """Serialize a DiffReport into an Excel-ready RFC 4180 CSV string."""
    buffer = io.StringIO()
    if include_utf8_bom:
        buffer.write("\ufeff")

    writer = csv.writer(buffer, lineterminator="\r\n")
    writer.writerow(
        [
            "Product ID",
            "SKU",
            "Slug",
            "Product Name",
            "Category",
            "Change Status",
            "Previous Price (Toman)",
            "Current Price (Toman)",
            "Delta (Toman)",
            "Delta (%)",
            "In Stock",
            "Option / Availability Details",
            "Source URL",
        ]
    )

    for item in report.items:
        previous_price_display = (
            str(item.previous_price_toman)
            if item.previous_price_toman is not None
            else "NEW"
        )
        stock_display = "In Stock" if item.current_in_stock else "Out of Stock"
        writer.writerow(
            [
                item.product_id,
                item.sku,
                item.slug,
                item.name,
                item.category,
                item.change_type.value,
                previous_price_display,
                item.current_price_toman,
                item.delta_toman,
                f"{item.delta_percent:+.2f}%",
                stock_display,
                item.option_change_summary,
                item.permalink,
            ]
        )

    return buffer.getvalue()
