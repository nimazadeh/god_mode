/* Main Dashboard DOM controller: Stat Cards, Mode Posture, Sort Indicator, and Process Table */
window.GodDashboard = {
  sortKey: "cpu_percent",
  sortAsc: false,
  statCache: { processes: 0, connections: 0, files: 0, threats: 0 },

  animateCounter(elId, targetVal) {
    const el = document.getElementById(elId);
    if (!el) return;
    const startVal = Number(this.statCache[elId] || 0);
    const endVal = Number(targetVal || 0);
    this.statCache[elId] = endVal;
    if (startVal === endVal) { el.textContent = String(endVal); return; }
    let step = 0;
    const timer = setInterval(() => {
      step += 1;
      el.textContent = String(Math.round(startVal + ((endVal - startVal) * step) / 6));
      if (step >= 6) clearInterval(timer);
    }, 30);
  },

  updateHeaderAndStats(stats) {
    if (!stats) return;
    this.animateCounter("stat-processes", stats.process_count);
    this.animateCounter("stat-connections", stats.connection_count);
    this.animateCounter("stat-files", stats.files_watched);
    this.animateCounter("stat-threats", stats.threat_count);
    document.getElementById("card-threats")?.classList.toggle("threat-active", stats.threat_count > 0);
    const mode = stats.operation_mode || "GUARD";
    document.querySelectorAll(".mode-btn[data-mode]").forEach((btn) => btn.classList.toggle("active", btn.dataset.mode === mode));
    const pill = document.getElementById("posture-indicator");
    if (pill) {
      pill.className = `posture-pill posture-${mode.toLowerCase()}`;
      pill.textContent = mode === "WAR" ? "WAR ACTIVE" : mode;
    }
    document.getElementById("main-header")?.classList.toggle("war-mode-header", mode === "WAR");
  },

  renderProcesses(processes, alerts) {
    const tbody = document.getElementById("processes-tbody");
    if (!tbody) return;
    tbody.textContent = "";
    const total = (processes || []).length;
    const base = window.GodInspector
      ? window.GodInspector.filterList(processes, (p) => `${p.pid} ${p.name} ${p.exe}`, (p) => p.risk_level !== "NORMAL")
      : (processes || []);
    const matchBadge = document.getElementById("filter-match-count");
    if (matchBadge) matchBadge.textContent = `${base.length} / ${total} SHOWN`;
    document.querySelectorAll("#processes-table th[data-sort]").forEach((th) => {
      const isSorted = th.dataset.sort === this.sortKey;
      th.classList.toggle("th-sorted", isSorted);
      th.dataset.dir = isSorted ? (this.sortAsc ? " ▲" : " ▼") : "";
    });
    const sorted = [...base].sort((a, b) => {
      const va = a[this.sortKey] ?? "";
      const vb = b[this.sortKey] ?? "";
      return typeof va === "number" && typeof vb === "number" ? (this.sortAsc ? va - vb : vb - va) : (this.sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va)));
    });
    sorted.forEach((proc) => {
      const tr = document.createElement("tr");
      tr.tabIndex = 0;
      if (proc.risk_level === "CRITICAL") tr.className = "row-critical";
      else if (proc.risk_level === "SUSPICIOUS") tr.className = "row-suspicious";
      [proc.pid, proc.name, proc.exe, `${proc.cpu_percent}%`, `${proc.memory_mb}`, proc.status].forEach((v) => window.GodPanels.appendCell(tr, v));
      tr.addEventListener("click", () => window.GodModals.showProcessDetail(proc, alerts));
      tbody.appendChild(tr);
    });
  },

  bindSortingAndKeyboard(reRenderFn) {
    document.querySelectorAll("#processes-table th[data-sort]").forEach((th) => {
      th.addEventListener("click", () => {
        this.sortAsc = this.sortKey === th.dataset.sort ? !this.sortAsc : false;
        this.sortKey = th.dataset.sort;
        reRenderFn();
      });
    });
  },
};
