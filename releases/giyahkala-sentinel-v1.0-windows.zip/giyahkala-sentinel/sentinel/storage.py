"""SQLite persistence repository for catalog snapshots and reseller watchlists.

Write-Ahead Logging (WAL) is enabled on connection creation so concurrent read
requests from the dashboard UI never block during an active catalog scan write.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from sentinel.extractor import extract_slug_from_url_or_slug
from sentinel.models import CatalogProduct, CatalogSnapshot, OptionTier


class SnapshotRepository:
    """Manage immutable CatalogSnapshots, baseline pointers, and watchlist items."""

    def __init__(self, database_path: str | Path) -> None:
        self._database_path = Path(database_path)
        self._database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize_schema()

    def _connect(self) -> sqlite3.Connection:
        """Open a SQLite connection configured with WAL journaling and row access."""
        connection = sqlite3.connect(str(self._database_path))
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA journal_mode=WAL;")
        connection.execute("PRAGMA synchronous=NORMAL;")
        connection.execute("PRAGMA temp_store=MEMORY;")
        connection.execute("PRAGMA foreign_keys=ON;")
        return connection

    def _initialize_schema(self) -> None:
        """Create snapshot, product record, and watchlist tables if absent."""
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS snapshots (
                    snapshot_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at_iso TEXT NOT NULL,
                    source_mode TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT '',
                    is_baseline INTEGER NOT NULL DEFAULT 0,
                    product_count INTEGER NOT NULL DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS idx_snapshots_baseline
                    ON snapshots(is_baseline, snapshot_id DESC)
                    WHERE is_baseline = 1;

                CREATE TABLE IF NOT EXISTS snapshot_products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_id INTEGER NOT NULL,
                    product_id INTEGER NOT NULL,
                    sku TEXT NOT NULL,
                    slug TEXT NOT NULL,
                    name TEXT NOT NULL,
                    category TEXT NOT NULL,
                    permalink TEXT NOT NULL,
                    base_price_toman INTEGER NOT NULL,
                    regular_price_toman INTEGER NOT NULL,
                    displayed_price_toman INTEGER NOT NULL,
                    is_in_stock INTEGER NOT NULL,
                    option_tiers_json TEXT NOT NULL,
                    FOREIGN KEY (snapshot_id) REFERENCES snapshots(snapshot_id) ON DELETE CASCADE
                );

                CREATE INDEX IF NOT EXISTS idx_snapshot_products_snapshot
                    ON snapshot_products(snapshot_id, id ASC);

                CREATE TABLE IF NOT EXISTS watchlist (
                    slug TEXT PRIMARY KEY,
                    label TEXT NOT NULL DEFAULT '',
                    added_at_iso TEXT NOT NULL
                );
                """
            )

    def save_snapshot(
        self,
        products: list[CatalogProduct],
        source_mode: str = "live",
        note: str = "",
        mark_as_baseline: bool = False,
    ) -> CatalogSnapshot:
        """Persist a new CatalogSnapshot and its products atomically.

        If no baseline snapshot exists yet in the repository, the first saved
        snapshot is automatically promoted to baseline so subsequent runs have
        a valid comparison anchor.
        """
        created_at_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with self._connect() as connection:
            existing_baseline_row = connection.execute(
                "SELECT snapshot_id FROM snapshots WHERE is_baseline = 1 LIMIT 1"
            ).fetchone()
            should_be_baseline = mark_as_baseline or (existing_baseline_row is None)

            if should_be_baseline:
                connection.execute("UPDATE snapshots SET is_baseline = 0")

            cursor = connection.execute(
                """
                INSERT INTO snapshots (
                    created_at_iso,
                    source_mode,
                    note,
                    is_baseline,
                    product_count
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    created_at_iso,
                    source_mode,
                    note,
                    1 if should_be_baseline else 0,
                    len(products),
                ),
            )
            snapshot_id = int(cursor.lastrowid or 1)

            product_batch = [
                (
                    snapshot_id,
                    product.product_id,
                    product.sku,
                    product.slug,
                    product.name,
                    product.category,
                    product.permalink,
                    product.base_price_toman,
                    product.regular_price_toman,
                    product.displayed_price_toman,
                    1 if product.is_in_stock else 0,
                    json.dumps(
                        [tier.model_dump() for tier in product.option_tiers],
                        ensure_ascii=False,
                    ),
                )
                for product in products
            ]
            connection.executemany(
                """
                INSERT INTO snapshot_products (
                    snapshot_id,
                    product_id,
                    sku,
                    slug,
                    name,
                    category,
                    permalink,
                    base_price_toman,
                    regular_price_toman,
                    displayed_price_toman,
                    is_in_stock,
                    option_tiers_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                product_batch,
            )

        return CatalogSnapshot(
            snapshot_id=snapshot_id,
            created_at_iso=created_at_iso,
            source_mode=source_mode,
            note=note,
            is_baseline=should_be_baseline,
            product_count=len(products),
            products=products,
        )

    def _load_snapshot_from_header(
        self,
        connection: sqlite3.Connection,
        header_row: sqlite3.Row,
    ) -> CatalogSnapshot:
        """Hydrate a CatalogSnapshot and its products using an open connection."""
        snapshot_id = int(header_row["snapshot_id"])
        product_rows = connection.execute(
            """
            SELECT * FROM snapshot_products
            WHERE snapshot_id = ?
            ORDER BY id ASC
            """,
            (snapshot_id,),
        ).fetchall()

        loaded_products = [
            CatalogProduct(
                product_id=int(row["product_id"]),
                sku=str(row["sku"]),
                slug=str(row["slug"]),
                name=str(row["name"]),
                category=str(row["category"]),
                permalink=str(row["permalink"]),
                base_price_toman=int(row["base_price_toman"]),
                regular_price_toman=int(row["regular_price_toman"]),
                displayed_price_toman=int(row["displayed_price_toman"]),
                is_in_stock=bool(row["is_in_stock"]),
                option_tiers=[
                    OptionTier(**tier_item)
                    for tier_item in json.loads(str(row["option_tiers_json"] or "[]"))
                ],
            )
            for row in product_rows
        ]

        return CatalogSnapshot(
            snapshot_id=snapshot_id,
            created_at_iso=str(header_row["created_at_iso"]),
            source_mode=str(header_row["source_mode"]),
            note=str(header_row["note"]),
            is_baseline=bool(header_row["is_baseline"]),
            product_count=int(header_row["product_count"]),
            products=loaded_products,
        )

    def get_snapshot(self, snapshot_id: int) -> CatalogSnapshot | None:
        """Load a single CatalogSnapshot and all of its product rows by ID."""
        with self._connect() as connection:
            header_row = connection.execute(
                "SELECT * FROM snapshots WHERE snapshot_id = ?",
                (snapshot_id,),
            ).fetchone()
            if header_row is None:
                return None
            return self._load_snapshot_from_header(connection, header_row)

    def get_baseline_snapshot(self) -> CatalogSnapshot | None:
        """Return the active baseline snapshot used as the comparison reference."""
        with self._connect() as connection:
            header_row = connection.execute(
                """
                SELECT * FROM snapshots
                WHERE is_baseline = 1
                ORDER BY snapshot_id DESC
                LIMIT 1
                """
            ).fetchone()
            if header_row is None:
                header_row = connection.execute(
                    "SELECT * FROM snapshots ORDER BY snapshot_id ASC LIMIT 1"
                ).fetchone()
            if header_row is None:
                return None
            return self._load_snapshot_from_header(connection, header_row)

    def get_latest_snapshot(self) -> CatalogSnapshot | None:
        """Return the most recently saved snapshot."""
        with self._connect() as connection:
            header_row = connection.execute(
                "SELECT * FROM snapshots ORDER BY snapshot_id DESC LIMIT 1"
            ).fetchone()
            if header_row is None:
                return None
            return self._load_snapshot_from_header(connection, header_row)

    def set_baseline_snapshot(self, snapshot_id: int) -> CatalogSnapshot | None:
        """Promote a specific snapshot to be the active comparison baseline."""
        target = self.get_snapshot(snapshot_id)
        if target is None:
            return None
        with self._connect() as connection:
            connection.execute("UPDATE snapshots SET is_baseline = 0")
            connection.execute(
                "UPDATE snapshots SET is_baseline = 1 WHERE snapshot_id = ?",
                (snapshot_id,),
            )
        return self.get_snapshot(snapshot_id)

    def list_snapshot_headers(self) -> list[dict]:
        """List lightweight metadata for all stored snapshots, newest first."""
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT
                    snapshot_id,
                    created_at_iso,
                    source_mode,
                    note,
                    is_baseline,
                    product_count
                FROM snapshots
                ORDER BY snapshot_id DESC
                """
            ).fetchall()

        headers: list[dict] = []
        for row in rows:
            headers.append(
                {
                    "snapshot_id": int(row["snapshot_id"]),
                    "created_at_iso": str(row["created_at_iso"]),
                    "source_mode": str(row["source_mode"]),
                    "note": str(row["note"]),
                    "is_baseline": bool(row["is_baseline"]),
                    "product_count": int(row["product_count"]),
                }
            )
        return headers

    def add_watchlist_item(self, slug_or_url: str, label: str = "") -> dict:
        """Insert or update a product slug in the reseller watchlist."""
        normalized_slug = extract_slug_from_url_or_slug(slug_or_url)
        added_at_iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        clean_label = label.strip() or normalized_slug
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO watchlist (slug, label, added_at_iso)
                VALUES (?, ?, ?)
                ON CONFLICT(slug) DO UPDATE SET
                    label = excluded.label,
                    added_at_iso = excluded.added_at_iso
                """,
                (normalized_slug, clean_label, added_at_iso),
            )
        return {
            "slug": normalized_slug,
            "label": clean_label,
            "added_at_iso": added_at_iso,
        }

    def remove_watchlist_item(self, slug: str) -> bool:
        """Delete a slug from the monitored watchlist."""
        normalized_slug = extract_slug_from_url_or_slug(slug)
        with self._connect() as connection:
            cursor = connection.execute(
                "DELETE FROM watchlist WHERE slug = ?",
                (normalized_slug,),
            )
            return (cursor.rowcount or 0) > 0

    def list_watchlist_items(self) -> list[dict]:
        """Return all configured watchlist items ordered by addition time."""
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT slug, label, added_at_iso FROM watchlist ORDER BY added_at_iso DESC"
            ).fetchall()
        return [
            {
                "slug": str(row["slug"]),
                "label": str(row["label"]),
                "added_at_iso": str(row["added_at_iso"]),
            }
            for row in rows
        ]
