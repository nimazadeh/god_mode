# Parse TM Extra Product Options `data-rules` JSON and Guard First-Time HTML Option Diffs

Product pages on `giyahkala.com` use the WooCommerce `TM Extra Product Options` plugin (`tmcp-field-wrap` / `tmcp-select`), which emits `<span class="price tc-price"><span class="amount">0 تومان</span></span>` and empty `data-price=""` attributes in raw server-rendered HTML while storing real Toman tier prices inside `data-rules` JSON arrays (for example `data-rules='["10200000"]'`). Furthermore, non-surcharge dropdowns such as extract carrier type (`نوع عصاره`) or 100-step volume selectors (`مقدار (لیتر)`) carry `data-rules='["0"]'` across all options.

We decided to:
1. Parse `data-rules` JSON on `<option>` elements whenever `data-price` is empty or zero, normalizing the extracted value to integer Toman (`IRT`).
2. Summarize multi-option `<select>` dropdowns whose individual options carry zero surcharge into a single bounded `OptionTier` row (joining up to 3 labels with `" / "` or summarizing `4+` labels as `"{first} … {last} ({count} گزینه)"` at the product's displayed base price) rather than concatenating 100 option strings or returning an empty list.
3. Suppress `OPTION_CHANGED` in `compare_single_product` whenever `previous_product.option_tiers` is empty and `delta_toman == 0`, so enabling deep HTML option inspection for the first time against a Store-API-only baseline never triggers false-positive change alerts on unchanged products.
