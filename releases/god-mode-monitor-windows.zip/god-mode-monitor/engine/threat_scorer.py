"""Threat classification and 3-tuple allowlist evaluation engine."""

from datetime import datetime
import re
from typing import Any
from constants import (
    CRITICAL_NAME_TOKENS,
    CRITICAL_OUTBOUND_MB,
    DATACENTER_ORG_TOKENS,
    HIGH_MEMORY_THRESHOLD_MB,
    HIGH_OUTBOUND_MB,
    KNOWN_CLIENT_APPS,
    SUSPICIOUS_PATH_TOKENS,
    SYSTEM_PROCESS_NAMES,
)

RAT_TOKEN_RE = re.compile(r"(?:^|[^a-z]|nj|dark|async|quasar|remcos|black)rat(?:[^a-z]|$)")


def _has_critical_name_token(name_low: str) -> bool:
    """Match malicious name tokens without false-positiving on 'migration'."""
    for tok in CRITICAL_NAME_TOKENS:
        if tok == "rat":
            if RAT_TOKEN_RE.search(name_low):
                return True
        elif tok in name_low:
            return True
    return False


def is_within_time_window(now_hhmm: str, start_hhmm: str, end_hhmm: str) -> bool:
    """Return True if HH:MM falls within start..end (handling overnight spans)."""
    if start_hhmm <= end_hhmm:
        return start_hhmm <= now_hhmm <= end_hhmm
    return now_hhmm >= start_hhmm or now_hhmm <= end_hhmm


def check_allowlist_match(
    rules: list[dict[str, Any]], process_path: str, exe_hash: str, alert_type: str
) -> tuple[bool, bool]:
    """Return (is_suppressed, needs_review) for a process_path + hash + alert_type."""
    now_iso = datetime.now().isoformat()
    for rule in rules:
        exp = rule.get("expires_at")
        if exp and exp < now_iso:
            continue
        if rule.get("process_path") == process_path and rule.get("alert_type") == alert_type:
            return (True, False) if rule.get("exe_hash") == exe_hash else (False, True)
    return False, False


def score_process_observation(
    proc: dict[str, Any], sustained_cpu: bool, is_signed: bool, has_remote: bool, allow_mem: bool
) -> tuple[str, str, str]:
    """Return (severity, alert_type, reason) for a single process snapshot."""
    name_low, path_low = str(proc.get("name", "")).lower(), str(proc.get("exe", "")).lower()
    if _has_critical_name_token(name_low):
        return "CRITICAL", "PROC_MALICIOUS_NAME", f"High-risk process name: {proc.get('name')}"
    if not is_signed and has_remote:
        return "CRITICAL", "PROC_UNSIGNED_FOREIGN", "Unsigned executable with foreign connection"
    if any(tok in path_low for tok in SUSPICIOUS_PATH_TOKENS):
        return "WARN", "PROC_TEMP_EXEC", f"Process executing from temporary path: {proc.get('exe')}"
    if name_low in SYSTEM_PROCESS_NAMES and "system32" not in path_low:
        return "HIGH", "PROC_MASQUERADE", f"System process {proc.get('name')} outside System32"
    if sustained_cpu:
        return "WARN", "PROC_CPU_SPIKE", f"Sustained CPU above 80% ({proc.get('cpu_percent')}%)"
    if float(proc.get("memory_mb", 0.0)) > HIGH_MEMORY_THRESHOLD_MB and not allow_mem:
        return "WARN", "PROC_MEM_SPIKE", f"High RAM usage ({proc.get('memory_mb')} MB)"
    return "INFO", "PROC_NORMAL", "Normal process execution"


def score_network_connection(
    conn: dict[str, Any], flagged_countries: list[str]
) -> tuple[str, str, str]:
    """Return (severity, alert_type, description) for an outbound connection."""
    code, country = str(conn.get("country_code", "UN")).upper(), str(conn.get("country", "Unknown"))
    proc_name, data_mb = str(conn.get("process_name", "Unknown")), float(conn.get("data_mb", 0.0))
    if code == "LO":
        return "INFO", "NET_CLEAN", f"Local connection ({proc_name})"
    org_low = f"{conn.get('org', '')} {conn.get('isp', '')}".lower()
    if code in flagged_countries and data_mb > CRITICAL_OUTBOUND_MB:
        return "CRITICAL", "NET_FLAGGED_EXFIL", f"{proc_name} sending ~{data_mb:.1f}MB to {country}"
    if proc_name in ("Unknown", "unknown") and data_mb > HIGH_OUTBOUND_MB:
        return "HIGH", "NET_UNKNOWN_HIGH_VOL", f"Unknown process sending ~{data_mb:.1f}MB outbound"
    if code in flagged_countries:
        return "WARN", "NET_FLAGGED_COUNTRY", f"Outbound connection from {proc_name} to {country}"
    is_known = any(app in proc_name.lower() for app in KNOWN_CLIENT_APPS)
    if (conn.get("is_hosting") or any(t in org_low for t in DATACENTER_ORG_TOKENS)) and not is_known:
        return "WARN", "NET_DATACENTER_ORG", f"{proc_name} connected to hosting network ({conn.get('org')})"
    return "INFO", "NET_CLEAN", f"{proc_name} connected to {country}"


def score_file_mutation(
    event_type: str, file_path: str, sensitive_start: str, sensitive_end: str, now_hhmm: str
) -> tuple[str, str, str]:
    """Return (severity, alert_type, description) for a watched file event."""
    ev = event_type.lower()
    if ev in ("deleted", "moved"):
        return "HIGH", f"FILE_{ev.upper()}", f"Watched file {ev}: {file_path}"
    if is_within_time_window(now_hhmm, sensitive_start, sensitive_end):
        return "CRITICAL", "FILE_SENSITIVE_HOURS", f"Nighttime modification ({now_hhmm}): {file_path}"
    return "WARN", "FILE_MODIFIED", f"Watched file {ev}: {file_path}"
