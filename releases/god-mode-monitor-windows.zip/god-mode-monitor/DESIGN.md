# DESIGN.md — God Mode Monitor Design System

## 1. Visual World & Surface Mode
- **Mode**: `Operate` (High-density real-time endpoint security telemetry).
- **Aesthetic Brief**: Dark Obsidian & Tactical Crimson (`#0D0D0D` canvas, warm-tinted charcoal surfaces, `#FF2222` crimson command accents, semantic severity badges).
- **Single Source of Color Truth**: Every color and shadow token resides exclusively in `dashboard/css/variables.css`. No other CSS file may declare literal hex, `rgb()`, or `hsl()` values.

## 2. Token Architecture (`dashboard/css/variables.css`)
- **Surfaces (Warm-tinted dark elevation layers)**:
  - `--bg-primary: #0D0D0D` (Root canvas)
  - `--bg-secondary: #131112` (Header, toolbar, sticky table headers, footer)
  - `--bg-panel: #171415` (Primary telemetry panels & drawers)
  - `--bg-card: #1D191A` (Stat cards, interactive controls, chips)
  - `--bg-row-hover: #FF222218` (Interactive row & control hover state)
- **Typography & Contrast (`>= 4.5:1` Craft Floor)**:
  - `--text-primary: #F2EEEE` (Primary data & headings)
  - `--text-secondary: #B5AAAA` (Column headers, secondary labels — warm-tinted, > 7:1 contrast)
  - `--text-muted: #8C7F7F` (Auxiliary metadata & empty state guidance — > 4.6:1 contrast)
- **Semantic Severity Palette**:
  - `INFO`: `--color-info: #5C7CFA`
  - `WARN`: `--color-warn: #FFB800`
  - `HIGH`: `--color-high: #FF6B1A`
  - `CRITICAL`: `--color-critical: #FF2222`
  - `CLEAN`: `--color-clean: #22CC66`

## 3. Typography & Numeric Discipline (`Operate Mode`)
- **UI & Telemetry Font (`--font-ui` / `--font-mono`)**: Self-hosted `'Inter'` (`Inter-Regular.woff2` & `Inter-SemiBold.woff2` under `/static/fonts/`) with `'Segoe UI', system-ui, -apple-system, sans-serif` fallback and `font-variant-numeric: tabular-nums` enforced across all counters, timestamps, PIDs, IP sockets, CPU/RAM metrics, and SHA-256 digests so numbers never jitter on 3-second WebSocket ticks.
- **Scale & Tracking**: Fixed `rem` scale (`0.68rem` badges, `0.75rem` table cells, `0.95rem` brand header, `1.65rem` stat counters); restrained uppercase tracking (`0.06em`–`0.08em`).

## 4. Interactive States & Browser Surfaces (`Craft Floor`)
- Every interactive control (`.mode-btn`, `.action-btn`, `.filter-input`, `tbody tr`, `th[data-sort]`) implements distinct `default`, `:hover`, `:focus-visible` (2px crimson focus ring with offset), `:active`, and `.active` states within `150ms–200ms` transitions.
- Empty states across `Alert Feed`, `Processes`, `Connections`, and `File Guard` provide actionable operational context rather than blank space.
- Custom browser surfaces: `::selection`, `::-webkit-scrollbar`, `:focus-visible`, and `caret-color: var(--red-core)`.
