"""API package for God Mode Monitor."""
